package simulator.component;

import java.util.EventListener;


public interface InterfaceListener extends EventListener {
	/**
	 * This fires if and only if the value of the interface i has changed.
	 * @param interface
	 */
	public void interfaceValueChanged(Interface i);
}
