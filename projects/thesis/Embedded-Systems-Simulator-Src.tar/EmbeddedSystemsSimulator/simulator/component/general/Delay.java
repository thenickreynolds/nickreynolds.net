package simulator.component.general;

import java.util.Set;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.Event;
import simulator.EventAction;
import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.component.Interface.Value;

public class Delay extends Component {
	private double delay;
	private Interface[] interfaces;
	private Interface input, output;
	private DelayGraphic ui;
	
	public Delay(String name, Engine engine, double delay) {
		super(name, engine);
		this.delay = delay;
		
		interfaces = new Interface[2];
		
		input = new Interface("input", this, Interface.INPUT);
		interfaces[0] = input;
		output = new Interface("output", this, Interface.OUTPUT);
		interfaces[1] = output;
		
		// create GUI
		ui = new DelayGraphic();
	}

	public Interface[] getInterfaces() {
		return interfaces;
	}

	public void init() {
		update();
	}
	
	public void update() {
		final Value v = input.getValue();
		
		engine.addEvent(
				new Event(this, engine.getTime() + delay, new EventAction() {
					public void execute() {
						changeOutput(v);
					}
				}));
	}
	
	public void changeOutput(Value v) {
		// if it's already the set value then return
		if(output.isValue(v)) return;
		output.setOutputValue(v);
	}

	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// only update if one of the changed interfaces was the input
		if(!changedInterfaces.contains(input)) return;
		
		update();
	}

	public void prepareOutputs() {
		output.setOutputValue(Value.LOGICAL_0);
	}

	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public void dispose() {}
	
	private class DelayGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final int width = 30;
		final int height = 20;
		
		public DelayGraphic() {
			this.setPreferredSize(new Dimension(width+1, height+1));
			this.registerInterface(input, 0, (int)(height*0.5-2.5));
			this.registerInterface(output, width-5, (int)(height*0.5-2.5));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw box
			g2D.drawRect((int)(width*0.1), (int)(height*0.1), (int)(width*0.8), (int)(height*0.8));
			// draw wires
			g2D.drawLine((int)(0), (int)(height*0.5), (int)(width*0.1), (int)(height*0.5));
			g2D.drawLine((int)(width), (int)(height*0.5), (int)(width*0.9), (int)(height*0.5));
			// draw clock hands
			g2D.drawLine((int)(width*0.5), (int)(height*0.5), (int)(width*0.5), (int)(height*0.2));
			g2D.drawLine((int)(width*0.5), (int)(height*0.5), (int)(width*0.5+height*0.2), (int)(height*0.5));
		}
	}
}
