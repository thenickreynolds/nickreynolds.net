package simulator.component.general;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;

import simulator.settings.*;
import static simulator.settings.Setting.Level;

public class PushButtonFactory extends ComponentFactory {
	public static final String NAME = "Push Button";
	public static final String PATH = "General";
	private ComponentGraphic ui = new PushButtonGraphic();
	private Setting settings[];
	private StringSetting nameSetting;
	
	public PushButtonFactory(Engine engine) {
		super(NAME, PATH, engine);
		settings = new Setting[1];
		nameSetting = new StringSetting("Name", Level.NECESSARY, NAME);
		settings[0] = nameSetting;
	}
	
	public Component createComponent() {
		return new PushButton(nameSetting.getValue(), engine);
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public Setting[] getSettings() {
		return settings;
	}
	
	private class PushButtonGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int SIDE = 20;
		
		public PushButtonGraphic() {
			this.setPreferredSize(new Dimension(SIDE+1, SIDE+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			g2D.setColor(Color.GRAY);
			g2D.draw3DRect(0, 0, SIDE-1, SIDE-1, true);
			g2D.draw3DRect(1, 1, SIDE-3, SIDE-3, true);
			g2D.draw3DRect(2, 2, SIDE-5, SIDE-5, true);
		}
	}
}