package simulator.component.general;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;
import simulator.settings.Setting;
import simulator.settings.StringSetting;
import simulator.settings.Setting.Level;

public class VCCFactory extends ComponentFactory {
	public static final String NAME = "Vcc";
	public static final String PATH = "General";
	private ComponentGraphic ui = new VCCGraphic();
	private Setting settings[];
	private StringSetting nameSetting;
	
	public VCCFactory(Engine engine) {
		super(NAME, PATH, engine);
		settings = new Setting[1];
		nameSetting = new StringSetting("Name", Level.NECESSARY, NAME);
		settings[0] = nameSetting;
	}
	
	public Component createComponent() {
		return new VCC(nameSetting.getValue(), engine);
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public Setting[] getSettings() {
		return settings;
	}
	
	private class VCCGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final int height = 20;
		final int width = 20;
		
		public VCCGraphic() {
			this.setPreferredSize(new Dimension(width+1, height+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// create the Vcc Symbol
			g2D.drawLine((int)(width*0.0), (int)(height*0.1), (int)(width*0.0), (int)(height*0.9));
			g2D.drawLine((int)(width*0.2), (int)(height*0.3), (int)(width*0.2), (int)(height*0.7));
			g2D.drawLine((int)(width*0.4), (int)(height*0.1), (int)(width*0.4), (int)(height*0.9));
			g2D.drawLine((int)(width*0.6), (int)(height*0.3), (int)(width*0.6), (int)(height*0.7));
			g2D.drawLine((int)(width*0.8), (int)(height*0.1), (int)(width*0.8), (int)(height*0.9));
			g2D.drawLine((int)(width*0.8), (int)(height*0.5), (int)(width*1.00), (int)(height*0.5));
		}
	}
}
