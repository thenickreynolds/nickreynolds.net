package simulator.component.general;

import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.component.Interface.Value;
import simulator.Engine;
import simulator.Event;
import simulator.EventAction;

import java.util.Set;

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Dimension;

public class PushButton extends Component {
	// array of all interfaces belonging to component
	private Interface interfaces[] = new Interface[1];
	// the single output
	private Interface output;
	// the graphic
	private PushButtonGraphic ui;
	// the propagation delay
	private double delay;
	// reference to this object
	final private PushButton me;
	
	public PushButton(String name, Engine engine) {
		super(name, engine);
		output = new Interface("Output", this, Interface.OUTPUT);
		interfaces[0] = output;
		delay = Engine.TIME_NANOSECOND;
		me = this;
		// create GUI
		ui = new PushButtonGraphic();
	}

	public Interface[] getInterfaces() {
		return interfaces;
	}
	
	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// this has no inputs and changing the output has no effect thus no actions
	}
	
	public void prepareOutputs() {
		output.setOutputValue(Value.LOGICAL_0);
	}
	
	public void init() { }
	
	public Interface getOutput() {
		return output;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public void dispose() {}
	
	private class PushButtonGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int SIDE = 20;
		
		public PushButtonGraphic() {
			this.setPreferredSize(new Dimension(SIDE+1, SIDE+1));
			this.registerInterface(output, (int)(SIDE*0.5-Interface.WIDTH*0.5), (int)(SIDE*0.5-Interface.HEIGHT*0.5));
			this.addMouseListener(new MouseListener() {
				public void mouseEntered(MouseEvent e) {};
				public void mouseClicked(MouseEvent e) {
					final Interface.Value v = Interface.notOperation(output.getValue());
					engine.addEvent(new Event(me, engine.getTime() + delay, new EventAction() {
						public void execute() {
							output.setOutputValue(v);
						}
					}));
				};
				public void mouseReleased(MouseEvent e) {};
				public void mousePressed(MouseEvent e) {};
				public void mouseExited(MouseEvent e) {};
			});
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			boolean raised = output.isValue(Interface.Value.LOGICAL_0);
			g2D.setColor(Color.GRAY);
			g2D.draw3DRect(0, 0, SIDE-1, SIDE-1, raised);
			g2D.draw3DRect(1, 1, SIDE-3, SIDE-3, raised);
			g2D.draw3DRect(2, 2, SIDE-5, SIDE-5, raised);
		}
	}
}
