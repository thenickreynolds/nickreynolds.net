package simulator.component.general;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;
import simulator.settings.DoubleSetting;
import simulator.settings.Setting;
import simulator.settings.StringSetting;
import simulator.settings.Setting.Level;

public class DelayFactory extends ComponentFactory {
	public static final String NAME = "Delay";
	public static final String PATH = "General";
	private ComponentGraphic ui = new DelayGraphic();
	private Setting settings[];
	private StringSetting nameSetting;
	private DoubleSetting delaySetting;
	
	public DelayFactory(Engine engine) {
		super(NAME, PATH, engine);
		settings = new Setting[2];
		nameSetting = new StringSetting("Name", Level.NECESSARY, NAME);
		delaySetting = new DoubleSetting("Propagation Delay (ms)", Level.NECESSARY, 1.0, Double.MAX_VALUE, Double.MIN_NORMAL);
		settings[0] = nameSetting;
		settings[1] = delaySetting;
	}
	
	public Setting[] getSettings() {
		return settings;
	}
	
	public Component createComponent() {
		return new Delay(nameSetting.getValue(), engine, delaySetting.getValue() / 1000.0);
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	private class DelayGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final int width = 30;
		final int height = 20;
		
		public DelayGraphic() {
			this.setPreferredSize(new Dimension(width+1, height+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw box
			g2D.drawRect((int)(width*0.1), (int)(height*0.1), (int)(width*0.8), (int)(height*0.8));
			// draw wires
			g2D.drawLine((int)(0), (int)(height*0.5), (int)(width*0.1), (int)(height*0.5));
			g2D.drawLine((int)(width), (int)(height*0.5), (int)(width*0.9), (int)(height*0.5));
			// draw clock hands
			g2D.drawLine((int)(width*0.5), (int)(height*0.5), (int)(width*0.5), (int)(height*0.2));
			g2D.drawLine((int)(width*0.5), (int)(height*0.5), (int)(width*0.5+height*0.2), (int)(height*0.5));
		}
	}
}
