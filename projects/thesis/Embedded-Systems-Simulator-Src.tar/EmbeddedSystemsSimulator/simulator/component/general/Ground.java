package simulator.component.general;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Set;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.component.Interface.Value;

public class Ground extends Component {
	// array of all interfaces belonging to component
	private Interface interfaces[] = new Interface[1];
	// the single output
	private Interface output;
	// the clock graphic
	private GroundGraphic ui;
	
	public Ground(String name, Engine engine) {
		super(name, engine);
		output = new Interface("output", this, Interface.OUTPUT);
		interfaces[0] = output;
		
		// create GUI
		ui = new  GroundGraphic();
	}
	
	public Interface[] getInterfaces() {
		return interfaces;
	}
	
	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// this has no inputs and changing the output has no effect thus no actions
	}
	
	public void prepareOutputs() {
		output.setOutputValue(Value.LOGICAL_0);
	}
	
	public void init() {
	}
	
	public Interface getOutput() {
		return output;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public void dispose() {}
	
	private class GroundGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int HEIGHT = 20;
		final static int WIDTH = 20;
		
		public GroundGraphic() {
			this.setPreferredSize(new Dimension(WIDTH+1+Interface.WIDTH, HEIGHT+1));
			registerInterface(output, (int)(WIDTH*1.0), (int)(HEIGHT*0.5-Interface.HEIGHT*0.5));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// create the Ground Symbol
			g2D.drawLine((int)(WIDTH*0.0), (int)(HEIGHT*0.5), (int)(WIDTH*0.0), (int)(HEIGHT*0.5));
			g2D.drawLine((int)(WIDTH*0.2), (int)(HEIGHT*0.4), (int)(WIDTH*0.2), (int)(HEIGHT*0.6));
			g2D.drawLine((int)(WIDTH*0.4), (int)(HEIGHT*0.3), (int)(WIDTH*0.4), (int)(HEIGHT*0.7));
			g2D.drawLine((int)(WIDTH*0.6), (int)(HEIGHT*0.2), (int)(WIDTH*0.6), (int)(HEIGHT*0.8));
			g2D.drawLine((int)(WIDTH*0.8), (int)(HEIGHT*0.1), (int)(WIDTH*0.8), (int)(HEIGHT*0.9));
			g2D.drawLine((int)(WIDTH*0.8), (int)(HEIGHT*0.5), (int)(WIDTH*1.0), (int)(HEIGHT*0.5));
		}
	}
}
