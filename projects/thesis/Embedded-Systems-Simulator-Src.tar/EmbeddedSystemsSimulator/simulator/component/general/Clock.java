package simulator.component.general;

import simulator.Event;
import simulator.EventAction;
import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.component.Interface.Value;
import simulator.Engine;

import java.util.Set;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Dimension;

public class Clock extends Component {
	// array of all interfaces belonging to component
	private Interface interfaces[] = new Interface[1];
	// the single output
	private Interface output;
	// the time between ticks of this clock
	private double step;
	// the clock graphic
	private ClockGraphic ui;
	
	public Clock(String name, Engine engine, double speed) {
		super(name, engine);
		output = new Interface("output", this, Interface.OUTPUT);
		interfaces[0] = output;
		this.step = speed/2.0;
		
		// create GUI
		ui = new ClockGraphic();
	}
	
	public void setStep(double step) {
		this.step = step;
	}
	
	public double getStep() {
		return step;
	}
	
	public Interface[] getInterfaces() {
		return interfaces;
	}
	
	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// this has no inputs and changing the output has no effect thus no actions
	}
	
	public void tick() {
		Value newOutput = Interface.notOperation(output.getValue());
		output.setOutputValue(newOutput);
		
		engine.addEvent(
				new Event(this, engine.getTime() + step, new EventAction() {
					public void execute() {
						tick();
					}
				}));
	}
	
	public void prepareOutputs() {
		output.setOutputValue(Value.LOGICAL_1);
	}
	
	public void init() {
		engine.addEvent(
				new Event(this, engine.getTime() + step, new EventAction() {
					public void execute() {
						tick();
					}
				}));
	}
	
	public Interface getOutput() {
		return output;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public void dispose() {}
	
	private class ClockGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int RADIUS = 25;
		
		public ClockGraphic() {
			this.setPreferredSize(new Dimension(RADIUS*2+1, RADIUS*2+1));
			this.registerInterface(output, (int)(RADIUS*0.5-Interface.WIDTH*0.5), (int)(RADIUS*0.5-Interface.HEIGHT*0.5));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// create the clock face
			g2D.drawOval(0, 0, RADIUS, RADIUS);
			// create the time sticks
			g2D.drawLine((int)(RADIUS*0.5), (int)(RADIUS*0.5), (int)(RADIUS*0.8), (int)(RADIUS/2.0));
			g2D.drawLine((int)(RADIUS*0.5), (int)(RADIUS*0.5), (int)(RADIUS*0.5), (int)(RADIUS-RADIUS*0.9));
		}
	}
}
