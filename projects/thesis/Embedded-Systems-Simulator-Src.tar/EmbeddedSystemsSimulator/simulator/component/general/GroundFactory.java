package simulator.component.general;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.settings.Setting;
import simulator.settings.StringSetting;
import simulator.settings.Setting.Level;

public class GroundFactory extends ComponentFactory {
	public static final String NAME = "Ground";
	public static final String PATH = "General";
	private ComponentGraphic ui = new GroundGraphic();
	private Setting settings[];
	private StringSetting nameSetting;
	
	public GroundFactory(Engine engine) {
		super(NAME, PATH, engine);
		settings = new Setting[1];
		nameSetting = new StringSetting("Name", Level.NECESSARY, NAME);
		settings[0] = nameSetting;
	}
	
	public Component createComponent() {
		return new Ground(nameSetting.getValue(), engine);
	}
	
	public Setting[] getSettings() {
		return settings;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	private class GroundGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int HEIGHT = 20;
		final static int WIDTH = 20;
		
		public GroundGraphic() {
			this.setPreferredSize(new Dimension(WIDTH+1+Interface.WIDTH, HEIGHT+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// create the Ground Symbol
			g2D.drawLine((int)(WIDTH*0.0), (int)(HEIGHT*0.5), (int)(WIDTH*0.0), (int)(HEIGHT*0.5));
			g2D.drawLine((int)(WIDTH*0.2), (int)(HEIGHT*0.4), (int)(WIDTH*0.2), (int)(HEIGHT*0.6));
			g2D.drawLine((int)(WIDTH*0.4), (int)(HEIGHT*0.3), (int)(WIDTH*0.4), (int)(HEIGHT*0.7));
			g2D.drawLine((int)(WIDTH*0.6), (int)(HEIGHT*0.2), (int)(WIDTH*0.6), (int)(HEIGHT*0.8));
			g2D.drawLine((int)(WIDTH*0.8), (int)(HEIGHT*0.1), (int)(WIDTH*0.8), (int)(HEIGHT*0.9));
			g2D.drawLine((int)(WIDTH*0.8), (int)(HEIGHT*0.5), (int)(WIDTH*1.0), (int)(HEIGHT*0.5));
		}
	}
}
