package simulator.component.general;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;

import simulator.settings.*;
import static simulator.settings.Setting.Level;

public class ClockFactory extends ComponentFactory {
	public static final String NAME = "Clock";
	public static final String PATH = "General";
	private ComponentGraphic ui = new ClockGraphic();
	private Setting settings[];
	private StringSetting nameSetting;
	private DoubleSetting frequencySetting;
	
	public ClockFactory(Engine engine) {
		super(NAME, PATH, engine);
		settings = new Setting[2];
		nameSetting = new StringSetting("Name", Level.NECESSARY, NAME);
		frequencySetting = new DoubleSetting("Frequency (Hz)", Level.NECESSARY, 1.0, Double.MAX_VALUE, Double.MIN_NORMAL);
		settings[0] = nameSetting;
		settings[1] = frequencySetting;
	}
	
	public Component createComponent() {
		return new Clock(nameSetting.getValue(), engine, 1.0/frequencySetting.getValue());
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public Setting[] getSettings() {
		return settings;
	}
	
	private class ClockGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int RADIUS = 25;
		
		public ClockGraphic() {
			this.setPreferredSize(new Dimension(RADIUS*2+1, RADIUS*2+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// create the clock face
			g2D.drawOval(0, 0, RADIUS, RADIUS);
			// create the time sticks
			g2D.drawLine((int)(RADIUS*0.5), (int)(RADIUS*0.5), (int)(RADIUS*0.8), (int)(RADIUS/2.0));
			g2D.drawLine((int)(RADIUS*0.5), (int)(RADIUS*0.5), (int)(RADIUS*0.5), (int)(RADIUS-RADIUS*0.9));
		}
	}
}