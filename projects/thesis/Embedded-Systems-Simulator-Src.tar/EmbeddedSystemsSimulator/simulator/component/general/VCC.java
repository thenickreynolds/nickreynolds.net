package simulator.component.general;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import java.util.Set;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.component.Interface.Value;

public class VCC extends Component {
	// array of all interfaces belonging to component
	private Interface interfaces[] = new Interface[1];
	// the single output
	private Interface output;
	// the clock graphic
	private VCCGraphic ui;
	
	public VCC(String name, Engine engine) {
		super(name, engine);
		output = new Interface("output", this, Interface.OUTPUT);
		interfaces[0] = output;
		
		// create GUI
		ui = new VCCGraphic();
	}
	
	public Interface[] getInterfaces() {
		return interfaces;
	}
	
	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// this has no inputs and changing the output has no effect thus no actions
	}
	
	public void prepareOutputs() {
		output.setOutputValue(Value.LOGICAL_1);
	}
	
	public void init() {
	}
	
	public Interface getOutput() {
		return output;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public void dispose() {}
	
	private class VCCGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final int height = 20;
		final int width = 20;
		
		public VCCGraphic() {
			this.setPreferredSize(new Dimension(width+1, height+1));
			registerInterface(output, (int)(width*1.0-Interface.WIDTH), (int)(height*0.5-Interface.HEIGHT*0.5));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// create the Vcc Symbol
			g2D.drawLine((int)(width*0.0), (int)(height*0.1), (int)(width*0.0), (int)(height*0.9));
			g2D.drawLine((int)(width*0.2), (int)(height*0.3), (int)(width*0.2), (int)(height*0.7));
			g2D.drawLine((int)(width*0.4), (int)(height*0.1), (int)(width*0.4), (int)(height*0.9));
			g2D.drawLine((int)(width*0.6), (int)(height*0.3), (int)(width*0.6), (int)(height*0.7));
			g2D.drawLine((int)(width*0.8), (int)(height*0.1), (int)(width*0.8), (int)(height*0.9));
			g2D.drawLine((int)(width*0.8), (int)(height*0.5), (int)(width*1.00), (int)(height*0.5));
		}
	}
}
