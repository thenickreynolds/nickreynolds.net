package simulator.component.AT90S8515;

import simulator.component.Interface;
import static simulator.component.AT90S8515.AT90S8515Consts.*;

public class Timers implements DataMemoryListener {
	private static final int SCALE_OFF = 0;
	private static final int SCALE_EXTERNAL_FALLING = -1;
	private static final int SCALE_EXTERNAL_RISING = -2;
	private static final int SCALER_VALUE[] = {SCALE_OFF, 1, 8, 64, 256, 1024, SCALE_EXTERNAL_FALLING, SCALE_EXTERNAL_RISING};
	private static enum OCM { DISCONNECTED, TOGGLE, CLEAR, SET };
	private static final OCM OUTPUT_COMPARE_MODE[] = { OCM.DISCONNECTED, OCM.TOGGLE, OCM.CLEAR, OCM.SET };
	private static enum PWM { DISABLED, MODE_8BIT, MODE_9BIT, MODE_10BIT };
	private static final PWM PULSE_WIDTH_MODE[] = { PWM.DISABLED, PWM.MODE_8BIT, PWM.MODE_9BIT, PWM.MODE_10BIT };
	
	private int timer0scaler;
	private int timer1scaler;
	private boolean timer1CTC;
	private boolean resetTimer1NextCycle = false;
	private Core core;
	private boolean timer1OutputCompareANextCycle = false;
	private boolean timer1OutputCompareBNextCycle = false;
	private int timer1OutputCompareACache;
	private int timer1OutputCompareBCache;
	private OCM timer1OutputCompareAMode;
	private OCM timer1OutputCompareBMode;
	private PWM timer1PulseWidthMode;
	private Interface outputCompareAInterface;
	private Interface outputCompareBInterface;
	
	public Timers(Core core, Interface outputCompareAInterface, Interface outputCompareBInterface) {
		this.core = core;
		this.outputCompareAInterface = outputCompareAInterface;
		this.outputCompareBInterface = outputCompareBInterface;
		// register for updates to the timer 0 control register 	
		core.dataMemory.registerListener(TCCR0, this);
		// register for updates to the timer 1 control registers 	
		core.dataMemory.registerListener(TCCR1A, this);
		core.dataMemory.registerListener(TCCR1B, this);
		core.dataMemory.registerListener(OCR1AH, this);
		core.dataMemory.registerListener(OCR1AL, this);
		core.dataMemory.registerListener(OCR1BH, this);
		core.dataMemory.registerListener(OCR1BL, this);
		// initialise the control data
		updateTimer0Control();
		updateTimer0ControlA();
		updateTimer0ControlB();
		cacheTimer1OutputACompare();
		cacheTimer1OutputBCompare();
	}
	
	public void updateTimers() {
		if(timer1OutputCompareANextCycle) {
			timer1OutputCompareANextCycle = false;
			// execute the output compare action
			if(timer1OutputCompareAMode == OCM.TOGGLE) {
				// toggle the output
				outputCompareAInterface.setOutputValue(
						Interface.notOperation(outputCompareAInterface.getValue()));
			} else if(timer1OutputCompareAMode == OCM.CLEAR) {
				// clear the output
				outputCompareAInterface.setOutputValue(Interface.Value.LOGICAL_0);
			} else if(timer1OutputCompareAMode == OCM.SET) {
				// set the output
				outputCompareAInterface.setOutputValue(Interface.Value.LOGICAL_1);
			}
			core.dataMemory.setFlagBit(TIFR, OCF1A);
		}
		if(timer1OutputCompareBNextCycle) {
			timer1OutputCompareBNextCycle = false;
			// execute the output compare action
			if(timer1OutputCompareBMode == OCM.TOGGLE) {
				// toggle the output
				outputCompareBInterface.setOutputValue(
						Interface.notOperation(outputCompareBInterface.getValue()));
			} else if(timer1OutputCompareBMode == OCM.CLEAR) {
				// clear the output
				outputCompareBInterface.setOutputValue(Interface.Value.LOGICAL_0);
			} else if(timer1OutputCompareBMode == OCM.SET) {
				// set the output
				outputCompareBInterface.setOutputValue(Interface.Value.LOGICAL_1);
			}
			core.dataMemory.setFlagBit(TIFR, OCF1B);
		}
		
		switch(timer0scaler) {
		case SCALE_OFF:
			break;
		case SCALE_EXTERNAL_RISING:
			// TODO :FUTURE: external rising edge for timer scaler
			break;
		case SCALE_EXTERNAL_FALLING:
			// TODO :FUTURE: external falling edge for timer scaler
			break;
		default:
			if(core.ticks % timer0scaler == 0)
				incrementTimer0();
			break;
		}
		switch(timer1scaler) {
		case SCALE_OFF:
			break;
		case SCALE_EXTERNAL_RISING:
			// TODO :FUTURE: external rising edge for timer scaler
			break;
		case SCALE_EXTERNAL_FALLING:
			// TODO :FUTURE: external falling edge for timer scaler
			break;
		default:
			if(core.ticks % timer1scaler == 0)
				incrementTimer1();
			break;
		}
	}

	private void incrementTimer0() {
		byte value = core.dataMemory.getMemory(TCNT0);
		value++;
		if(value == 0) {
			// timer overflow
			core.dataMemory.setFlagBit(TIFR, TOV);
		}
		core.dataMemory.setMemory(TCNT0, value);
	}
	

	private void incrementTimer1() {
		// get the value of this counter
		int value = ((core.dataMemory.getMemory(TCNT1H) << 8) & BYTE1) | (core.dataMemory.getMemory(TCNT1L) & BYTE0);
		// increment or reset timer
		if(resetTimer1NextCycle) {
			value = 0;
			resetTimer1NextCycle = false;
		} else {
			value++;
			if(value == 0) {
				// timer overflow
				core.dataMemory.setFlagBit(TIFR, TOV1);
			}
		}
		// check the output compare
		if(value == timer1OutputCompareACache) {
			timer1OutputCompareANextCycle = true;
			if(timer1CTC) resetTimer1NextCycle = true;
		}
		if(value == timer1OutputCompareBCache) {
			timer1OutputCompareBNextCycle = true;
		}
		// set the value of the timer
		core.dataMemory.setMemory(TCNT1H, (byte)(value >> 8));
		core.dataMemory.setMemory(TCNT1L, (byte)value);
		
		// TODO :FUTURE: pulse width modulation mode action?
	}
	
	public void dataMemoryChanged(int pos) {
		switch(pos) {
		case TCCR0:
			updateTimer0Control();
			break;
		case TCCR1A:
			updateTimer0ControlA();
			break;
		case TCCR1B:
			updateTimer0ControlB();
			break;
		case OCR1AH:
		case OCR1AL:
			cacheTimer1OutputACompare();
			break;
		case OCR1BH:
		case OCR1BL:
			cacheTimer1OutputBCompare();
			break;
		default:
			assert false;
		}
	}
	
	private void updateTimer0Control() {
		// update the scaler
		timer0scaler = SCALER_VALUE[core.dataMemory.getMemory(TCCR0) & 0x07];
	}
	
	private void updateTimer0ControlA() {
		byte data = core.dataMemory.getMemory(TCCR1A);
		// update the pulse width mode
		timer1PulseWidthMode = PULSE_WIDTH_MODE[data & 0x03];
		// update the output compare A and B modes
		timer1OutputCompareBMode = OUTPUT_COMPARE_MODE[(data & 0x30) >> 4];
		timer1OutputCompareAMode = OUTPUT_COMPARE_MODE[(data & 0xC0) >> 6];
	}
	
	private void updateTimer0ControlB() {
		byte data = core.dataMemory.getMemory(TCCR1B);
		// update the scaler
		timer1scaler = SCALER_VALUE[data & 0x07];
		// update the clear on timer compare flag
		timer1CTC = ((data & 0x08) != 0);
		// TODO :FUTURE: input capture noise canceller
		// TODO :FUTURE: input capture edge select
	}
	
	private void cacheTimer1OutputACompare() {
		// cache the timer 1 output compare A value
		timer1OutputCompareACache = ((core.dataMemory.getMemory(OCR1AH) << 8) & BYTE1) | (core.dataMemory.getMemory(OCR1AL) & BYTE0);
	}
	
	private void cacheTimer1OutputBCompare() {
		// cache the timer 1 output compare B value
		timer1OutputCompareACache = ((core.dataMemory.getMemory(OCR1BH) << 8) & BYTE1) | (core.dataMemory.getMemory(OCR1BL) & BYTE0);
	}
}