package simulator.component.AT90S8515;

public class AT90S8515Consts {
	/* PIN NAMES */
	public final static String PIN_NAMES[] = new String[] {
		"PIN 01: PB0 (T0)",		// pin 1
		"PIN 02: PB1 (T1)",		// pin 2
		"PIN 03: PB2 (AIN0)",	// pin 3
		"PIN 04: PB3 (AIN1)",	// pin 4
		"PIN 05: PB4 (!SS)",	// pin 5
		"PIN 06: PB5 (MOSI)",	// pin 6
		"PIN 07: PB6 (MISO)",	// pin 7
		"PIN 08: PB7 (SCK)",	// pin 8
		"PIN 09: NOT RESET",	// pin 9
		"PIN 10: PD0 (RXD)",	// pin 10
		"PIN 11: PD1 (TXD)",	// pin 11
		"PIN 12: PD2 (INT0)",	// pin 12
		"PIN 13: PD3 (INT1)",	// pin 13
		"PIN 14: PD4",			// pin 14
		"PIN 15: PD5 (OC1A)",	// pin 15
		"PIN 16: PD6 (!WR)",	// pin 16
		"PIN 17: PD7 (!RD)",	// pin 17
		"PIN 18: XTAL2",		// pin 18
		"PIN 19: XTAL1",		// pin 19
		"PIN 20: GND",			// pin 20
		"PIN 21: PC0 (A8)",		// pin 21
		"PIN 22: PC1 (A9)",		// pin 22
		"PIN 23: PC2 (A10)",	// pin 23
		"PIN 24: PC3 (A11)",	// pin 24
		"PIN 25: PC4 (A12)",	// pin 25
		"PIN 26: PC5 (A13)",	// pin 26
		"PIN 27: PC6 (A14)",	// pin 27
		"PIN 28: PC7 (A15)",	// pin 28
		"PIN 29: OC1B",			// pin 29
		"PIN 30: ALE",			// pin 30
		"PIN 31: ICP",			// pin 31
		"PIN 32: PA7 (AD7)",	// pin 32
		"PIN 33: PA6 (AD6)",	// pin 33
		"PIN 34: PA5 (AD5)",	// pin 34
		"PIN 35: PA4 (AD4)",	// pin 35
		"PIN 36: PA3 (AD3)",	// pin 36
		"PIN 37: PA2 (AD2)",	// pin 37
		"PIN 38: PA1 (AD1)",	// pin 38
		"PIN 39: PA0 (AD0)",	// pin 39
		"PIN 40: VCC"			// pin 40
	};
	
	/* REGISTER NAMES */
	public final static String REGISTER_NAMES[] = new String[] {
		"General 0",			// register 0
		"General 1",			// register 1
		"General 2",			// register 2
		"General 3",			// register 3
		"General 4",			// register 4
		"General 5",			// register 5
		"General 6",			// register 6
		"General 7",			// register 7
		"General 8",			// register 8
		"General 9",			// register 9
		"General 10",			// register 10
		"General 11",			// register 11
		"General 12",			// register 12
		"General 13",			// register 13
		"General 14",			// register 14
		"General 15",			// register 15
		"General 16",			// register 16
		"General 17",			// register 17
		"General 18",			// register 18
		"General 19",			// register 19
		"General 20",			// register 20
		"General 21",			// register 21
		"General 22",			// register 22
		"General 23",			// register 23
		"General 24",			// register 24
		"General 25",			// register 25
		"General 26",			// register 26
		"General 27",			// register 27
		"General 28",			// register 28
		"General 29",			// register 29
		"General 30",			// register 30
		"General 31",			// register 31
		"RESERVED",				// register 32
		"RESERVED",				// register 33
		"RESERVED",				// register 34
		"RESERVED",				// register 35
		"RESERVED",				// register 36
		"RESERVED",				// register 37
		"RESERVED",				// register 38
		"RESERVED",				// register 39
		"ACSR",					// register 40
		"UBRR",					// register 41
		"UCR",					// register 42
		"USR",					// register 43
		"UDR",					// register 44
		"SPCR",					// register 45
		"SPSR",					// register 46
		"SPDR",					// register 47
		"PIND",					// register 48
		"DDRD",					// register 49
		"PORTD",				// register 50
		"PINC",					// register 51
		"DDRC",					// register 52
		"PORTC",				// register 53
		"PINB",					// register 54
		"DDRB",					// register 55
		"PORTB",				// register 56
		"PINA",					// register 57
		"DDRA",					// register 58
		"PORTA",				// register 59
		"EECR",					// register 60
		"EEDR",					// register 61
		"EEARL",				// register 62
		"EEARH",				// register 63
		"RESERVED",				// register 64
		"WDTCR",				// register 65
		"RESERVED",				// register 66
		"RESERVED",				// register 67
		"ICR1L",				// register 68
		"ICR1H",				// register 69
		"RESERVED",				// register 70
		"RESERVED",				// register 71
		"OCR1BL",				// register 72
		"OCR1BH",				// register 73
		"OCR1AL",				// register 74
		"OCR1AH",				// register 75
		"TCNT1L",				// register 76
		"TCNT1H",				// register 77
		"TCCR1B",				// register 78
		"TCCR1A",				// register 79
		"RESERVED",				// register 80
		"RESERVED",				// register 81
		"TCNT0",				// register 82
		"TCCR0",				// register 83
		"RESERVED",				// register 84
		"MCUCR",				// register 85
		"RESERVED",				// register 86
		"RESERVED",				// register 87
		"TIFR",					// register 88
		"TIMSK",				// register 89
		"GIFR",					// register 90
		"GIMSK",				// register 91
		"RESERVED",				// register 92
		"SPL",					// register 93
		"SPH",					// register 94
		"SREG",					// register 95
	};
	
	// memory boundaries
	// the start of the WXYZ registers (note, W does not exist on this chip)
	protected static final int INDIRECT_REGISTERS_OFFSET = 0x18;
	// the start of the IO Registers
	protected static final int IO_REGISTERS_OFFSET = 0x20;
	// the start of the internal SRAM
	protected static final int INTERNAL_SRAM_OFFSET = 0x60;
	
	// the number of program instructions
	protected final static int NUM_INSTRUCTIONS = 0x1000;
	
	// the clock speed in ticks per second
	// TODO :FUTURE: this will need to become variable
	public static final int CLOCK_SPEED 			= 4000000;
	
	/* GENERAL CONSTS */
	public static final int BIT0					= 0x01;
	public static final int BIT1					= 0x02;
	public static final int BIT2					= 0x04;
	public static final int BIT3					= 0x08;
	public static final int BIT4					= 0x10;
	public static final int BIT5					= 0x20;
	public static final int BIT6					= 0x40;
	public static final int BIT7					= 0x80;
	
	public static final int BYTE0					= 0x000000FF;
	public static final int BYTE1					= 0x0000FF00;
	public static final int BYTE2					= 0x00FF0000;
	public static final int BYTE3					= 0xFF000000;
	
	/* PINS */
	public static final int INTERFACE_RXD			= 9;
	public static final int INTERFACE_TXD			= 10;
	public static final int INTERFACE_INT0			= 11;
	public static final int INTERFACE_INT1			= 12;
	public static final int INTERFACE_OC1A			= 14;
	public static final int INTERFACE_OC1B			= 28;
	
	/* the value after a bitwise and if all pins are input */
	public static final int PORT_INPUT				= 0x00;
	
	// the value for the UART interrupt mask, masks interrupts bits only
	public static final int UART_INTERRUPT_MASK		= 0xE0; 
	
	// REGISTERS & PINS
	public static final int GENERAL_PURPOSE_0		= 0x00;
	public static final int GENERAL_PURPOSE_1		= 0x01;
	public static final int GENERAL_PURPOSE_2		= 0x02;
	public static final int GENERAL_PURPOSE_3		= 0x03;
	public static final int GENERAL_PURPOSE_4		= 0x04;
	public static final int GENERAL_PURPOSE_5		= 0x05;
	public static final int GENERAL_PURPOSE_6		= 0x06;
	public static final int GENERAL_PURPOSE_7		= 0x07;
	public static final int GENERAL_PURPOSE_8		= 0x08;
	public static final int GENERAL_PURPOSE_9		= 0x09;
	public static final int GENERAL_PURPOSE_10		= 0x0A;
	public static final int GENERAL_PURPOSE_11		= 0x0B;
	public static final int GENERAL_PURPOSE_12		= 0x0C;
	public static final int GENERAL_PURPOSE_13		= 0x0D;
	public static final int GENERAL_PURPOSE_14		= 0x0E;
	public static final int GENERAL_PURPOSE_15		= 0x0F;
	public static final int GENERAL_PURPOSE_16		= 0x10;
	public static final int GENERAL_PURPOSE_17		= 0x11;
	public static final int GENERAL_PURPOSE_18		= 0x12;
	public static final int GENERAL_PURPOSE_19		= 0x13;
	public static final int GENERAL_PURPOSE_20		= 0x14;
	public static final int GENERAL_PURPOSE_21		= 0x15;
	public static final int GENERAL_PURPOSE_22		= 0x16;
	public static final int GENERAL_PURPOSE_23		= 0x17;
	public static final int GENERAL_PURPOSE_24		= 0x18;
	public static final int GENERAL_PURPOSE_25		= 0x19;
	public static final int GENERAL_PURPOSE_26		= 0x1A;
	public static final int X_LOW_BYTE				= GENERAL_PURPOSE_26;
	public static final int GENERAL_PURPOSE_27		= 0x1B;
	public static final int X_HIGH_BYTE				= GENERAL_PURPOSE_27;
	public static final int GENERAL_PURPOSE_28		= 0x1C;
	public static final int Y_LOW_BYTE				= GENERAL_PURPOSE_28;
	public static final int GENERAL_PURPOSE_29		= 0x1D;
	public static final int Y_HIGH_BYTE				= GENERAL_PURPOSE_29;
	public static final int GENERAL_PURPOSE_30		= 0x1E;
	public static final int Z_LOW_BYTE				= GENERAL_PURPOSE_30;
	public static final int GENERAL_PURPOSE_31		= 0x1F;
	public static final int Z_HIGH_BYTE				= GENERAL_PURPOSE_31;
	public static final int ACSR					= 0x28;
	public static final int UBRR					= 0x29;
	public static final int UCR						= 0x2A;
		public static final int TXB8			= BIT0;
		public static final int RXB8			= BIT1;
		public static final int CHR9			= BIT2;
		public static final int TXEN			= BIT3;
		public static final int RXEN			= BIT4;
		public static final int UDRIE			= BIT5;
		public static final int TXCIE			= BIT6;
		public static final int RXCIE			= BIT7;
	public static final int USR						= 0x2B;
		public static final int OR				= BIT3;
		public static final int FE				= BIT4;
		public static final int UDRE			= BIT5;
		public static final int TXC				= BIT6;
		public static final int RXC				= BIT7;
	public static final int UDR						= 0x2C;
	public static final int SPCR					= 0x2D;
	public static final int SPSR					= 0x2E;
	public static final int SPDR					= 0x2F;
	public static final int PIND					= 0x30;
	public static final int DDRD					= 0x31;
		public static final int DDD0			= BIT0;
		public static final int DDD1			= BIT1;
		public static final int DDD2			= BIT2;
		public static final int DDD3			= BIT3;
		public static final int DDD4			= BIT4;
		public static final int DDD5			= BIT5;
		public static final int DDD6			= BIT6;
		public static final int DDD7			= BIT7;
	public static final int PORTD					= 0x32;
	public static final int PINC					= 0x33;
	public static final int DDRC					= 0x34;
		public static final int DDC0			= BIT0;
		public static final int DDC1			= BIT1;
		public static final int DDC2			= BIT2;
		public static final int DDC3			= BIT3;
		public static final int DDC4			= BIT4;
		public static final int DDC5			= BIT5;
		public static final int DDC6			= BIT6;
		public static final int DDC7			= BIT7;
	public static final int PORTC					= 0x35;
	public static final int PINB					= 0x36;
	public static final int DDRB					= 0x37;
		public static final int DDB0			= BIT0;
		public static final int DDB1			= BIT1;
		public static final int DDB2			= BIT2;
		public static final int DDB3			= BIT3;
		public static final int DDB4			= BIT4;
		public static final int DDB5			= BIT5;
		public static final int DDB6			= BIT6;
		public static final int DDB7			= BIT7;
	public static final int PORTB					= 0x38;
	public static final int PINA					= 0x39;
	public static final int DDRA					= 0x3A;
		public static final int DDA0			= BIT0;
		public static final int DDA1			= BIT1;
		public static final int DDA2			= BIT2;
		public static final int DDA3			= BIT3;
		public static final int DDA4			= BIT4;
		public static final int DDA5			= BIT5;
		public static final int DDA6			= BIT6;
		public static final int DDA7			= BIT7;
	public static final int PORTA					= 0x3B;
	public static final int EECR					= 0x3C;
	public static final int EEDR					= 0x3D;
	public static final int EEARL					= 0x3E;
	public static final int EEARH					= 0x3F;
	public static final int WDTCR					= 0x41;
	public static final int ICR1L					= 0x44;
	public static final int ICR1H					= 0x45;
	public static final int OCR1BL					= 0x48;
	public static final int OCR1BH					= 0x49;
	public static final int OCR1AL					= 0x4A;
	public static final int OCR1AH					= 0x4B;
	public static final int TCNT1L					= 0x4C;
	public static final int TCNT1H					= 0x4D;
	public static final int TCCR1B					= 0x4E;
	public static final int TCCR1A					= 0x4F;
	public static final int TCNT0					= 0x52;
	public static final int TCCR0					= 0x53;
	public static final int MCUCR					= 0x55;
	public static final int TIFR					= 0x58;
		public static final int TOV				= BIT1;
		public static final int ICF1			= BIT3;
		public static final int OCF1B			= BIT5;
		public static final int OCF1A			= BIT6;
		public static final int TOV1			= BIT7;
	public static final int TIMSK					= 0x59;
	public static final int GIFR					= 0x5A;
		public static final int INT0			= BIT6;
		public static final int INT1			= BIT7;
	public static final int GIMSK					= 0x5B;
		public static final int INTF0			= BIT6;
		public static final int INTF1			= BIT7;
	public static final int SPL						= 0x5D;
		public static final int SP0				= BIT0;
		public static final int SP1				= BIT1;
		public static final int SP2				= BIT2;
		public static final int SP3				= BIT3;
		public static final int SP4				= BIT4;
		public static final int SP5				= BIT5;
		public static final int SP6				= BIT6;
		public static final int SP7				= BIT7;
	public static final int SPH						= 0x5E;
		public static final int SP8				= BIT0;
		public static final int SP9				= BIT1;
		public static final int SP10			= BIT2;
		public static final int SP11			= BIT3;
		public static final int SP12			= BIT4;
		public static final int SP13			= BIT5;
		public static final int SP14			= BIT6;
		public static final int SP15			= BIT7;
	public static final int SREG					= 0x5F;
		public static final int SREG_C			= BIT0;
		public static final int SREG_Z			= BIT1;
		public static final int SREG_N			= BIT2;
		public static final int SREG_V			= BIT3;
		public static final int SREG_S			= BIT4;
		public static final int SREG_H			= BIT5;
		public static final int SREG_T			= BIT6;
		public static final int SREG_I			= BIT7;
}
