package simulator.component.AT90S8515;

import simulator.TemporaryException;
import simulator.component.AT90S8515.instructions.Instruction;
import simulator.component.AT90S8515.instructions.Instruction32Bit;
import static simulator.component.AT90S8515.AT90S8515Consts.*;

public class Core {
	/* NOTATION:
	 *  Rd:		Destination (and source) register in the Register File
	 *  Rr:		Source register in the register file
	 *  Rs:		Result after instruction is executed
	 *  K:		Constant data
	 *  k:		Constant address
	 *  b:		Bit in the Register File or I/O Register (3-bit)
	 *  s:		Bit in the Status Register (3-bit)
	 *  X,Y,Z:	Indirect Address Register (X=R27:R26, Y=R29:R28, Z=R31:R30)
	 *  A:		I/O location address
	 *  q:		Displacement for direct addressing (6-bit)
	 */
	
	/* this is the in-system programmable flash program memory
	 *  these are 16 bits wide (two bytes per cell)
	 *  NOTE: This should be changed to a short (2 byte primitive) when possible - will need to change a lot of code
	 */
	protected Instruction programMemory[];
	// the program counter 
	protected int programCounter = 0x0000;
	// the number of cycles to wait before executing the next instruction
	protected int waitCycles = 0;
	// the total number of ticks thus far
	protected long ticks = 0;
	// the byte program code
	protected byte programCode[];
	
	/* this is the memory array containing the following in order
	 *  32 general purpose registers
	 *  64 I/O registers
	 *  512 SRAM slots
	 *  
	 *  these are 8 bits wide (one byte per cell)
	 */
	protected DataMemory dataMemory = new DataMemory(0x260);
		
	/** Create a new Instruction Set Interpreter, loading in programMemory as the program instructions
	 * @param program	The program memory (instructions)
	 */
	public Core(byte programCode[]) {
		if(programCode.length != Interpreter.PROGRAM_SIZE_BYTES)
			throw new TemporaryException("Program not correct size - should be " + Interpreter.PROGRAM_SIZE_BYTES);
		this.programCode = programCode;
		programMemory = Interpreter.interpret(programCode, this);
	}
	
	public boolean nextIsBreakpoint() {
		return waitCycles == 0 && programMemory[programCounter].getBreakpoint();
	}
	
	public int numWaitCycles() {
		return waitCycles;
	}
	
	/** Execute the next instruction
	 */
	public void executeNextInstruction() {
		ticks++;
		if(waitCycles > 0) {
			// wait a cycle and decrement wait cycles
			waitCycles--;
		} else {
			// execute the next instruction
			programMemory[programCounter].execute();
		}
	}
	
	protected void instruction_nop() {
		incrementPC();
	}
	
	protected void instruction_cpc(final int Rd_address, final int Rr_address) {
		compare(dataMemory.getMemory(Rd_address), dataMemory.getMemory(Rr_address), true);
		incrementPC();
	}
	
	protected void instruction_sbc(final int Rd_address, final int Rr_address) {
		dataMemory.setMemory(Rd_address, subtract(dataMemory.getMemory(Rd_address), dataMemory.getMemory(Rr_address), true));
		incrementPC();
	}
	
	protected void instruction_add(final int Rd_address, final int Rr_address) {
		dataMemory.setMemory(Rd_address, add(dataMemory.getMemory(Rd_address), dataMemory.getMemory(Rr_address), false));
		incrementPC();
	}
	
	protected void instruction_cp(final int Rd_address, final int Rr_address) {
		compare(dataMemory.getMemory(Rd_address), dataMemory.getMemory(Rr_address), false);
		incrementPC();
	}
	
	protected void instruction_cpse(final int Rd_address, final int Rr_address) {
		// get the register which we will be operating on
		int Rd = dataMemory.getMemory(Rd_address);
		int Rr = dataMemory.getMemory(Rr_address);
		
		// check this bit
		if(Rd == Rr) {
			if(programMemory[programCounter+1] instanceof Instruction32Bit) {
				setPCRelative(3);
				setWaitCycles(2);
			} else {
				setPCRelative(2);
				setWaitCycles(1);
			}
		} else {
			incrementPC();
		}
	}
	
	protected void instruction_sub(final int Rd_address, final int Rr_address) {
		dataMemory.setMemory(Rd_address, subtract(dataMemory.getMemory(Rd_address), dataMemory.getMemory(Rr_address), false));
		incrementPC();		
	}
	
	protected void instruction_adc(final int Rd_address, final int Rr_address) {
		dataMemory.setMemory(Rd_address, add(dataMemory.getMemory(Rd_address), dataMemory.getMemory(Rr_address), true));
		incrementPC();
	}
	
	protected void instruction_and(final int Rd_address, final int Rr_address) {
		dataMemory.setMemory(Rd_address, and(dataMemory.getMemory(Rd_address), dataMemory.getMemory(Rr_address)));
		incrementPC();
	}
	
	protected void instruction_eor(final int Rd_address, final int Rr_address) {
		// get the registers which we will be operating on
		byte Rd = dataMemory.getMemory(Rd_address);
		byte Rr = dataMemory.getMemory(Rr_address);
		byte Rs = (byte)((Rd & BYTE0) ^ (Rr & BYTE0));
		
		setStatusN((Rs & BIT7) != 0);
		setStatusV(false);
		setStatusZ(Rs == 0x00);
		setStatusS(getStatusN() ^ getStatusV());
		
		dataMemory.setMemory(Rd_address, Rs);
		incrementPC();
	}
	
	protected void instruction_or(final int Rd_address, final int Rr_address) {
		dataMemory.setMemory(Rd_address, or(dataMemory.getMemory(Rd_address), dataMemory.getMemory(Rr_address)));
		incrementPC();
	}
	
	protected void instruction_mov(final int Rd_address, final int Rr_address) {
		dataMemory.setMemory(Rd_address, dataMemory.getMemory(Rr_address));
		incrementPC();
	}
	
	protected void instruction_cpi(final int Rd_address, final byte K) {
		compare(dataMemory.getMemory(Rd_address), K, false);
		incrementPC();
	}
	
	protected void instruction_sbci(final int Rd_address, final byte K) {
		dataMemory.setMemory(Rd_address, subtract(dataMemory.getMemory(Rd_address), K, true));
		incrementPC();
	}
	
	protected void instruction_subi(final int Rd_address, final byte K) {
		dataMemory.setMemory(Rd_address, subtract(dataMemory.getMemory(Rd_address), K, false));
		incrementPC();
	}
	
	protected void instruction_ori(final int Rd_address, final byte K) {
		dataMemory.setMemory(Rd_address, or(dataMemory.getMemory(Rd_address), K));
		incrementPC();
	}
	
	protected void instruction_andi(final int Rd_address, final byte K) {
		dataMemory.setMemory(Rd_address, and(dataMemory.getMemory(Rd_address), K));
		incrementPC();
	}
	
	/**
	 * This performs the code for a ld instruction.
	 * @param register		The 16 bit register to use.
	 * @param Rr_address	The source address
	 * @param postincrement	If this true then this will increment "register" after the load, otherwise it will decrement register before the load.
	 */
	protected void instruction_ld(int register, int Rd_address, boolean postincrement) {
		int value = ((dataMemory.getMemory(register+1) & 0xFF) << 8) | (dataMemory.getMemory(register) & 0xFF);
		
		if(!postincrement) value--; // pre decrement
		
		dataMemory.setMemory(Rd_address, dataMemory.getMemory(value));
		
		if(postincrement) value++; // post increment
		
		dataMemory.setMemory(register, (byte)(value & 0x00FF));
		dataMemory.setMemory(register+1, (byte)((value & 0xFF00) >> 8));
		
		setWaitCycles(1);
		incrementPC();
	}
	
	protected void instruction_st(int register, int Rd_address, boolean postincrement) {
		int value = ((dataMemory.getMemory(register+1) & 0xFF) << 8) | (dataMemory.getMemory(register) & 0xFF);
		
		if(!postincrement) value--; // pre decrement
		
		dataMemory.setMemory(value, dataMemory.getMemory(Rd_address));
		
		if(postincrement) value++; // post increment
		
		dataMemory.setMemory(register, (byte)(value & 0x00FF));
		dataMemory.setMemory(register+1, (byte)((value & 0xFF00) >> 8));
		
		setWaitCycles(1);
		incrementPC();
	}
	
	
	protected void instruction_ldd(int register, int Rd_address, int offset) {
		int value = ((dataMemory.getMemory(register+1) & 0xFF) << 8) | (dataMemory.getMemory(register) & 0xFF);
		
		dataMemory.setMemory(Rd_address, dataMemory.getMemory(value + offset));
		
		setWaitCycles(1);
		incrementPC();
	}
	
	protected void instruction_std(int register, int Rd_address, int offset) {
		int value = ((dataMemory.getMemory(register+1) & 0xFF) << 8) | (dataMemory.getMemory(register) & 0xFF);
		
		dataMemory.setMemory(value + offset, dataMemory.getMemory(Rd_address));
		
		setWaitCycles(1);
		incrementPC();
	}
	
	// 32 bit instruction
	protected void instruction_lds(int Rr_address, int k) {
		dataMemory.setMemory(Rr_address, dataMemory.getMemory(k));
		incrementPC();
		incrementPC();
		setWaitCycles(1);
	}
	
	// 32 bit instruction
	protected void instruction_sts(int Rd_address, int k) {
		dataMemory.setMemory(k, dataMemory.getMemory(Rd_address));
		incrementPC();
		incrementPC();
		setWaitCycles(1);
	}
	
	protected void instruction_pop(final int Rd_address) {
		dataMemory.setMemory(Rd_address, pop());
		incrementPC();
		setWaitCycles(1);
	}
	
	protected void instruction_push(final int Rd_address) {
		push(dataMemory.getMemory(Rd_address));
		incrementPC();
		setWaitCycles(1);
	}
	
	protected void instruction_neg(final int Rd_address) {
		byte Rd = dataMemory.getMemory(Rd_address);
		byte Rs = (byte)(0x00 - Rd);
		
		setStatusH((Rs & BIT3) != 0 || (Rd & BIT3) != 0);
		setStatusN((Rs & BIT7) != 0);
		setStatusV(Rs == 0x80);
		setStatusZ(Rs == 0x00);
		setStatusC(Rs != 0x00);
		setStatusS(getStatusN() ^ getStatusV());
		
		dataMemory.setMemory(Rd_address, Rs);
		incrementPC();
	}
	
	protected void instruction_com(final int Rd_address) {
		byte Rd = dataMemory.getMemory(Rd_address);
		byte Rs = (byte)(0xFF - Rd);
		
		setStatusN((Rs & BIT7) != 0);
		setStatusV(false);
		setStatusZ(Rs == 0x00);
		setStatusC(true);
		setStatusS(getStatusN() ^ getStatusV());
		
		dataMemory.setMemory(Rd_address, Rs);
		incrementPC();
	}
	
	protected void instruction_swap(final int Rd_address) {
		byte Rd = dataMemory.getMemory(Rd_address); 
		dataMemory.setMemory(Rd_address, (byte)(((Rd & 0xF0) >> 4) | ((Rd & 0x0F) << 4)));
		incrementPC();
	}
	
	protected void instruction_inc(final int Rd_address) {
		byte Rs = (byte)(dataMemory.getMemory(Rd_address) + 1);
		
		setStatusV(Rs == 0x80);
		setStatusN((Rs & BIT7) != 0);
		setStatusZ(Rs == 0x00);
		setStatusS(getStatusN() ^ getStatusV());

		dataMemory.setMemory(Rd_address, Rs);
		incrementPC();
	}
	
	protected void instruction_asr(final int Rd_address) {
		byte Rd = dataMemory.getMemory(Rd_address);
		byte Rs = (byte)(((Rd & BYTE0) >> 1) | ((Rd & BYTE0) & 0x80));
		
		setStatusN((Rs & BIT7) != 0);
		setStatusZ(Rs == 0x00);
		setStatusC((Rd & BIT0) != 0);
		setStatusV(getStatusN() ^ getStatusC());
		setStatusS(getStatusN() ^ getStatusV());
		
		dataMemory.setMemory(Rd_address, Rs);
		incrementPC();
	}
	
	protected void instruction_lsr(final int Rd_address) {
		byte Rd = dataMemory.getMemory(Rd_address);
		byte Rs = (byte)((Rd & BYTE0) >> 1);
		
		setStatusN(false);
		setStatusZ(Rs == 0x00);
		setStatusC((Rd & BIT0) != 0);
		setStatusV(getStatusN() ^ getStatusC());
		setStatusS(getStatusN() ^ getStatusV());
		
		dataMemory.setMemory(Rd_address, Rs);
		incrementPC();
	}
	
	protected void instruction_ror(final int Rd_address) {
		byte Rd = dataMemory.getMemory(Rd_address);
		byte Rs = getStatusC() ? (byte)((Rd >> 1) & BYTE0) : (byte)(((Rd >> 1) & BYTE0) | BIT7);
		
		setStatusN((Rs & BIT7) != 0);
		setStatusZ(Rs == 0x00);
		setStatusC((Rd & BIT0) != 0);
		setStatusV(getStatusN() ^ getStatusC());
		setStatusS(getStatusN() ^ getStatusV());
		
		dataMemory.setMemory(Rd_address, Rs);
		incrementPC();
	}
	
	/* SET STATUS BITS */
	protected void instruction_sec() {
		setStatusC(true);
		incrementPC();
	}
	protected void instruction_sez() {
		setStatusZ(true);
		incrementPC();
	}
	protected void instruction_sen() {
		setStatusN(true);
		incrementPC();
	}
	protected void instruction_sev() {
		setStatusV(true);
		incrementPC();
	}
	protected void instruction_ses() {
		setStatusS(true);
		incrementPC();
	}
	protected void instruction_seh() {
		setStatusH(true);
		incrementPC();
	}
	protected void instruction_set() {
		setStatusT(true);
		incrementPC();
	}
	protected void instruction_sei() {
		setStatusI(true);
		incrementPC();
	}
	
	/* CLEAR STATUS BITS */
	protected void instruction_clc() {
		setStatusC(false);
		incrementPC();
	}
	protected void instruction_clz() {
		setStatusZ(false);
		incrementPC();
	}
	protected void instruction_cln() {
		setStatusN(false);
		incrementPC();
	}
	protected void instruction_clv() {
		setStatusV(false);
		incrementPC();
	}
	protected void instruction_cls() {
		setStatusS(false);
		incrementPC();
	}
	protected void instruction_clh() {
		setStatusH(false);
		incrementPC();
	}
	protected void instruction_clt() {
		setStatusT(false);
		incrementPC();
	}
	protected void instruction_cli() {
		setStatusI(false);
		incrementPC();
	}
	
	protected void instruction_ret() {
		byte byteA = pop(); // MSB
		byte byteB = pop(); // LSB
		
		// TODO :FUTURE: which byte is popped off first?
		setPC(((byteA << 8) & BYTE1) | (byteB & BYTE0));
		
		setWaitCycles(3);
	}
	
	protected void instruction_reti() {
		byte byteA = pop(); // MSB
		byte byteB = pop(); // LSB
		
		// TODO :FUTURE: which byte is popped off first?
		setPC(((byteA << 8) & BYTE1) | (byteB & BYTE0));
		
		setStatusI(true);
		
		setWaitCycles(3);
	}
	
	protected void instruction_sleep() { /* TODO :FUTURE: sleep instruction */ }
	
	protected void instruction_wdr() { /* TODO :FUTURE: watchdog reset instruction */ }
	
	protected void instruction_lpm() {
		int position = getRegisterZ();
		// adjust for the big/little endian
		position += (position % 2 == 1) ? -1 : 1;
		dataMemory.setMemory(0, programCode[position]);
		
		incrementPC();
		setWaitCycles(2);
	}
	
	protected void instruction_icall() {
		// add one to the program counter before pushing
		incrementPC();
		// push the program counter
		push((byte)(programCounter & BYTE0));
		push((byte)((programCounter & BYTE1) >> 8));

		// set the program counter
		setPC(getRegisterZ());
		setWaitCycles(2);
	}
	
	protected void instruction_ijmp() {
		setPC(getRegisterZ());
		setWaitCycles(1);
	}
	
	protected void instruction_dec(final int Rd_address) {
		byte Rs = (byte)(dataMemory.getMemory(Rd_address) - 1);
		
		setStatusV((Rs & BYTE0) == 0x7F);
		setStatusN((Rs & BIT7) != 0);
		setStatusZ(Rs == 0x00);
		setStatusS(getStatusN() ^ getStatusV());
		
		dataMemory.setMemory(Rd_address, Rs);
		incrementPC();
	}
	
	protected void instruction_cbi(final int A, final int b) {
		// AND with the inverse of 1 shifted up b times (move the bit into the correct position)
		dataMemory.setMemory(A, (byte)((dataMemory.getMemory(A) & (~(1 << b))) & BYTE0));
		setWaitCycles(1);
		incrementPC();
	}
	
	protected void instruction_sbi(final int A, final int b) {
		// OR with 1 shifted up b times (move the bit into the correct position)
		dataMemory.setMemory(A, (byte)((dataMemory.getMemory(A) & BYTE0) | (1<<b)));
		setWaitCycles(1);
		incrementPC();
	}
	
	protected void instruction_adiw(int d, int K) {
		int number = ((dataMemory.getMemory(d+1) & BYTE0) << 8) | (dataMemory.getMemory(d) & BYTE0);
		int result = number + K;
		
		setStatusC(((result & 0x8000) == 0) && ((number & 0x8000) != 0));
		setStatusV(((result & 0x8000) != 0) && ((number & 0x8000) == 0));
		setStatusN((result & 0x8000) != 0);
		setStatusZ((result & 0xFFFF) == 0);
		setStatusS(getStatusN() ^ getStatusV());
		
		dataMemory.setMemory(d, (byte)(result & 0x00FF));
		dataMemory.setMemory(d+1, (byte)((result & 0xFF00) >> 8));
		
		setWaitCycles(1);
		incrementPC();
	}
	
	protected void instruction_sbiw(int d, int K) {
		int number = ((dataMemory.getMemory(d+1) & BYTE0) << 8) | (dataMemory.getMemory(d) & BYTE0);
		int result = number - K;
		
		setStatusC(((result & 0x8000) != 0) && ((number & 0x8000) == 0));
		setStatusV(((result & 0x8000) == 0) && ((number & 0x8000) != 0));
		setStatusN((result & 0x8000) != 0);
		setStatusZ((result & 0xFFFF) == 0);
		setStatusS(getStatusN() ^ getStatusV());
		
		dataMemory.setMemory(d, (byte)(result & 0x00FF));
		dataMemory.setMemory(d+1, (byte)((result & 0xFF00) >> 8));
		
		setWaitCycles(1);
		incrementPC();
	}
	
	protected void instruction_sbic(int A, int b) {
		if(((dataMemory.getMemory(A) & BYTE0) & (1<<b)) == 0) {
			// bit is cleared, skip next instruction
			if(programMemory[programCounter+1] instanceof Instruction32Bit) {
				setPCRelative(3);
				setWaitCycles(2);
			} else {
				setPCRelative(2);
				setWaitCycles(1);
			}
		} else {
			// bit not set, act as normal
			incrementPC();
		}
	}
	
	protected void instruction_sbis(int A, int b) {
		if(((dataMemory.getMemory(A) & BYTE0) & (1<<b)) != 0) {
			// bit is set, skip next instruction
			if(programMemory[programCounter+1] instanceof Instruction32Bit) {
				setPCRelative(3);
				setWaitCycles(2);
			} else {
				setPCRelative(2);
				setWaitCycles(1);
			}
		} else {
			// bit not set, act as normal
			incrementPC();
		}
	}
	
	protected void instruction_in(final int Rd_address, final int A) {
		dataMemory.setMemory(Rd_address, dataMemory.getMemory(A));
		incrementPC();
	}
	
	protected void instruction_out(final int A, final int Rr_address) {
		dataMemory.setMemory(A, dataMemory.getMemory(Rr_address));
		incrementPC();
	}
	
	protected void instruction_rjmp(final short k) {
		setPC(programCounter + k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_rcall(final short k) {
		// add one to the program counter before pushing
		incrementPC();
		// push the program counter
		push((byte)(programCounter & BYTE0));
		push((byte)((programCounter & BYTE1) >> 8));
		
		setPCRelative(k);
		setWaitCycles(2);
	}
	
	protected void instruction_ldi(final int Rd_address, final byte K) {
		dataMemory.setMemory(Rd_address, K);
		incrementPC();
	}
	
	protected void instruction_brcs(final byte k) {
		if(getStatusS() == false) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_breq(final byte k) {
		if(getStatusZ() == false) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brvs(final byte k) {
		if(getStatusV() == false) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brmi(final byte k) {
		if(getStatusN() == false) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brlt(final byte k) {
		if(getStatusS() == false) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brts(final byte k) {
		if(getStatusT() == false) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brhs(final byte k) {
		if(getStatusH() == false) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brie(final byte k) {
		if(getStatusI() == false) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brcc(final byte k) {
		if(getStatusC() == true) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brne(final byte k) {
		if(getStatusZ() == true) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);}
	
	protected void instruction_brpl(final byte k) {
		if(getStatusN() == true) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brge(final byte k) {
		if(getStatusS() == true) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brvc(final byte k) {
		if(getStatusV() == true) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brhc(final byte k) {
		if(getStatusH() == true) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brtc(final byte k) {
		if(getStatusT() == true) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_brid(final byte k) {
		if(getStatusI() == true) {
			// don't jump
			incrementPC();
			return;
		}
		setPCRelative(k + 1);
		setWaitCycles(1);
	}
	
	protected void instruction_bld(final int Rd_address, final int b) {
		// set or clear the bit
		dataMemory.setMemory(Rd_address, getStatusT() ? (byte)((dataMemory.getMemory(Rd_address) & BYTE0) | (1 << b)) : (byte)(((dataMemory.getMemory(Rd_address) & BYTE0) & (~(1 << b))) & BYTE0));
		incrementPC();
	}
	
	protected void instruction_bst(final int Rd_address, final int b) {
		// set or clear the bit
		setStatusT(((dataMemory.getMemory(Rd_address) & BYTE0) & (1 << b)) != 0);
		incrementPC();
	}
	
	protected void instruction_sbrs(final int Rd_address, final int b) {
		// check this bit
		if(((dataMemory.getMemory(Rd_address) & BYTE0) & (1 << b)) != 0) {
			if(programMemory[programCounter+1] instanceof Instruction32Bit) {
				setPCRelative(3);
				setWaitCycles(2);
			} else {
				setPCRelative(2);
				setWaitCycles(1);
			}
		} else {
			incrementPC();
		}
	}
	
	protected void instruction_sbrc(final int Rd_address, final int b) {
		// check this bit
		if(((dataMemory.getMemory(Rd_address) & BYTE0) & (1 << b)) == 0) {
			if(programMemory[programCounter+1] instanceof Instruction32Bit) {
				setPCRelative(3);
				setWaitCycles(2);
			} else {
				setPCRelative(2);
				setWaitCycles(1);
			}
		} else {
			incrementPC();
		}
	}
	
	/** Set the amount of (extra) cycles to wait until the next instruction is executed
	 * @param numCycles the number of cycles to add (signed)
	 */
	protected void setWaitCycles(int numCycles) {
		waitCycles = numCycles;
	}
	
	/** Increment the program counter
	 */
	protected void incrementPC() {
		setPC(programCounter + 1);
	}

	/** Set the program counter to "programCounter"
	 * @param programCounter
	 */
	protected void setPC(int programCounter) {
		// ensure that overflow and underflow causes wrap
		this.programCounter = programCounter % NUM_INSTRUCTIONS;
		while(this.programCounter < 0)
			this.programCounter = NUM_INSTRUCTIONS + this.programCounter;
	}

	/** Add "offset" to the program counter
	 * @param offset	the value to add to the program counter (signed)
	 */
	protected void setPCRelative(int offset) {
		setPC(programCounter + offset);
	}
	
	/** Get the stack pointer (address)
	 * @return	the address the stack pointer contains
	 */
	protected int getStackAddress() {
		return (((dataMemory.getMemory(SPH) & BYTE0) << 8) | (dataMemory.getMemory(SPL) & BYTE0));
	}
	
	/** Increment the stack
	 */
	protected void incrementStack() {
		int newStack = getStackAddress() + 1;
		dataMemory.setMemory(SPH, (byte)((newStack & BYTE1) >> 8));
		dataMemory.setMemory(SPL, (byte)(newStack & BYTE0));
	}
	
	/** Decrement the stack
	 */
	protected void decrementStack() {
		int newStack = getStackAddress() - 1;
		dataMemory.setMemory(SPH, (byte)((newStack & BYTE1) >> 8));
		dataMemory.setMemory(SPL, (byte)(newStack & BYTE0));
	}
	
	/** Get the value in the X register
	 * @return the value of the X register as an int (lower 16 bits being the value)
	 */
	protected int getRegisterX() {
		return ((dataMemory.getMemory(X_HIGH_BYTE) << 8) | (dataMemory.getMemory(X_LOW_BYTE) & BYTE0));
	}
	
	/** Get the value in the Y register
	 * @return the value of the Y register as an int (lower 16 bits being the value)
	 */
	protected int getRegisterY() {
		return ((dataMemory.getMemory(Y_HIGH_BYTE) << 8) | (dataMemory.getMemory(Y_LOW_BYTE) & BYTE0));
	}
	
	/** Get the value in the Z register
	 * @return the value of the Z register as an int (lower 16 bits being the value)
	 */
	protected int getRegisterZ() {
		return ((dataMemory.getMemory(Z_HIGH_BYTE) << 8) | (dataMemory.getMemory(Z_LOW_BYTE) & BYTE0));
	}
	
	/** Return the value of the carry
	 * @return the current carry value
	 */
	protected int carry() {
		return (getStatusC()) ? 1 : 0;
	}
	
	/** Sets the C bit
	 * @param if set is true the C bit is set, otherwise it is cleared
	 */
	protected void setStatusC(boolean set) {
		if(set) dataMemory.setMemory(SREG, (byte)(dataMemory.getMemory(SREG) | SREG_C));
		else dataMemory.setMemory(SREG, (byte)((dataMemory.getMemory(SREG) & ~SREG_C) & BYTE0));
	}
	
	/** Gets the C bit
	 * @param if C is set true is returned, otherwise false
	 */
	protected boolean getStatusC() {
		return ((dataMemory.getMemory(SREG) & SREG_C) != 0);
	}
	
	/** Sets the Z bit
	 * @param if set is true the Z bit is set, otherwise it is cleared
	 */
	protected void setStatusZ(boolean set) {
		if(set) dataMemory.setMemory(SREG, (byte)(dataMemory.getMemory(SREG) | SREG_Z));
		else dataMemory.setMemory(SREG, (byte)((dataMemory.getMemory(SREG) & ~SREG_Z) & BYTE0));
	}
	
	/** Gets the Z bit
	 * @param if Z is set true is returned, otherwise false
	 */
	protected boolean getStatusZ() {
		return ((dataMemory.getMemory(SREG) & SREG_Z) != 0);
	}
	
	/** Sets the N bit
	 * @param if set is true the N bit is set, otherwise it is cleared
	 */
	protected void setStatusN(boolean set) {
		if(set) dataMemory.setMemory(SREG, (byte)(dataMemory.getMemory(SREG) | SREG_N));
		else dataMemory.setMemory(SREG, (byte)((dataMemory.getMemory(SREG) & ~SREG_N) & BYTE0));
	}
	
	/** Gets the N bit
	 * @param if N is set true is returned, otherwise false
	 */
	protected boolean getStatusN() {
		return ((dataMemory.getMemory(SREG) & SREG_N) != 0);
	}
	
	/** Sets the V bit
	 * @param if set is true the V bit is set, otherwise it is cleared
	 */
	protected void setStatusV(boolean set) {
		if(set) dataMemory.setMemory(SREG, (byte)(dataMemory.getMemory(SREG) | SREG_V));
		else dataMemory.setMemory(SREG, (byte)((dataMemory.getMemory(SREG) & ~SREG_V) & BYTE0));
	}
	
	/** Gets the V bit
	 * @param if V is set true is returned, otherwise false
	 */
	protected boolean getStatusV() {
		return ((dataMemory.getMemory(SREG) & SREG_V) != 0);
	}
	
	/** Sets the S bit
	 * @param if set is true the S bit is set, otherwise it is cleared
	 */
	protected void setStatusS(boolean set) {
		if(set) dataMemory.setMemory(SREG, (byte)(dataMemory.getMemory(SREG) | SREG_S));
		else dataMemory.setMemory(SREG, (byte)((dataMemory.getMemory(SREG) & ~SREG_S) & BYTE0));
	}
	
	/** Gets the S bit
	 * @param if S is set true is returned, otherwise false
	 */
	protected boolean getStatusS() {
		return ((dataMemory.getMemory(SREG) & SREG_S) != 0);
	}
	
	/** Sets the H bit
	 * @param if set is true the H bit is set, otherwise it is cleared
	 */
	protected void setStatusH(boolean set) {
		if(set) dataMemory.setMemory(SREG, (byte)(dataMemory.getMemory(SREG) | SREG_H));
		else dataMemory.setMemory(SREG, (byte)((dataMemory.getMemory(SREG) & ~SREG_H) & BYTE0));
	}
	
	/** Gets the H bit
	 * @param if H is set true is returned, otherwise false
	 */
	protected boolean getStatusH() {
		return ((dataMemory.getMemory(SREG) & SREG_H) != 0);
	}
	
	/** Sets the T bit
	 * @param if set is true the T bit is set, otherwise it is cleared
	 */
	protected void setStatusT(boolean set) {
		if(set) dataMemory.setMemory(SREG, (byte)(dataMemory.getMemory(SREG) | SREG_T));
		else dataMemory.setMemory(SREG, (byte)((dataMemory.getMemory(SREG) & ~SREG_T) & BYTE0));
	}
	
	/** Gets the T bit
	 * @param if T is set true is returned, otherwise false
	 */
	protected boolean getStatusT() {
		return ((dataMemory.getMemory(SREG) & SREG_T) != 0);
	}
	
	/** Sets the I bit
	 * @param if set is true the I bit is set, otherwise it is cleared
	 */
	protected void setStatusI(boolean set) {
		if(set) dataMemory.setMemory(SREG, (byte)(dataMemory.getMemory(SREG) | SREG_I));
		else dataMemory.setMemory(SREG, (byte)((dataMemory.getMemory(SREG) & ~SREG_I) & BYTE0));
	}
	
	/** Gets the I bit
	 * @param if I is set true is returned, otherwise false
	 */
	protected boolean getStatusI() {
		return ((dataMemory.getMemory(SREG) & SREG_I) != 0);
	}
	
	/** Compares Rd and Rr together including the carry bit if "carry" is true
	 * @param Rd	value of the first register
	 * @param Rr	value of the second register
	 * @param carry	include carry in the comparison if true
	 * @return		the result of the compare
	 */
	protected byte compare(byte Rd, byte Rr, boolean carry) {
		// result of comparison
		byte Rs = (carry) ? (byte)(Rd - Rr - carry()) : (byte)(Rd - Rr); 
		
		// update status flags
		setStatusH(
				((Rd & BIT3) == 0 && (Rr & BIT3) != 0)
			||	((Rr & BIT3) != 0 && (Rs & BIT3) != 0)
			||	((Rs & BIT3) != 0 && (Rd & BIT3) == 0)
			);
		setStatusV(
				((Rd & BIT7) != 0 && (Rr & BIT7) == 0 && (Rs & BIT7) == 0)
			||	((Rd & BIT7) == 0 && (Rr & BIT7) != 0 && (Rs & BIT7) != 0)
			);
		setStatusN(
				((Rs & BIT7) != 0));
		// carry comparison does not set Z if zero - only clears if not zero
		if(carry) {
			if(Rs != 0x00) setStatusZ(false);
		} else {
			setStatusZ(Rs == 0x00);
		}
		setStatusC(
				((Rd & BIT7) == 0 && (Rr & BIT7) != 0)
			||	((Rr & BIT7) != 0 && (Rs & BIT7) != 0)
			||	((Rs & BIT7) != 0 && (Rd & BIT7) == 0)
			);
		setStatusS(getStatusN() ^ getStatusV());
		
		return Rs;
	}
	
	/** Adds Rd and Rr together including the carry bit if "carry" is true
	 * @param Rd	value of the first register
	 * @param Rr	value of the second register
	 * @param carry	include carry in the addition if true
	 * @return		the result of the addition
	 */
	protected byte add(byte Rd, byte Rr, boolean carry) {
		// result of comparison
		byte Rs = (carry) ? (byte)(Rd + Rr + carry()) : (byte)(Rd + Rr);
		
		// update status flags
		setStatusH(
				((Rd & BIT3) != 0 && (Rr & BIT3) != 0)
			||	((Rr & BIT3) != 0 && (Rs & BIT3) == 0)
			||	((Rs & BIT3) == 0 && (Rd & BIT3) != 0)
			);
		setStatusV(
				((Rd & BIT7) != 0 && (Rr & BIT7) != 0 && (Rs & BIT7) == 0)
			||	((Rd & BIT7) == 0 && (Rr & BIT7) == 0 && (Rs & BIT7) != 0)
			);
		setStatusN(
				((Rs & BIT7) != 0));
		setStatusZ(
				((Rs == 0x00)));
		setStatusC(
				((Rd & BIT7) != 0 && (Rr & BIT7) != 0)
			||	((Rr & BIT7) != 0 && (Rs & BIT7) == 0)
			||	((Rs & BIT7) == 0 && (Rd & BIT7) !=	 0)
			);
		setStatusS(getStatusN() ^ getStatusV());
		
		return Rs;
	}
	
	/** Subtracts Rr (and the carry if "carry is true") from Rd
	 * @param Rd	value of the first register
	 * @param Rr	value of the second register
	 * @param carry	include carry in the subtraction if true
	 * @return		the result of the subtraction
	 */
	protected byte subtract(byte Rd, byte Rr, boolean carry) {
		// result of comparison
		byte Rs = (carry) ? (byte)(Rd - Rr - carry()) : (byte)(Rd - Rr);
		
		// update status flags
		setStatusH(
				((Rd & BIT3) == 0 && (Rr & BIT3) != 0)
			||	((Rr & BIT3) != 0 && (Rs & BIT3) != 0)
			||	((Rs & BIT3) != 0 && (Rd & BIT3) == 0)
			);
		setStatusV(
				((Rd & BIT7) != 0 && (Rr & BIT7) == 0 && (Rs & BIT7) == 0)
			||	((Rd & BIT7) == 0 && (Rr & BIT7) != 0 && (Rs & BIT7) != 0)
			);
		setStatusN(
				((Rs & BIT7) != 0));
		if(carry) {
			if(Rs != 0x00) setStatusZ(false);
		} else {
			setStatusZ(Rs == 0x00);
		}
		setStatusC(
				((Rd & BIT7) == 0 && (Rr & BIT7) != 0)
			||	((Rr & BIT7) != 0 && (Rs & BIT7) != 0)
			||	((Rs & BIT7) != 0 && (Rd & BIT7) ==	0)
			);
		setStatusS(getStatusN() ^ getStatusV());
		
		return Rs;
	}
	
	/** Ands Rr and Rd
	 * @param Rd	value of the first register
	 * @param Rr	value of the second register
	 * @return		the result of the and
	 */
	protected byte and(byte Rd, byte Rr) {
		// result of comparison
		byte Rs = (byte)((Rd & BYTE0) & (Rr & BYTE0));
		
		// update status flags
		setStatusV(false);
		setStatusN(((Rs & BIT7) != 0));
		setStatusZ(((Rs == 0x00)));
		setStatusS(getStatusN() ^ getStatusV());
		
		return Rs;
	}
	
	/** Ors Rr and Rd
	 * @param Rd	value of the first register
	 * @param Rr	value of the second register
	 * @return		the result of the or
	 */
	protected byte or(byte Rd, byte Rr) {
		// result of comparison
		byte Rs = (byte)((Rd & BYTE0) | (Rr & BYTE0));
		
		// update status flags
		setStatusV(false);
		setStatusN((Rs & BIT7) != 0);
		setStatusZ(Rs == 0x00);
		setStatusS(getStatusN() ^ getStatusV());
		
		return Rs;
	}
	
	protected byte pop() {
		incrementStack();
		return dataMemory.getMemory(getStackAddress());
	}

	protected void push(byte data) {
		dataMemory.setMemory(getStackAddress(), data);
		decrementStack();
	}
	
	protected void interrupt(int address) {
		// push the program counter
		push((byte)(programCounter & BYTE0));
		push((byte)((programCounter & BYTE1) >> 8));
		
		// clear the interrupt enable flag
		setStatusI(false);
		// set the pc address
		setPC(address);
		setWaitCycles(2);
	}
}