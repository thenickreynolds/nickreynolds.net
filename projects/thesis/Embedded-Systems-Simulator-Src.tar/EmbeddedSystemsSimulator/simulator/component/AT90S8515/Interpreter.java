package simulator.component.AT90S8515;

import static simulator.component.AT90S8515.AT90S8515Consts.*;
import simulator.component.AT90S8515.instructions.Instruction;
import simulator.component.AT90S8515.instructions.Instruction32Bit;
import simulator.component.AT90S8515.instructions.Instruction32BitData;
import simulator.component.AT90S8515.instructions.InstructionInterpretationException;
import simulator.component.AT90S8515.instructions.InstructionUnsupported;
import simulator.component.AT90S8515.instructions.InstructionUnknownOrData;

public class Interpreter {
	/* NOTATION:
	 *  Rd:		Destination (and source) register in the Register File
	 *  Rr:		Source register in the register file
	 *  Rs:		Result after instruction is executed
	 *  K:		Constant data
	 *  k:		Constant address
	 *  b:		Bit in the Register File or I/O Register (3-bit)
	 *  s:		Bit in the Status Register (3-bit)
	 *  X,Y,Z:	Indirect Address Register (X=R27:R26, Y=R29:R28, Z=R31:R30)
	 *  A:		I/O location address
	 *  q:		Displacement for direct addressing (6-bit)
	 */
	// the number of the program memory in bytes
	protected static final int PROGRAM_SIZE_BYTES = 0x2000;
	
	public static Instruction[] interpret(final byte programCode[], final Core core) {
		// if the program length is odd throw an exception (instructions are 2 bytes each)
		if(programCode.length != PROGRAM_SIZE_BYTES)
			throw new IndexOutOfBoundsException("Program requires exactly " + PROGRAM_SIZE_BYTES + " bytes");
		
		// create an instruction array (2bytes per instruction)
		Instruction program[] = new Instruction[NUM_INSTRUCTIONS];
		
		// iterate over the entire instruction memory
		for(int i = 0; i < program.length; i++) {
			// decode the current program code into an instruction, give the second set of 2 bytes only if there is room
			try {
				program[i] = decodeInstruction(
						new byte[] {programCode[i * 2 + 0], programCode[i * 2 + 1]},
						(i == program.length - 1) ? null : new byte[] {programCode[i * 2 + 2], programCode[i * 2 + 3]},
						core);
			} catch (InstructionInterpretationException iie) {
				program[i] = new InstructionUnknownOrData(programCode[i * 2 + 0], programCode[i * 2 + 1]);
			}
			
			// if the last instruction was a thirty two bit instruction then skip over this one
			if(program[i] instanceof Instruction32Bit) {
				// empty instruction here
				i++;
				program[i] = new Instruction32BitData();
			}
		}
		
		return program;
	}
	
	/** this method decodes an instruction and calls the respective method to execute
	 *  - there are many redundant checks in this to ensure error detection, some of these will never
	 *    fire but in case there may be a programming error I decided to include them anyway
	 *  - all instructions should be determined in O(1) lookup time 
	 *  @param instruction	the instruction to be decoded and executed
	 *  @param data32instruction	the data after the current instruction in case this is a 32 bit instruction
	 */
	public static Instruction decodeInstruction(final byte[] instruction, final byte[] data32instruction, final Core core) {
		// instruction must be 2 bytes long
		if(instruction.length != 2)
			throw new IndexOutOfBoundsException("Instruction must be 2 bytes");
		
		switch((instruction[0] & BYTE0) & 0xF0) {
		// XXXX 0000 0000 0000
		case 0x00:
			// 0000 ???? ???? ????
			switch((instruction[0] & BYTE0) & 0x0C) {
			// 0000 XX00 0000 0000
			case 0x00:
				// NOP
				if((instruction[0] & BYTE0) != 0x00) unrecognisedCode(instruction, core); 
				return instruction_nop(instruction, core);
			case 0x04:
				// CPC
				return instruction_cpc(instruction, core);
			case 0x08:
				// SBC
				return instruction_sbc(instruction, core);
			case 0x0C:
				// LSL, ADD
				return instruction_add(instruction, core);
			default:
				unrecognisedCode(instruction, core);
			}
		case 0x10:
			// 0001 ???? ???? ????
			switch((instruction[0] & BYTE0) & 0x0C) {
			// 0000 XX00 0000 0000
			case 0x00:
				// CPSE
				return instruction_cpse(instruction, core);
			case 0x04:
				// CP
				return instruction_cp(instruction, core);
			case 0x08:
				// SUB
				return instruction_sub(instruction, core);
			case 0x0C:
				// ROL, ADC
				return instruction_adc(instruction, core);
			default:
				unrecognisedCode(instruction, core);
			}
		case 0x20:
			// 0010 ???? ???? ????
			switch((instruction[0] & BYTE0) & 0x0C) {
			// 0000 XX00 0000 0000
			case 0x00:
				// TST, AND
				return instruction_and(instruction, core);
			case 0x04:
				// CLR, EOR
				return instruction_eor(instruction, core);
			case 0x08:
				// OR
				return instruction_or(instruction, core);
			case 0x0C:
				// MOV
				return instruction_mov(instruction, core);
			default:
				unrecognisedCode(instruction, core);
			}
		case 0x30:
			// 0011 ???? ???? ????
			// CPI
			return instruction_cpi(instruction, core);
		case 0x40:
			// 0100 ???? ???? ????
			// SBCI
			return instruction_sbci(instruction, core);
		case 0x50:
			// 0101 ???? ???? ????
			// SUBI
			return instruction_subi(instruction, core);
		case 0x60:
			// 0110 ???? ???? ????
			// ORI, SBR
			return instruction_ori(instruction, core);
		case 0x70:
			// 0111 ???? ???? ????
			// ANDI, CBR
			return instruction_andi(instruction, core);
		case 0x80:
			// 1000 ???? ???? ????
			if(((instruction[0] & BYTE0) & 0x02) == 0x00) {
				// LD
				return instruction_ld(instruction, core);
			} else {
				// ST
				return instruction_st(instruction, core);
			}
		case 0x90:
			// 1001 ???? ???? ????
			switch((instruction[0] & BYTE0) & 0x0F) {
			// 0000 XXXX 0000 0000
			case 0x00:
			case 0x01:
				switch((instruction[1] & BYTE0) & 0x0F) {
				// 0000 0000 0000 XXXX
				case 0x00:
					// LDS - 32 bit instruction
					if(data32instruction.length != 2)
						throw new IndexOutOfBoundsException("Instruction was 32bit but incorrect no data32instruction supplied");
					return instruction_lds(instruction, data32instruction, core);
				case 0x01:
				case 0x09:
				case 0x02:
				case 0x0A:
				case 0x0C:
				case 0x0D:
				case 0x0E:
					// LD
					return instruction_ld(instruction, core);
				case 0x0F:
					// POP
					return instruction_pop(instruction, core);
				default:
					unrecognisedCode(instruction, core);
				}
			case 0x02:
			case 0x03:
				switch((instruction[1] & BYTE0) & 0x0F) {
				// 0000 0000 0000 XXXX
				case 0x00:
					// STS - 32 bit instruction
					if(data32instruction.length != 2)
						throw new IndexOutOfBoundsException("Instruction was 32bit but incorrect no data32instruction supplied");
					return instruction_sts(instruction, data32instruction, core);
				case 0x01:
				case 0x09:
					// ST
					return instruction_st(instruction, core);
				case 0x02:
				case 0x0A:
					// ST
					return instruction_st(instruction, core);
				case 0x0C:
					// ST
					return instruction_st(instruction, core);
				case 0x0D:
					// ST
					return instruction_st(instruction, core);
				case 0x0E:
					// ST
					return instruction_st(instruction, core);
				case 0x0F:
					// PUSH
					return instruction_push(instruction, core);
				default:
					unrecognisedCode(instruction, core);
				}
			case 0x04:
			case 0x05:
				switch((instruction[1] & BYTE0) & 0x0F) {
				// 0000 0000 0000 XXXX
				case 0x00:
					// COM
					return instruction_com(instruction, core);
				case 0x01:
					// NEG
					return instruction_neg(instruction, core);
				case 0x02:
					// SWAP
					return instruction_swap(instruction, core);
				case 0x03:
					// INC
					return instruction_inc(instruction, core);
				case 0x05:
					// ASR
					return instruction_asr(instruction, core);
				case 0x06:
					// LSR
					return instruction_lsr(instruction, core);
				case 0x07:
					// ROR
					return instruction_ror(instruction, core);
				case 0x08:
					if(((instruction[0] & BYTE0) & 0x01) == 0x00) {
						// 1001 0100 ???? 1000
						switch((instruction[1] & BYTE0) & 0xF0) {
						// 0000 0000 XXXX 0000
						case 0x00:
							// SEC
							return instruction_sec(instruction, core);
						case 0x10:
							// SEZ
							return instruction_sez(instruction, core);
						case 0x20:
							// SEN
							return instruction_sen(instruction, core);
						case 0x30:
							// SEV
							return instruction_sev(instruction, core);
						case 0x40:
							// SES
							return instruction_ses(instruction, core);
						case 0x50:
							// SEH
							return instruction_seh(instruction, core);
						case 0x60:
							// SET
							return instruction_set(instruction, core);
						case 0x70:
							// SEI
							return instruction_sei(instruction, core);
						case 0x80:
							// CLC
							return instruction_clc(instruction, core);
						case 0x90:
							// CLZ
							return instruction_clz(instruction, core);
						case 0xA0:
							// CLN
							return instruction_cln(instruction, core);
						case 0xB0:
							// CLV
							return instruction_clv(instruction, core);
						case 0xC0:
							// CLS
							return instruction_cls(instruction, core);
						case 0xD0:
							// CLH
							return instruction_clh(instruction, core);
						case 0xE0:
							// CLT
							return instruction_clt(instruction, core);
						case 0xF0:
							// CLI
							return instruction_cli(instruction, core);
						default:
							unrecognisedCode(instruction, core);
						}
					} else {
						// 1001 0101 ???? 1000
						switch((instruction[1] & BYTE0) & 0xF0) {
						// 0000 0000 XXXX 0000
						case 0x00:
							// RET
							return instruction_ret(instruction, core);
						case 0x10:
							// RETI
							return instruction_reti(instruction, core);
						case 0x80:
							// SLEEP
							return instruction_sleep(instruction, core);
						case 0xA0:
							// WDR
							return instruction_wdr(instruction, core);
						case 0xC0:
							// LPM
							return instruction_lpm(instruction, core);
						default:
							unrecognisedCode(instruction, core);
						}
					}
				case 0x09:
					if((instruction[0] & BYTE0) == 0x94 && (instruction[1] & BYTE0) == 0x09) {
						// IJMP
						return instruction_ijmp(instruction, core);
					} else if((instruction[0] & BYTE0) == 0x94 && (instruction[1] & BYTE0) == 0x09) {
						// ICALL
						return instruction_icall(instruction, core);
					} else {
						unrecognisedCode(instruction, core);
					}
				case 0x0A:
					// DEC
					return instruction_dec(instruction, core);
				default:
					unrecognisedCode(instruction, core);
				}
			case 0x06:
				// ADIW
				return instruction_adiw(instruction, core);
			case 0x07:
				// SBIW
				return instruction_sbiw(instruction, core);
			case 0x08:
				// CBI
				return instruction_cbi(instruction, core);
			case 0x09:
				// SBIC
				return instruction_sbic(instruction, core);
			case 0x0A:
				// SBI
				return instruction_sbi(instruction, core);
			case 0x0B:
				// SBIS
				return instruction_sbis(instruction, core);
			default:
				unrecognisedCode(instruction, core);
			}
		case 0xA0:
			// 1010 ???? ???? ????
			if(((instruction[0] & BYTE0) & 0x02) == 0x00) {
				// LDD
				return instruction_ldd(instruction, core);
			} else if(((instruction[0] & BYTE0) & 0x02) == 0x02) {
				// STD
				return instruction_std(instruction, core);
			} else {
				unrecognisedCode(instruction, core);
			}
		case 0xB0:
			// 1011 ???? ???? ????
			if(((instruction[0] & BYTE0) & 0x08) == 0x00) {
				// IN
				return instruction_in(instruction, core);
			} else if(((instruction[0] & BYTE0) & 0x08) == 0x08) {
				// OUT
				return instruction_out(instruction, core);
			} else {
				unrecognisedCode(instruction, core);
			}
		case 0xC0:
			// 1100 ???? ???? ????
			// RJMP
			return instruction_rjmp(instruction, core);
		case 0xD0:
			// 1101 ???? ???? ????
			// RCALL
			return instruction_rcall(instruction, core);
		case 0xE0:
			// 1110 ???? ???? ????
			// SER, LDI - same instruction
			return instruction_ldi(instruction, core);
		case 0xF0:
			// 1111 ???? ???? ????
			switch((instruction[0] & BYTE0) & 0x0C) {
			// 0000 XX00 0000 0000
			case 0x00:
				// Branch if set - BRBS is covered in other branches
				switch((instruction[1] & BYTE0) & 0x07) {
				// 0000 0000 0000 0XXX
				case 0x00:
					// BRCS, BRLO
					return instruction_brcs(instruction, core);
				case 0x01:
					// BREQ
					return instruction_breq(instruction, core);
				case 0x02:
					// BRMI
					return instruction_brmi(instruction, core);
				case 0x03:
					// BRVS
					return instruction_brvs(instruction, core);
				case 0x04:
					// BRLT
					return instruction_brlt(instruction, core);
				case 0x05:
					// BRHS
					return instruction_brhs(instruction, core);
				case 0x06:
					// BRTS
					return instruction_brts(instruction, core);
				case 0x07:
					// BRIE
					return instruction_brie(instruction, core);
				default:
					unrecognisedCode(instruction, core);
				}
			case 0x04:
				// Branch if clear - BRBC is covered in other branches
				switch((instruction[1] & BYTE0) & 0x07) {
				// 0000 0000 0000 0XXX
				case 0x00:
					// BRCC, BRSH
					return instruction_brcc(instruction, core);
				case 0x01:
					// BRNE
					return instruction_brne(instruction, core);
				case 0x02:
					// BRPL
					return instruction_brpl(instruction, core);
				case 0x03:
					// BRVC
					return instruction_brvc(instruction, core);
				case 0x04:
					// BRGE
					return instruction_brge(instruction, core);
				case 0x05:
					// BRHC
					return instruction_brhc(instruction, core);
				case 0x06:
					// BRTC
					return instruction_brtc(instruction, core);
				case 0x07:
					// BRID
					return instruction_brid(instruction, core);
				default:
					unrecognisedCode(instruction, core);
				}
			case 0x08:
				if(((instruction[1] & BYTE0) & 0x08) != 0) {
					unrecognisedCode(instruction, core);
				} else if(((instruction[0] & BYTE0) & 0x02) == 0x00) {
					// BLD
					return instruction_bld(instruction, core);
				} else if(((instruction[0] & BYTE0) & 0x02) == 0x02) {
					// BST
					return instruction_bst(instruction, core);
				} else {
					unrecognisedCode(instruction, core);
				}
			case 0x0C:
				if(((instruction[1] & BYTE0) & 0x08) != 0) {
					unrecognisedCode(instruction, core);
				} else if(((instruction[0] & BYTE0) & 0x02) == 0x00) {
					// SBRC
					return instruction_sbrc(instruction, core);
				} else if(((instruction[0] & BYTE0) & 0x02) == 0x02) {
					// SBRS
					return instruction_sbrs(instruction, core);
				} else {
					unrecognisedCode(instruction, core);
				}
			default:
				unrecognisedCode(instruction, core);
			}
		default:
			unrecognisedCode(instruction, core);
		}
		throw new InstructionInterpretationException("Could not decode instruction: " + (instruction[0] & BYTE0) + " " + (instruction[1] & BYTE0)); 
	}
	
	protected static Instruction instruction_nop(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x00 || (instruction[1] & BYTE0) != 0x00) instructionError(instruction, core);
		return new Instruction() {
			public void execute() {
				core.instruction_nop();
			}
			
			public String toString() {
				return "nop";
			}
		};
	}
	
	protected static Instruction instruction_cpc(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x04) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_cpc(Rd_address, Rr_address);
			}
			public String toString() {
				return "cpc r" + Rd_address + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_sbc(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x08) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));

		return new Instruction() {
			public void execute() {
				core.instruction_sbc(Rd_address, Rr_address);
			}
			public String toString() {
				return "sbc r" + Rd_address + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_lsl(final byte instruction[], final Core core) {
		// synonymous with add
		return instruction_add(instruction, core);
	}
	
	protected static Instruction instruction_add(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x0C) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));

		return new Instruction() {
			public void execute() {
				core.instruction_add(Rd_address, Rr_address);
			}
			public String toString() {
				return "add r" + Rd_address + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_cp(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x14) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_cp(Rd_address, Rr_address);
			}
			public String toString() {
				return "cp r" + Rd_address + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_cpse(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x10 || ((instruction[1] & BYTE0) & 0x04) != 0x00) instructionError(instruction, core);

		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_cpse(Rd_address, Rr_address);
			}
			public String toString() {
				return "cpse r" + Rd_address + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_sub(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x18) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_sub(Rd_address, Rr_address);
			}
			public String toString() {
				return "sub r" + Rd_address + ", r" + Rr_address;
			}
		};	
	}
	
	protected static Instruction instruction_adc(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x1C) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_adc(Rd_address, Rr_address);
			}
			public String toString() {
				return "adc r" + Rd_address + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_rol(final byte instruction[], final Core core) {
		// synonymous with adc
		return instruction_adc(instruction, core);
	}
	
	protected static Instruction instruction_tst(final byte instruction[], final Core core) {
		// synonymous with and
		return instruction_and(instruction, core);
	}
	
	protected static Instruction instruction_and(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x20) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_and(Rd_address, Rr_address);
			}
			public String toString() {
				return "and r" + Rd_address + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_eor(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x24) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_eor(Rd_address, Rr_address);
			}
			public String toString() {
				return "eor r" + Rd_address + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_clr(final byte instruction[], final Core core) {
		// synonymous with eor
		return instruction_eor(instruction, core);
	}
	
	protected static Instruction instruction_or(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x28) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_or(Rd_address, Rr_address);
			}
			public String toString() {
				return "or r" + Rd_address + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_mov(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0x2C) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT1) << 3) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_mov(Rd_address, Rr_address);
			}
			public String toString() {
				return "mov r" + Rd_address + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_cpi(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xF0) != 0x30) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = (((instruction[1] & BYTE0) & 0xF0) >> 4) + 0x10;
		final byte K = (byte)((((instruction[0] & BYTE0) & 0x0F) << 4) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_cpi(Rd_address, K);
			}
			public String toString() {
				return "cpi r" + Rd_address + ", " + K;
			}
		};
	}
	
	protected static Instruction instruction_sbci(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xF0) != 0x40) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = (((instruction[1] & BYTE0) & 0xF0) >> 4) + 0x10;
		final byte K = (byte)((((instruction[0] & BYTE0) & 0x0F) << 4) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_sbci(Rd_address, K);
			}
			public String toString() {
				return "sbci r" + Rd_address + ", " + K;
			}
		};
	}
	
	protected static Instruction instruction_subi(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xF0) != 0x50) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = (((instruction[1] & BYTE0) & 0xF0) >> 4) + 0x10;
		final byte K = (byte)((((instruction[0] & BYTE0) & 0x0F) << 4) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_subi(Rd_address, K);
			}
			public String toString() {
				return "subi r" + Rd_address + ", " + K;
			}
		};
	}
	
	protected static Instruction instruction_sbr(final byte instruction[], final Core core) {
		// synonymous with ori
		return instruction_ori(instruction, core);
	}
	
	protected static Instruction instruction_ori(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xF0) != 0x60) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = (((instruction[1] & BYTE0) & 0xF0) >> 4) + 0x10;
		final byte K = (byte)((((instruction[0] & BYTE0) & 0x0F) << 4) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_ori(Rd_address, K);
			}
			public String toString() {
				return "ori r" + Rd_address + ", " + K;
			}
		};
	}
	
	protected static Instruction instruction_andi(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xF0) != 0x70) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = (((instruction[1] & BYTE0) & 0xF0) >> 4) + 0x10;
		final byte K = (byte)((((instruction[0] & BYTE0) & 0x0F) << 4) | ((instruction[1] & BYTE0) & 0x0F));
		
		return new Instruction() {
			public void execute() {
				core.instruction_andi(Rd_address, K);
			}
			public String toString() {
				return "andi r" + Rd_address + ", " + K;
			}
		};
	}
	
	protected static Instruction instruction_cbr(final byte instruction[], final Core core) {
		// synonymous with andi
		return instruction_andi(instruction, core);
	}
	
	protected static Instruction instruction_ld(final byte instruction[], final Core core) {
		final int Rd_address = (((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4);
		
		if((instruction[0] & 0x10) == 0) {
			// true if this has an offset - get the register to work with (Y or Z)
			final int register = ((((instruction[1] & BYTE0) & BIT3) == 0) ? Z_LOW_BYTE : Y_LOW_BYTE);
			// get the offset value
			final int offset =
				((instruction[0] & BYTE0) & BIT5)
				| (((instruction[0] & BYTE0) & 0x0C) << 1)
				| (((instruction[1] & BYTE0) & 0x07));
			
			return new Instruction() {
				public void execute() {
					core.instruction_ldd(register, Rd_address, offset);
				}
				public String toString() {
					String returnString = "";
					returnString += (offset == 0) ? "ld " : "ldd ";
					returnString += "r" + Rd_address + ", ";
					returnString += (register == Y_LOW_BYTE) ? "Y" : "Z";
					if(offset != 0) returnString += "+" + offset;
					return returnString;
				}
			};
		}
		
		switch((instruction[1] & BYTE0) & 0x0F) {
		case 1:
			return new Instruction() {
				public void execute() {
					core.instruction_ld(Z_LOW_BYTE, Rd_address, true);
				}
				public String toString() {
					return "ld r" + Rd_address + ", Z+";
				}
			};
		case 2:
			return new Instruction() {
				public void execute() {
					core.instruction_ld(Z_LOW_BYTE, Rd_address, false);
				}
				public String toString() {
					return "ld r" + Rd_address + ", -Z";
				}
			};
		case 9:
			return new Instruction() {
				public void execute() {
					core.instruction_ld(Y_LOW_BYTE, Rd_address, true);
				}
				public String toString() {
					return "ld r" + Rd_address + ", Y+";
				}
			};
		case 10:
			return new Instruction() {
				public void execute() {
					core.instruction_ld(Y_LOW_BYTE, Rd_address, false);
				}
				public String toString() {
					return "ld r" + Rd_address + ", -Y";
				}
			};
		case 12:
			return new Instruction() {
				public void execute() {
					core.instruction_ldd(X_LOW_BYTE, Rd_address, 0);
				}
				public String toString() {
					return "ldd r" + Rd_address + ", X";
				}
			};
		case 13:
			return new Instruction() {
				public void execute() {
					core.instruction_ld(X_LOW_BYTE, Rd_address, true);
				}
				public String toString() {
					return "ld r" + Rd_address + ", X+";
				}
			};
		case 14:
			return new Instruction() {
				public void execute() {
					core.instruction_ld(X_LOW_BYTE, Rd_address, false);
				}
				public String toString() {
					return "ld r" + Rd_address + ", -X";
				}
			};
		default:
			assert false;
			break;
		}

		return new InstructionUnsupported();
	}
	
	protected static Instruction instruction_st(final byte instruction[], final Core core) {
		final int Rd_address = (((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4);
		
		if((instruction[0] & 0x10) == 0) {
			// true if this has an offset - get the register to work with (Y or Z)
			final int register = ((((instruction[1] & BYTE0) & BIT3) == 0) ? Z_LOW_BYTE : Y_LOW_BYTE);
			// get the offset value
			final int offset =
				((instruction[0] & BYTE0) & BIT5)
				| (((instruction[0] & BYTE0) & 0x0C) << 1)
				| (((instruction[1] & BYTE0) & 0x07));
			
			return new Instruction() {
				public void execute() {
					core.instruction_std(register, Rd_address, offset);
				}
				public String toString() {
					String returnString = "";
					returnString += (offset == 0) ? "st " : "std ";
					returnString += "r" + Rd_address + ", ";
					returnString += (register == Y_LOW_BYTE) ? "Y" : "Z";
					if(offset != 0) returnString += "+" + offset;
					return returnString;
				}
			};
		}
		
		switch((instruction[1] & BYTE0) & 0x0F) {
		case 1:
			return new Instruction() {
				public void execute() {
					core.instruction_st(Z_LOW_BYTE, Rd_address, true);
				}
				public String toString() {
					return "st r" + Rd_address + ", Z+";
				}
			};
		case 2:
			return new Instruction() {
				public void execute() {
					core.instruction_st(Z_LOW_BYTE, Rd_address, false);
				}
				public String toString() {
					return "st r" + Rd_address + ", -Z";
				}
			};
		case 9:
			return new Instruction() {
				public void execute() {
					core.instruction_st(Y_LOW_BYTE, Rd_address, true);
				}
				public String toString() {
					return "st r" + Rd_address + ", Y+";
				}
			};
		case 10:
			return new Instruction() {
				public void execute() {
					core.instruction_st(Y_LOW_BYTE, Rd_address, false);
				}
				public String toString() {
					return "st r" + Rd_address + ", -Y";
				}
			};
		case 12:
			return new Instruction() {
				public void execute() {
					core.instruction_std(X_LOW_BYTE, Rd_address, 0);
				}
				public String toString() {
					return "std r" + Rd_address + ", X";
				}
			};
		case 13:
			return new Instruction() {
				public void execute() {
					core.instruction_st(X_LOW_BYTE, Rd_address, true);
				}
				public String toString() {
					return "st r" + Rd_address + ", X+";
				}
			};
		case 14:
			return new Instruction() {
				public void execute() {
					core.instruction_st(X_LOW_BYTE, Rd_address, false);
				}
				public String toString() {
					return "st r" + Rd_address + ", -X";
				}
			};
		default:
			assert false;
			break;
		}

		return new InstructionUnsupported();
	}
	
	// 32 Bit Instruction
	protected static Instruction instruction_lds(final byte instruction[], final byte data32instructions[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x90 || ((instruction[1] & BYTE0) & 0x0F) != 0x00) instructionError(instruction, core);
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int k = ((data32instructions[0] & BYTE0) << 8) | (data32instructions[1] & BYTE0);
		
		return new Instruction32Bit() {
			public void execute() {
				core.instruction_lds(Rd_address, k);
			}
			public String toString() {
				return "lds r" + Rd_address + ", " + k;
			}
		};
	}
	
	// 32 Bit Instruction
	protected static Instruction instruction_sts(final byte instruction[], final byte data32instructions[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x92 || ((instruction[1] & BYTE0) & 0x0F) != 0x00) instructionError(instruction, core);
		// get the registers which we will be operating on
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int k = ((data32instructions[0] & BYTE0) << 8) | (data32instructions[1] & BYTE0);
		
		return new Instruction32Bit() {
			public void execute() {
				core.instruction_sts(Rr_address, k);
			}
			public String toString() {
				return "sts " + k + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_pop(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x90 || ((instruction[1] & BYTE0) & 0x0F) != 0x0F) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		
		return new Instruction() {
			public void execute() {
				core.instruction_pop(Rd_address);
			}
			public String toString() {
				return "pop r" + Rd_address;
			}
		};
	}
	
	protected static Instruction instruction_push(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x92 || ((instruction[1] & BYTE0) & 0x0F) != 0x0F) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		
		return new Instruction() {
			public void execute() {
				core.instruction_push(Rd_address);
			}
			public String toString() {
				return "push r" + Rd_address;
			}
		};
	}
	
	protected static Instruction instruction_neg(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x94 || ((instruction[1] & BYTE0) & 0x0F) != 0x01) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		
		return new Instruction() {
			public void execute() {
				core.instruction_neg(Rd_address);
			}
			public String toString() {
				return "neg r" + Rd_address;
			}
		};
	}
	
	protected static Instruction instruction_com(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x94 || ((instruction[1] & BYTE0) & 0x0F) != 0x00) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		
		return new Instruction() {
			public void execute() {
				core.instruction_com(Rd_address);
			}
			public String toString() {
				return "com r" + Rd_address;
			}
		};
	}
	
	protected static Instruction instruction_swap(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x94 || ((instruction[1] & BYTE0) & 0x0F) != 0x02) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		
		return new Instruction() {
			public void execute() {
				core.instruction_swap(Rd_address);
			}
			public String toString() {
				return "swap r" + Rd_address;
			}
		};
	}
	
	protected static Instruction instruction_inc(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x94 || ((instruction[1] & BYTE0) & 0x0F) != 0x03) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		
		return new Instruction() {
			public void execute() {
				core.instruction_inc(Rd_address);
			}
			public String toString() {
				return "inc r" + Rd_address;
			}
		};
	}
	
	protected static Instruction instruction_asr(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x94 || ((instruction[1] & BYTE0) & 0x0F) != 0x05) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		
		return new Instruction() {
			public void execute() {
				core.instruction_asr(Rd_address);
			}
			public String toString() {
				return "asr r" + Rd_address;
			}
		};
	}
	
	protected static Instruction instruction_lsr(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x94 || ((instruction[1] & BYTE0) & 0x0F) != 0x06) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		
		return new Instruction() {
			public void execute() {
				core.instruction_lsr(Rd_address);
			}
			public String toString() {
				return "lsr r" + Rd_address;
			}
		};
	}
	
	protected static Instruction instruction_ror(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x94 || ((instruction[1] & BYTE0) & 0x0F) != 0x07) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		
		return new Instruction() {
			public void execute() {
				core.instruction_ror(Rd_address);
			}
			public String toString() {
				return "ror r" + Rd_address;
			}
		};
	}
	
	/* SET STATUS BITS */
	protected static Instruction instruction_sec(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0x08) instructionError(instruction, core);
		
		return new Instruction() {
			public void execute() {
				core.instruction_sec();
			}
			public String toString() {
				return "sec";
			}
		};
	}
	protected static Instruction instruction_sez(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0x18) instructionError(instruction, core);
		
		return new Instruction() {
			public void execute() {
				core.instruction_sez();
			}
			public String toString() {
				return "sez";
			}
		};
	}
	protected static Instruction instruction_sen(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0x28) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_sen();
			}
			public String toString() {
				return "sen";
			}
		};
	}
	protected static Instruction instruction_sev(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0x38) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_sev();
			}
			public String toString() {
				return "sev";
			}
		};
	}
	protected static Instruction instruction_ses(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0x48) instructionError(instruction, core);
		
		return new Instruction() {
			public void execute() {
				core.instruction_ses();
			}
			public String toString() {
				return "ses";
			}
		};
	}
	protected static Instruction instruction_seh(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0x58) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_seh();
			}
			public String toString() {
				return "seh";
			}
		};
	}
	protected static Instruction instruction_set(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0x68) instructionError(instruction, core);
		
		return new Instruction() {
			public void execute() {
				core.instruction_set();
			}
			public String toString() {
				return "set";
			}
		};
	}
	protected static Instruction instruction_sei(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0x78) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_sei();
			}
			public String toString() {
				return "sei";
			}
		};
	}
	
	/* CLEAR STATUS BITS */
	protected static Instruction instruction_clc(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0x88) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_clc();
			}
			public String toString() {
				return "clc";
			}
		};
	}
	protected static Instruction instruction_clz(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0x98) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_clz();
			}
			public String toString() {
				return "clz";
			}
		};
	}
	protected static Instruction instruction_cln(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0xA8) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_cln();
			}
			public String toString() {
				return "cln";
			}
		};
	}
	protected static Instruction instruction_clv(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0xB8) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_clv();
			}
			public String toString() {
				return "clv";
			}
		};
	}
	protected static Instruction instruction_cls(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0xC8) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_cls();
			}
			public String toString() {
				return "cls";
			}
		};
	}
	protected static Instruction instruction_clh(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0xD8) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_clh();
			}
			public String toString() {
				return "clh";
			}
		};
	}
	protected static Instruction instruction_clt(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0xE8) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_clt();
			}
			public String toString() {
				return "clt";
			}
		};
	}
	protected static Instruction instruction_cli(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x94 || (instruction[1] & BYTE0) != 0xF8) instructionError(instruction, core);

		return new Instruction() {
			public void execute() {
				core.instruction_cli();
			}
			public String toString() {
				return "cli";
			}
		};
	}
	
	protected static Instruction instruction_ret(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x95 || (instruction[1] & BYTE0) != 0x08) instructionError(instruction, core);
		
		return new Instruction() {
			public void execute() {
				core.instruction_ret();
			}
			public String toString() {
				return "ret";
			}
		};
	}
	
	protected static Instruction instruction_reti(final byte instruction[], final Core core) {
		if((instruction[0] & BYTE0) != 0x95 || (instruction[1] & BYTE0) != 0x18) instructionError(instruction, core);
		
		return new Instruction() {
			public void execute() {
				core.instruction_reti();
			}
			public String toString() {
				return "reti";
			}
		};
	}
	
	protected static Instruction instruction_sleep(final byte instruction[], final Core core) {
		System.err.println("Instruction \"sleep\" not supported");
		/* TODO :FUTURE: sleep instruction */
		return new InstructionUnsupported();
	}
	
	protected static Instruction instruction_wdr(final byte instruction[], final Core core) {
		System.err.println("Instruction \"wdr\" not supported");
		/* TODO :FUTURE: watchdog reset instruction */
		return new InstructionUnsupported();
	}
	
	protected static Instruction instruction_lpm(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFF) != 0x95 || ((instruction[1] & BYTE0) & 0xFF) != 0xC8) instructionError(instruction, core);
		
		return new Instruction() {
			public void execute() {
				core.instruction_lpm();
			}
			public String toString() {
				return "lpm";
			}
		};
	}
	
	protected static Instruction instruction_icall(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFF) != 0x95 || ((instruction[1] & BYTE0) & 0xFF) != 0x09) instructionError(instruction, core);
		
		return new Instruction() {
			public void execute() {
				core.instruction_icall();
			}
			public String toString() {
				return "icall";
			}
		};
	}
	
	protected static Instruction instruction_ijmp(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFF) != 0x94 || ((instruction[1] & BYTE0) & 0xFF) != 0x09) instructionError(instruction, core);
		
		return new Instruction() {
			public void execute() {
				core.instruction_ijmp();
			}
			public String toString() {
				return "ijmp";
			}
		};
	}
	
	protected static Instruction instruction_dec(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0x94 || ((instruction[1] & BYTE0) & 0x0F) != 0x0A) instructionError(instruction, core);

		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		
		return new Instruction() {
			public void execute() {
				core.instruction_dec(Rd_address);
			}
			public String toString() {
				return "dec r" + Rd_address;
			}
		};
	}
	
	protected static Instruction instruction_cbi(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFF) != 0x98) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int A = (((instruction[1] & BYTE0) & 0xF8) >> 3) + IO_REGISTERS_OFFSET;
		final int b = ((instruction[1] & BYTE0) & 0x07);
		
		return new Instruction() {
			public void execute() {
				core.instruction_cbi(A, b);
			}
			public String toString() {
				return "cbi " + REGISTER_NAMES[A] + ", " + b;
			}
		};
	}
	
	protected static Instruction instruction_sbi(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFF) != 0x9A) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int b = ((instruction[1] & BYTE0) & 0x07);
		final int A = (((instruction[1] & BYTE0) & 0xF8) >> 3) + IO_REGISTERS_OFFSET;
		
		return new Instruction() {
			public void execute() {
				core.instruction_sbi(A, b);
			}
			public String toString() {
				return "sbi " + REGISTER_NAMES[A] + ", " + b;
			}
		};
	}
	
	protected static Instruction instruction_adiw(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFF) != 0x96) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int K = (((instruction[1] & BYTE0) & 0xC0) >> 2) | ((instruction[1] & BYTE0) & 0x0F);
		final int d = ((((instruction[1] & BYTE0) & 0x30) >> 4) * 2) + INDIRECT_REGISTERS_OFFSET;

		return new Instruction() {
			public void execute() {
				core.instruction_adiw(d, K);
			}
			public String toString() {
				return "adiw r" + d + ":r" + (d+1) + ", " + K;
			}
		};
	}
	
	protected static Instruction instruction_sbiw(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFF) != 0x97) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int K = (((instruction[1] & BYTE0) & 0xC0) >> 2) | ((instruction[1] & BYTE0) & 0x0F);
		final int d = ((((instruction[1] & BYTE0) & 0x30) >> 4) * 2) + INDIRECT_REGISTERS_OFFSET;

		return new Instruction() {
			public void execute() {
				core.instruction_sbiw(d, K);
			}
			public String toString() {
				return "sbiw r" + d + ":r" + (d+1) + ", " + K;
			}
		};
	}
	
	protected static Instruction instruction_sbic(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFF) != 0x99) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int b = ((instruction[1] & BYTE0) & 0x07);
		final int A = (((instruction[1] & BYTE0) & 0xF8) >> 3) + IO_REGISTERS_OFFSET;
		
		return new Instruction() {
			public void execute() {
				core.instruction_sbic(A, b);
			}
			public String toString() {
				return "sbic " + REGISTER_NAMES[A] + ", " + b;
			}
		};
	}
	
	protected static Instruction instruction_sbis(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFF) != 0x9B) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int b = ((instruction[1] & BYTE0) & 0x07);
		final int A = (((instruction[1] & BYTE0) & 0xF8) >> 3) + IO_REGISTERS_OFFSET;
		
		return new Instruction() {
			public void execute() {
				core.instruction_sbis(A, b);
			}
			public String toString() {
				return "sbis " + REGISTER_NAMES[A] + ", " + b;
			}
		};
	}
	
	protected static Instruction instruction_ldd(final byte instruction[], final Core core) {
		// synonymous with ld
		return instruction_ld(instruction, core);
	}
	
	protected static Instruction instruction_std(final byte instruction[], final Core core) {
		// synonymous with st
		return instruction_st(instruction, core);
	}
	
	protected static Instruction instruction_in(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xF8) != 0xB0) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int A = ((((instruction[0] & BYTE0) & 0x06) << 3) | ((instruction[1] & BYTE0) & 0x0F)) + IO_REGISTERS_OFFSET;

		return new Instruction() {
			public void execute() {
				core.instruction_in(Rd_address, A);
			}
			public String toString() {
				return "in r" + Rd_address + ", " + REGISTER_NAMES[A];
			}
		};
	}
	
	protected static Instruction instruction_out(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xF8) != 0xB8) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rr_address = ((((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4));
		final int A = ((((instruction[0] & BYTE0) & 0x06) << 3) | ((instruction[1] & BYTE0) & 0x0F)) + IO_REGISTERS_OFFSET;
		
		return new Instruction() {
			public void execute() {
				core.instruction_out(A, Rr_address);
			}
			public String toString() {
				return "out " + REGISTER_NAMES[A] + ", r" + Rr_address;
			}
		};
	}
	
	protected static Instruction instruction_rjmp(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xF0) != 0xC0) instructionError(instruction, core);
		
		/* get the constant offset - 12 bits
		 * shift it up by 4 bits to get the negative value in the correct spot for the short
		 * divide by 2^4 (=16) to get it back to what it was but now correct sign
		 * MUST be working with shorts the whole time to preserve the negative bit
		 */
		short kk = (short)((((instruction[0] & BYTE0) & 0x0F) << 8) | (instruction[1] & BYTE0));
		kk <<= 4;
		kk /= 16;
		final short k = kk;
		
		return new Instruction() {
			public void execute() {
				core.instruction_rjmp(k);
			}
			public String toString() {
				return "rjmp " + k;
			}
		};
	}
	
	protected static Instruction instruction_rcall(final byte instruction[], final Core core) {
		short kk = (short)((((instruction[0] & BYTE0) & 0x0F) << 8) | (instruction[1] & BYTE0));
		kk <<= 4;
		kk /= 16;
		final short k = kk;
		
		return new Instruction() {
			public void execute() {
				core.instruction_rcall(k);
			}
			public String toString() {
				return "rcall " + k;
			}
		};
	}
	
	protected static Instruction instruction_ser(final byte instruction[], final Core core) {
		// synonymous with ldi
		return instruction_ldi(instruction, core);
	}
	
	protected static Instruction instruction_ldi(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xF0) != 0xE0) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = (((instruction[1] & BYTE0) & 0xF0) >> 4) + 0x10;
		final byte K = (byte)((((instruction[0] & BYTE0) & 0x0F) << 4) | ((instruction[1] & BYTE0) & 0x0F));

		return new Instruction() {
			public void execute() {
				core.instruction_ldi(Rd_address, K);
			}
			public String toString() {
				return "ldi r" + Rd_address + ", " + K;
			}
		};
	}
	
	protected static Instruction instruction_brcs(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF0 || ((instruction[1] & BYTE0) & 0x07) != 0x00) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brcs(k);
			}
			public String toString() {
				return "brcs " + k;
			}
		};
	}
	
	protected static Instruction instruction_brlo(final byte instruction[], final Core core) {
		// synonymous with brcs
		return instruction_brcs(instruction, core);
	}
	
	protected static Instruction instruction_breq(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF0 || ((instruction[1] & BYTE0) & 0x07) != 0x01) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;
		
		return new Instruction() {
			public void execute() {
				core.instruction_breq(k);
			}
			public String toString() {
				return "breq " + k;
			}
		};
	}
	
	protected static Instruction instruction_brvs(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF0 || ((instruction[1] & BYTE0) & 0x07) != 0x03) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;
		
		return new Instruction() {
			public void execute() {
				core.instruction_brvs(k);
			}
			public String toString() {
				return "brvs " + k;
			}
		};
	}
	
	protected static Instruction instruction_brmi(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF0 || ((instruction[1] & BYTE0) & 0x07) != 0x02) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brmi(k);
			}
			public String toString() {
				return "brmi " + k;
			}
		};
	}
	
	protected static Instruction instruction_brlt(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF0 || ((instruction[1] & BYTE0) & 0x07) != 0x04) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;
		
		return new Instruction() {
			public void execute() {
				core.instruction_brlt(k);
			}
			public String toString() {
				return "brlt " + k;
			}
		};
	}
	
	protected static Instruction instruction_brts(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF0 || ((instruction[1] & BYTE0) & 0x07) != 0x06) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brts(k);
			}
			public String toString() {
				return "brts " + k;
			}
		};
	}
	
	protected static Instruction instruction_brhs(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF0 || ((instruction[1] & BYTE0) & 0x07) != 0x05) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;
		
		return new Instruction() {
			public void execute() {
				core.instruction_brhs(k);
			}
			public String toString() {
				return "brhs " + k;
			}
		};
	}
	
	protected static Instruction instruction_brie(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF0 || ((instruction[1] & BYTE0) & 0x07) != 0x07) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brie(k);
			}
			public String toString() {
				return "brie " + k;
			}
		};
	}
	
	protected static Instruction instruction_brcc(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF4 || ((instruction[1] & BYTE0) & 0x07) != 0x00) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brcc(k);
			}
			public String toString() {
				return "brcc " + k;
			}
		};
	}
	
	protected static Instruction instruction_brsh(final byte instruction[], final Core core) {
		// synonymous with brcc
		return instruction_brcc(instruction, core);
	}
	
	protected static Instruction instruction_brne(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF4 || ((instruction[1] & BYTE0) & 0x07) != 0x01) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brne(k);
			}
			public String toString() {
				return "brne " + k;
			}
		};
	}
	
	protected static Instruction instruction_brpl(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF4 || ((instruction[1] & BYTE0) & 0x07) != 0x02) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;
		
		return new Instruction() {
			public void execute() {
				core.instruction_brpl(k);
			}
			public String toString() {
				return "brpl " + k;
			}
		};
	}
	
	protected static Instruction instruction_brge(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF4 || ((instruction[1] & BYTE0) & 0x07) != 0x04) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brge(k);
			}
			public String toString() {
				return "brge " + k;
			}
		};
	}
	
	protected static Instruction instruction_brvc(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF4 || ((instruction[1] & BYTE0) & 0x07) != 0x03) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brvc(k);
			}
			public String toString() {
				return "brvc " + k;
			}
		};
	}
	
	protected static Instruction instruction_brhc(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF4 || ((instruction[1] & BYTE0) & 0x07) != 0x05) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brhc(k);
			}
			public String toString() {
				return "brhc " + k;
			}
		};
	}
	
	protected static Instruction instruction_brtc(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF4 || ((instruction[1] & BYTE0) & 0x07) != 0x06) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brtc(k);
			}
			public String toString() {
				return "brtc " + k;
			}
		};
	}
	
	protected static Instruction instruction_brid(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFC) != 0xF4 || ((instruction[1] & BYTE0) & 0x07) != 0x07) instructionError(instruction, core);
		
		// shift up one (get the sign in the right spot) then divide by two
		byte kk = (byte)((((instruction[0] & BYTE0) & 0x03) << 5) | (((instruction[1] & BYTE0) & 0xF8) >> 3));
		kk <<= 1;
		kk /= 2;
		final byte k = kk;

		return new Instruction() {
			public void execute() {
				core.instruction_brid(k);
			}
			public String toString() {
				return "brid " + k;
			}
		};
	}
	
	protected static Instruction instruction_bld(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0xF8 || ((instruction[1] & BYTE0) & 0x08) != 0x00) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = (((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4);
		final int b = (instruction[1] & BYTE0) & 0x7;

		return new Instruction() {
			public void execute() {
				core.instruction_bld(Rd_address, b);
			}
			public String toString() {
				return "bld r" + Rd_address + ", " + b;
			}
		};
	}
	
	protected static Instruction instruction_bst(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0xFA || ((instruction[1] & BYTE0) & 0x08) != 0x00) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = (((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4);
		final int b = (instruction[1] & BYTE0) & 0x7;

		return new Instruction() {
			public void execute() {
				core.instruction_bst(Rd_address, b);
			}
			public String toString() {
				return "bst r" + Rd_address + ", " + b;
			}
		};
	}
	
	protected static Instruction instruction_sbrs(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0xFE || ((instruction[1] & BYTE0) & 0x08) != 0x00) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = (((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4);
		final int b = (instruction[1] & BYTE0) & 0x7;

		return new Instruction() {
			public void execute() {
				core.instruction_sbrs(Rd_address, b);
			}
			public String toString() {
				return "sbrs r" + Rd_address + ", " + b;
			}
		};
	}
	
	protected static Instruction instruction_sbrc(final byte instruction[], final Core core) {
		if(((instruction[0] & BYTE0) & 0xFE) != 0xFC || ((instruction[1] & BYTE0) & 0x08) != 0x00) instructionError(instruction, core);
		
		// get the registers which we will be operating on
		final int Rd_address = (((instruction[0] & BYTE0) & BIT0) << 4) | (((instruction[1] & BYTE0) & 0xF0) >> 4);
		final int b = (instruction[1] & BYTE0) & 0x7;

		return new Instruction() {
			public void execute() {
				core.instruction_sbrc(Rd_address, b);
			}
			public String toString() {
				return "sbrc r" + Rd_address + ", " + b;
			}
		};
	}

	/** Throw an error indicating that the instruction was interpreted wrong (programming error) 
	 */
	protected static Instruction instructionError(final byte instruction[], final Core core) {
		throw new InstructionInterpretationException("Misinterpreted code: " + (instruction[0] & BYTE0) + " " + (instruction[1] & BYTE0));
	}
	
    /** Throw an error indicating that the given instruction could not be interpreted (not in this instruction set)
     */
	protected static void unrecognisedCode(byte instruction[], final Core core) throws InstructionInterpretationException {
		throw new InstructionInterpretationException("Do not recognise code: " + (instruction[0] & BYTE0) + " " + (instruction[1] & BYTE0));
	}
}