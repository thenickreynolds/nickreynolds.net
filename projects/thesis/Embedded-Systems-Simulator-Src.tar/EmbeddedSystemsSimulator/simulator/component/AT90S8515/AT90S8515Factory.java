package simulator.component.AT90S8515;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.CannotCreateComponentException;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;
import simulator.component.AT90S8515.instructions.InstructionInterpretationException;
import simulator.settings.*;

import java.io.IOException;
import java.io.File;

public class AT90S8515Factory extends ComponentFactory {
	public static final String NAME = "AT90S8515";
	public static final String PATH = "Atmel Microcontrollers";
	private ComponentGraphic ui = new AtmelGraphic();
	private Setting settings[];
	private StringSetting nameSetting;
	private FileSetting fileSetting;
	
	public AT90S8515Factory(Engine engine) {
		super(NAME, PATH, engine);
		settings = new Setting[2];
		nameSetting = new StringSetting("Name", Setting.Level.NORMAL, NAME, 1, Integer.MAX_VALUE);
		fileSetting = new FileSetting("Filename", Setting.Level.NORMAL, "hex");
		settings[0] = nameSetting;
		settings[1] = fileSetting;
	}
	
	public Setting[] getSettings() {
		return settings;
	}
	
	public Component createComponent() throws CannotCreateComponentException {
		try {
			File file = fileSetting.getValue();
			if(file == null) throw new CannotCreateComponentException("Cannot open file");
			byte data[] = HexFileParser.parseFile(file, Interpreter.PROGRAM_SIZE_BYTES);
			return new AT90S8515(nameSetting.getValue(), engine, data);
		} catch (IOException e) {
			throw new CannotCreateComponentException("Error opening intel hex file\n\n" + e.getMessage());
		} catch (InstructionInterpretationException e) {
			throw new CannotCreateComponentException("Error processing intel hex file\n\n" + e.getMessage());
		}
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	private class AtmelGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int WIDTH = 184;
		final static int HEIGHT = 30;
		
		public AtmelGraphic() {
			this.setPreferredSize(new Dimension(WIDTH+1, HEIGHT+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw outline
			g2D.drawRect(0, 0, WIDTH, HEIGHT);
			g2D.drawString("AT90S8515", WIDTH/10, 20);
		}
	}
}