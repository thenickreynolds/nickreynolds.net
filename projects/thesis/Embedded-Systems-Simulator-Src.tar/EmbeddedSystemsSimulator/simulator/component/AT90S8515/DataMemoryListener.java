package simulator.component.AT90S8515;

public interface DataMemoryListener {
	public void dataMemoryChanged(int position);
}
