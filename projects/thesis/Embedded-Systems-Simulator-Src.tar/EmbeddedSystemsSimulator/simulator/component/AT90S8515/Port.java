// TODO :FUTURE: ignore pins - to allow certain pins to be completely ignored

package simulator.component.AT90S8515;

import static simulator.component.AT90S8515.AT90S8515Consts.*;
import simulator.component.Interface;
import simulator.component.Interface.Value;

public class Port implements DataMemoryListener {
	private Interface interfaces[];
	private int ddrRegister;
	private int pinRegister;
	private int portRegister;
	private Core core;
	
	/**
	 * This is used to represent a port
	 * @param i0	Pin 0
	 * @param i1	Pin 1
	 * @param i2	Pin 2
	 * @param i3	Pin 3
	 * @param i4	Pin 4
	 * @param i5	Pin 5
	 * @param i6	Pin 6
	 * @param i7	Pin 7
	 * @param ddrRegister	The address of the DDR for this port
	 * @param pinRegister	The address of the PIN for this port
	 * @param portRegister	The address of the PORT for this port
	 * @param core	The core of the chip to which this port belongs
	 */
	public Port(Interface i0, Interface i1, Interface i2, Interface i3,
			Interface i4, Interface i5, Interface i6, Interface i7,
			int ddrRegister, int pinRegister, int portRegister, Core core) {
		interfaces = new Interface[8];
		interfaces[0] = i0;
		interfaces[1] = i1;
		interfaces[2] = i2;
		interfaces[3] = i3;
		interfaces[4] = i4;
		interfaces[5] = i5;
		interfaces[6] = i6;
		interfaces[7] = i7;
		this.ddrRegister = ddrRegister;
		this.pinRegister = pinRegister;
		this.portRegister = portRegister;
		this.core = core;
		core.dataMemory.registerListener(ddrRegister, this);
		core.dataMemory.registerListener(portRegister, this);
	}
	
	/**
	 * Updates the value of the PIN register based on current input and the DDR register
	 */
	public void updateInputs() {
		byte ddr = core.dataMemory.getMemory(ddrRegister);
		byte pins = 0x00;
		for (byte i = 0, mask = 0x01; mask != 0; i++, mask <<= 1) {
			// if this an input
			if((ddr & mask) == PORT_INPUT) {
				// set or clear the bit
				if(interfaces[i].getValue() == Value.LOGICAL_1) pins |= mask;
				else pins &= (~mask);
			}
		}
		core.dataMemory.setMemory(pinRegister, pins);
	}
	
	/**
	 * Updates the value of the interfaces based on current PORT and DDR registers
	 */
	public void updateOutputs() {
		byte ports = core.dataMemory.getMemory(portRegister);
		for (byte i = 0, mask = 0x01; mask != 0; i++, mask <<= 1) {
			// if this an output
			interfaces[i].setOutputValue(((ports & mask) != PORT_INPUT) ? Value.LOGICAL_1 : Value.LOGICAL_0); 
		}
	}
	
	/**
	 * Updates the direction of the interfaces based on the current DDR register, also updates the input pins if necessary
	 */
	public void updateDirections() {
		byte ddr = core.dataMemory.getMemory(ddrRegister);
		for (byte i = 0, mask = 0x01; mask != 0; i++, mask <<= 1) {
			interfaces[i].setDirection(((ddr & mask) == PORT_INPUT) ? Interface.INPUT : Interface.OUTPUT);
		}
		updateInputs();
	}
	
	/**
	 * This is called when monitored data memory has changed, is checks what memory was changed and reacts accordingly
	 */
	public void dataMemoryChanged(int position) {
		if(position == ddrRegister) {
			updateDirections();
		} else if(position == portRegister) {
			updateOutputs();
		} else {
			assert false;
		}
	}
	
	/**
	 * This notifies the port that pin "pin" has changed it's input value
	 * @param pin the number of the pin (0..7)
	 */
	public void interfaceValueChanged(int pin) {
		// this would only occur if the interface was set to input therefore can assume DDR agrees
		byte mask = (byte)(1 << pin); // get the bit position of this pin
		// update the register value
		if(interfaces[pin].isValue(Value.LOGICAL_1))
			// set this bit
			core.dataMemory.setMemory(pinRegister, (byte)(core.dataMemory.getMemory(pinRegister) | mask));
		else
			// clear this bit
			core.dataMemory.setMemory(pinRegister, (byte)(core.dataMemory.getMemory(pinRegister) & (~mask)));
	}
}
