package simulator.component.AT90S8515.instructions;

public abstract class Instruction {
	protected boolean breakpoint = false;
	
	/**
	 * Return the current instruction as a String
	 * @return the instruction as a String
	 */
	public abstract String toString();
	
	/**
	 * Execute the current instruction
	 */
	public abstract void execute();
	
	public boolean getBreakpoint() {
		return breakpoint;
	}
	
	public void setBreakpoint(boolean breakpoint) {
		this.breakpoint = breakpoint;
	}
	
	public void toggleBreakpoint() {
		breakpoint = !breakpoint;
	}
}
