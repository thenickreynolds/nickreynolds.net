package simulator.component.AT90S8515.instructions;

/**
 * This class is used to indicate special instructions of size 32 bit
 */
public abstract class Instruction32Bit extends Instruction {
}
