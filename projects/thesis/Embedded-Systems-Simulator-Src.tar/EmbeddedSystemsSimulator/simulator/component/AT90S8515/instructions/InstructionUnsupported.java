package simulator.component.AT90S8515.instructions;

/**
 * Represents an unsupported instruction
 */
public class InstructionUnsupported extends Instruction {
	public void execute() {}

	public String toString() {
		return "UNSUPORTED INSTRUCTION";
	}
}
