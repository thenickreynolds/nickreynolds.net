package simulator.component.AT90S8515.instructions;

public class InstructionInterpretationException extends RuntimeException {
	static final long serialVersionUID = 0;
	
	public InstructionInterpretationException(String s) {
		super(s);
	}
}
