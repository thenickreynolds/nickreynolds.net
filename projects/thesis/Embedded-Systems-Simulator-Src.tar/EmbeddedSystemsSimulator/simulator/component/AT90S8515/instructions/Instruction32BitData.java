package simulator.component.AT90S8515.instructions;

/**
 * This is the data cell of a 32 bit instruction (i.e. kkkk kkkk kkkk kkkk)
 */
public class Instruction32BitData extends Instruction {
	public void execute() {
	}
	
	public String toString() {
		return "<data of 32 bit instruction>";
	}
	
	public void setBreakpoint(boolean breakpoint) {
	}
	
	public boolean getBreakpoint() {
		return false;
	}
}
