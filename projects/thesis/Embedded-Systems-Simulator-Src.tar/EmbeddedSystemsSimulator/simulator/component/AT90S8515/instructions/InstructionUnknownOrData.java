package simulator.component.AT90S8515.instructions;

public class InstructionUnknownOrData extends Instruction {
	private byte dataA;
	private byte dataB;
	
	public InstructionUnknownOrData(byte dataA, byte dataB) {
		this.dataA = dataA;
		this.dataB = dataB;
	}

	public void execute() {
		// maybe throw an error if this occurs
		System.err.println("Attempted to execute unknown instruction or data");
	}

	public String toString() {
		return "Unknown or data: " + (dataA&0xFF) + ":" + (dataB&0xFF);
	}
}