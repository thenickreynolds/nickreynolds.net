package simulator.component.AT90S8515;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;

public class HexFileParser {
	// represents a normal line
	private final static byte DATA = 0;
	// represents the EOF
	private final static byte EOF = 1;
	// represents the extend segment address record
	private final static byte ESAR = 2;
	// the minimum length of an Intel hex file line (line with no data)
	private final static int NO_DATA_LINE_LENTH = 11;
	// the minimum length of an Intel hex file line (line with no data)
	private final static int DATA_START = 9;
	
	/** Parses the supplied file as a hex file storing and returns the result as an array of bytes.
	 * If the file is longer then an IOException will be thrown. If the file is less than size the
	 * array returned will have empty cells padded out at the end. If the number of hex values is odd
	 * the final cell will have the higher 4 bits as the final character and the lower 4 bits zeroed.
	 * This implementation ignores checksums and can only handle the following records:
	 * Data Record, End of File Record, Extended Segment Address Record.
	 * Finally, this implementation will swap the positions of each byte by one cell. It will move an
	 * even byte one cell up and an odd byte one cell down, this is to reverse big endian notation
	 * @param file	the location and name of the file to read 
	 * @param size	the size in bytes of the file to read
	 * @return	an array of bytes "size" long. Each byte represents two hex characters, any unused bytes are zeroed 
	 * @throws IOException	If the file cannot be read
	 * @throws FileNotFoundException If the file specified cannot be found
	 */
	public static byte[] parseFile(File file, int size) throws FileNotFoundException, IOException {
		if(size < 0) throw new IOException("Cannot read in less than zero bytes");
		
		// the reader of the input file
		BufferedReader reader = new BufferedReader(new FileReader(file));
		
		// the entire hex file (will be "size" long)
		byte data[] = new byte[size];
		// the current line we are up to
        int lineNumber = 0;
        // the offset that should be added to all addresses
        int dataOffset = 0;
        
		try {
			while(true) {
				// read the current line
				String line = reader.readLine();
				
				// if at the last line there was no EOF
				if(line == null)
					throw new IOException("File did not contain EOF");
				
				// keep track of the current line
				lineNumber++;
				
				// minimum bytes for a hex file line
				if(line.length() < NO_DATA_LINE_LENTH)
					throw new IOException("Does not meet minimum length on line " + lineNumber);
				// check that the first character is a colon
				if(line.charAt(0) != ':')
					throw new IOException("Does not start with ':' on line " + lineNumber);
				
				// get the length of the data
				int dataLength = parseHexString(line.substring(1, 3));
				// throw an error if the length is not correct
				if(line.length() != NO_DATA_LINE_LENTH + dataLength * 2)
					throw new IOException("Incorrect length specified on line " + lineNumber);
				
				// get the offset
				int dataAddress = parseHexString(line.substring(3, 7));
				
				// get the entry type
				int lineType = parseHexString(line.substring(7, 9));
				
				// check the line type
				if(lineType == DATA) {
					// this is data, read and store this data to the array
					// WARNING: the words are little endian, need to be swapped
					for(int pos = 0; pos < dataLength; pos ++) {
						/* get the current writing address 
						 * offset in the array + data address this line + position in line
						 */
						int byteAddress = dataOffset + dataAddress + pos;
						// handle the endian value here - if even move up, if odd move down
						byteAddress = (byteAddress % 2 == 0) ? byteAddress + 1 : byteAddress - 1;
						// get the byte
						data[byteAddress] =
							(byte)(  (toByteFromHex(line.charAt(DATA_START + pos * 2)) << 4)
									| toByteFromHex(line.charAt(DATA_START + pos * 2 + 1)));
					}
					// read all the bytes for this line - move to next
				} else if(lineType == EOF) {
					// end of file
					break;
				} else if(lineType == ESAR) {
					// extended segment address record, ensure the dataAddress is zero
					if(dataAddress != 0)
						throw new IOException("Extended Segment Address Record address value is not zero on line " + lineNumber);
					if(dataLength > 4) // greater than 4 hex characters = 2 bytes
						throw new IOException("Extended Segment Address Record offset maximum is greater than 4 bytes (not supported) on line " + lineNumber);
					// get the dataOffset
					long offsetValue = 16 * Integer.parseInt(line.substring(DATA_START, DATA_START + dataLength * 2));
					if(size < offsetValue) {
						throw new IOException("File tried to store more data than requested for on line " + lineNumber);
					}
					// we can do this safely as we know it's less than size which is an int
					dataOffset = (int)offsetValue;
				} else {
					/* do not recognise format, this may be a valid format but not supported
					 * such as:
					 *  - Start Segment Address Record
					 *  - Extended Linear Address Record
					 *  - Start Linear Address Record
					 * or newer
					 */
					throw new IOException("Can not handle format of line " + lineNumber);
				}
			}
		} catch (NumberFormatException e) {
			// this may be thrown during the above code - if it is then throw a generic exception 
			throw new IOException("Could not parse number on line " + lineNumber);
		}
		
		return data;
	}
	
	/** Parses a hex string and returns the corresponding integer
	 * @param str	the string containing the hex value
	 * @return	the number represented in the string
	 * @throws NumberFormatException if the string is not a valid hex number
	 */
	private static int parseHexString(String str) throws NumberFormatException {
		return Integer.parseInt(str, 16);
	}
	
	private static byte toByteFromHex(char c) {
		return (byte)parseHexString(c + "");
	}
}
