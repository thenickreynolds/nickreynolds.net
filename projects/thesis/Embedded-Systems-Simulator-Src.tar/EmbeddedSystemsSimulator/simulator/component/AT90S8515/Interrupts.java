package simulator.component.AT90S8515;

import static simulator.component.AT90S8515.AT90S8515Consts.*;

public class Interrupts implements DataMemoryListener {
	// the core processing unit
	private Core core;
	// the global interrupt flag
	private boolean globalInterruptsEnabled;
	/* this is set when an interrupt is triggered but not cleared
	 *  when it is true then all interrupt flags must be checked
	 *  when this is false then there are no interrupts to check
	 *  thus it should save some time
	 */
	private boolean interruptTriggered;
	
	// TODO reset interrupt - add check and to updateInterrupts below
	//private boolean resetTriggered;				// vector 0x00
	private boolean external0Triggered;				// vector 0x01
	private boolean external1Triggered;				// vector 0x02
	private boolean timer1CaptureTriggered;			// vector 0x03
	private boolean timer1CompareATriggered;		// vector 0x04
	private boolean timer1CompareBTriggered;		// vector 0x05
	private boolean timer1OverflowTriggered;		// vector 0x06
	private boolean timer0OverflowTriggered;		// vector 0x07
	// TODO spi transfer complete interrupt - add check and to updateInterrupts below
	//private boolean spiTransferCompleteTriggered;	// vector 0x08
	private boolean UARTReceiveCompleteTriggered;	// vector 0x09
	private boolean UARTEmptyTriggered;				// vector 0x0A
	private boolean UARTTransmitCompleteTriggered;	// vector 0x0B
	// TODO analouge compare interrupt - add check and to updateInterrupts below
	//private boolean analougeCompareTriggered;		// vector 0x0C
	// execute this interrupt next cycle
	private int interruptVector;
	// this is true if the interrupt vector must be executed next cycle
	private boolean executeInterrupt;
	
	public Interrupts(Core core) {
		this.core = core;
		// add data listeners
		core.dataMemory.setInterruptListener(this);
		core.dataMemory.registerListener(GIFR, this);
		core.dataMemory.registerListener(GIMSK, this);
		core.dataMemory.registerListener(TIFR, this);
		core.dataMemory.registerListener(TIMSK, this);
		core.dataMemory.registerListener(UCR, this);
		core.dataMemory.registerListener(USR, this);
		// initialise the settings
		interruptTriggered = false;
		executeInterrupt = false;
		updateGeneral();
		updateTimers();
		updateUART();
	}
	
	// trigger any interrupts queued
	public void updateInterrupts() {
		// execute any interrupts waiting from last time
		if(executeInterrupt) {
			// clear the flags
			executeInterrupt = false;
			switch(interruptVector) {
			case 0x00:
				// reset not done
				break;
			case 0x01:
				core.dataMemory.clearFlagBit(GIFR, INTF0);
				break;
			case 0x02:
				core.dataMemory.clearFlagBit(GIFR, INTF1);
				break;
			case 0x03:
				core.dataMemory.clearFlagBit(TIFR, ICF1);
				break;
			case 0x04:
				core.dataMemory.clearFlagBit(TIFR, OCF1A);
				break;
			case 0x05:
				core.dataMemory.clearFlagBit(TIFR, OCF1B);
				break;
			case 0x06:
				core.dataMemory.clearFlagBit(TIFR, TOV1);
				break;
			case 0x07:
				core.dataMemory.clearFlagBit(TIFR, TOV);
				break;
			case 0x08:
				// SPI transfer interrupt not done
				break;
			case 0x09:
				// does not clear the RXC flag
				break;
			case 0x0A:
				// does not clear the UDRE flag
				break;
			case 0x0B:
				core.dataMemory.clearFlagBit(USR, TXC);
				break;
			case 0x0C:
				// analog comparator interrupt not done
				break;
			default:
				assert false;	
			}
			// execute the interrupt
			core.interrupt(interruptVector);
			// skip others, this will clear I so no others should be triggered
			return;
		}
		
		// check to make sure interrupts are enabled and the triggered flag is set
		if(globalInterruptsEnabled && interruptTriggered) {
			// clear the interrupt triggered flag - this will be invalid after a trigger as the I flag is cleared
			interruptTriggered = false;
			/* this MUST be in the following order - this is the priority order
			 * check each interrupt, if triggered store the vector and clear the flag
			 */
			if(external0Triggered) {
				interruptVector = 0x01;
			} else if(external1Triggered) {
				interruptVector = 0x02;
			} else if(timer1CaptureTriggered) {
				interruptVector = 0x03;
			} else if(timer1CompareATriggered) {
				interruptVector = 0x04;
			} else if(timer1CompareBTriggered) {
				interruptVector = 0x05;
			} else if(timer1OverflowTriggered) {
				interruptVector = 0x06;
			} else if(timer0OverflowTriggered) {
				interruptVector = 0x07;
			} else if(UARTReceiveCompleteTriggered) {
				interruptVector = 0x09;
			} else if(UARTEmptyTriggered) {
				interruptVector = 0x0A;
			} else if(UARTTransmitCompleteTriggered) {
				interruptVector = 0x0B;
			} else {
				return;
			}
			// execute the interrupt on the next cycle
			executeInterrupt = true;
		}
	}
	
	public void dataMemoryChanged(int position) {
		/* if global interrupts aren't enabled and this isn't a call
		 * to enable them then return straight away - no point
		 */
		if(position != SREG && !globalInterruptsEnabled) return;
		
		switch(position) {
		case SREG:
			updateSREG();
			break;
		case GIFR:
		case GIMSK:
			updateGeneral();
			break;
		case TIFR:
		case TIMSK:
			updateTimers();
			break;
		case UCR:
		case USR:
			updateUART();
			break;
		default:
			assert false;
		}
	}
	
	public void updateSREG() {
		boolean enableGlobalInterrupts = (((core.dataMemory.getMemory(SREG) & BYTE0) & SREG_I) != 0x00);
		
		// if this has changed then update all flags
		if(enableGlobalInterrupts != globalInterruptsEnabled) {
			// update global interrupt flag
			globalInterruptsEnabled = enableGlobalInterrupts;
			// update all other flags
			updateGeneral();
			updateTimers();
			updateUART();
		}
	}
	
	
	
	public void updateGeneral() {
		// get the flags and enable mask
		byte gifr = core.dataMemory.getMemory(GIFR);
		byte gimsk = core.dataMemory.getMemory(GIMSK);
		byte result = (byte)((gifr & 0xFF) & (gimsk & 0xFF));
		
		// external interrupt 0
		if((result & INTF0) != 0) external0Triggered = interruptTriggered = globalInterruptsEnabled;
		else external0Triggered = false;
		// external interrupt 1
		if((result & INTF1) != 0) external1Triggered = interruptTriggered = globalInterruptsEnabled;
		else external1Triggered = false;
	}
	
	public void updateTimers() {
		// get the flags and enable mask
		byte tifr = core.dataMemory.getMemory(TIFR);
		byte timsk = core.dataMemory.getMemory(TIMSK);
		byte result = (byte)((tifr & 0xFF) & (timsk & 0xFF));
		
		// overflow timer 1
		if((result & TOV1) != 0) timer1OverflowTriggered = interruptTriggered = globalInterruptsEnabled;
		else timer1OverflowTriggered = false;
		// output compare match A timer 1
		if((result & OCF1A) != 0) timer1CompareATriggered = interruptTriggered = globalInterruptsEnabled;
		else timer1CompareATriggered = false;
		// output compare match B timer 1
		if((result & OCF1B) != 0) timer1CompareBTriggered = interruptTriggered = globalInterruptsEnabled;
		else timer1CompareBTriggered = false;
		// input capture timer 1
		if((result & ICF1) != 0) timer1CaptureTriggered = interruptTriggered = globalInterruptsEnabled;
		else timer1CaptureTriggered = false;
		// overflow timer 0
		if((result & TOV) != 0) timer0OverflowTriggered = interruptTriggered = globalInterruptsEnabled;
		else timer0OverflowTriggered = false;
	}
	
	public void updateUART() {
		// get the flags and enable mask
		byte ucr = core.dataMemory.getMemory(UCR);
		byte usr = core.dataMemory.getMemory(USR);
		byte result = (byte)((usr & 0xFF) & (ucr & 0xFF) & UART_INTERRUPT_MASK);
		
		// UART receive complete
		if((result & RXC) != 0) UARTReceiveCompleteTriggered = interruptTriggered = globalInterruptsEnabled;
		else UARTReceiveCompleteTriggered = false;
		// UART empty
		if((result & TXC) != 0) UARTTransmitCompleteTriggered = interruptTriggered = globalInterruptsEnabled;
		else UARTEmptyTriggered = false;
		// UART transmit complete
		if((result & UDRE) != 0) UARTEmptyTriggered = interruptTriggered = globalInterruptsEnabled;
		else UARTTransmitCompleteTriggered = false;
	}
}
