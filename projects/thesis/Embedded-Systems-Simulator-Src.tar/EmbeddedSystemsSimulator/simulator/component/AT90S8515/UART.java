package simulator.component.AT90S8515;

import simulator.component.Interface;
import static simulator.component.AT90S8515.AT90S8515Consts.*;

public class UART implements DataMemoryListener {
	private Core core;
	private int shiftRegisterOut = 0;
	private int shiftRegisterIn = 0;
	private boolean sending = false;
	private boolean receiving = false;
	private boolean dataWaitingInUDR = false;
	private boolean transmit9Bits;
	private boolean transmitEnabled;
	private boolean receiveEnabled;
	private Interface transmitInterface;
	private Interface receiveInterface;
	// the baud rate (this is the same as bit rate in this case - binary) in clock ticks
	private int baudRate;
	// ticks between sending each bit
	private int ticksPerBit;
	// ticks between sampling
	private int ticksPerSample;
	// the tick that the receive is currently on
	private int receiveTick;
	// the last value read from the receive interface
	private Interface.Value lastValue;
	// the current receive bit
	private int receiveBit;
	// the receive sampling array
	private Interface.Value receiveSample[];
	// the time remaining until flagging the retrieval of UART data
	private boolean bufferedData;
	
	public UART(Core core, Interface transmitInterface, Interface receiveInterface) {
		this.core = core;
		this.transmitInterface = transmitInterface;
		this.receiveInterface = receiveInterface;
		// this will notify us when the code writes to the UDR register (to be written out to)
		core.dataMemory.registerListener(UDR, this);
		// these are for the UART settings
		core.dataMemory.registerListener(UCR, this);
		// the UART baud register
		core.dataMemory.registerListener(UBRR, this);
		// initialise all the settings
		updateSettings();
		receiveTick = 0;
		receiveBit = 0;
		bufferedData = false;
		lastValue = receiveInterface.getValue();
		receiveSample = new Interface.Value[3];
		// initialise the USR register
		core.dataMemory.setFlagBit(USR, UDRE);
	}
	
	public void updateUART() {
		// send if necessary
		if(sending && core.ticks % ticksPerBit == 0) {
			send();
		}
		
		// receive if necessary
		if(receiveEnabled && core.ticks % ticksPerSample == 0) {
			// ensure the pin in INPUT // TODO :FUTURE: this should be forced in the Port also - cannot be changed via ddr
			receiveInterface.setDirection(Interface.INPUT);
			if(receiving) {
				receive();
			} else {
				// try to detect any information
				if(receiveInterface.isValue(Interface.Value.LOGICAL_0)) {
					if(lastValue == Interface.Value.LOGICAL_1) {
						receiveTick = 0;
						receiving = true;
						receiveBit = 0;
					}
				} else lastValue = Interface.Value.LOGICAL_1;
			}
		}
	}
	
	public void send() {
		if(bufferedData) {
			// got the latest data, set flag
			core.dataMemory.setFlagBit(USR, UDRE);
			// clear the bufferedData flag
			bufferedData = false;
			// wait until next time around to send the first bit
			return;
		}
		
		// check if empty (MSB is always 1 while not empty thus compare to 0)
		if(shiftRegisterOut == 0) {
			// check sending enabled and data is waiting
			if(transmitEnabled && dataWaitingInUDR) {
				// get the next lot of data if 
				getWaitingUDR();
				// this takes a tick to happen, don't send anything yet
				return;
			} else {
				// finish sending - set flag
				core.dataMemory.setFlagBit(USR, TXC);
				sending = false;
				// not sending, return
				return;
			}
		}
		// transmit the next bit (LSB of shift register)
		transmitInterface.setOutputValue(((shiftRegisterOut & 0x01) != 0) ?
				Interface.Value.LOGICAL_1 : Interface.Value.LOGICAL_0);
		// ensure the pin is output (this is forced by UART transmit enabled)
		transmitInterface.setDirection(Interface.OUTPUT);
		// shift down
		shiftRegisterOut >>= 1;
	}
	
	public void receive() {
		// sample now
		if(receiveTick % 16 == 7) {
			// store the first sample
			receiveSample[0] = receiveInterface.getValue();
		} else if(receiveTick % 16 == 8) {
			// store the second sample
			receiveSample[1] = receiveInterface.getValue();
		} else if(receiveTick % 16 == 9) {
			// store the third sample and analyse
			receiveSample[2] = receiveInterface.getValue();
			Interface.Value v = getSampleVote();
			if(receiveBit == 0) {
				if(v != Interface.Value.LOGICAL_0) {
					// bad first bit - ignore, reset variables
					receiving = false;
				}
				shiftRegisterIn = 0;
			} else if(receiveBit == 9) {
				if(v != Interface.Value.LOGICAL_1) {
					// bad receive - stop bit not right
					core.dataMemory.setFlagBit(USR, FE);
				}
				// copy the character in
				core.dataMemory.setUDRReadRegister((byte)shiftRegisterIn);
				
				System.out.println((char)shiftRegisterIn);
				
				// set flags
				core.dataMemory.setFlagBit(USR, RXC);
				// reset the variables
				shiftRegisterIn = 0;
				receiving = false;
				receiveBit = 0;
			} else {
				// receive bit is in the middle somewhere - store it
				int mask = 1 << (receiveBit-1);
				if(v == Interface.Value.LOGICAL_1) shiftRegisterIn |= mask;
			}
			receiveBit++;
		}
		if(receiving) receiveTick++;
		else receiveTick = 0;
	}
	
	private Interface.Value getSampleVote() {
		// the number of logical 1s
		int logical_1 = 0;
		// count the logical 1s
		for(Interface.Value v : receiveSample)
			if(v == Interface.Value.LOGICAL_1) logical_1++;
		// return the majority read value
		return (logical_1 > 1) ? Interface.Value.LOGICAL_1 : Interface.Value.LOGICAL_0;
	}
	
	public void dataMemoryChanged(int position) {
		if(position == UDR) {
			// clear the send complete flag
			core.dataMemory.clearFlagBit(USR, UDRE);
			// data to be sent has been written
			if(!sending) {
				getWaitingUDR();
				// start sending if transmit is enabled
				if(transmitEnabled) sending = true;
			} else {
				dataWaitingInUDR = true;
			}
		} else if(position == UCR) {
			updateSettings();
		} else if(position == UBRR) {
			updateBaud();
		}
	}
	
	private void getWaitingUDR() {
		// get the value, shift it up one - add the stop bit
		if(transmit9Bits) {
			// get the 9th bit
			int bit9 = ((core.dataMemory.getMemory(UCR) & TXB8) != 0) ? 0x200 : 0; 
			shiftRegisterOut = bit9 | ((core.dataMemory.getUDRWriteRegister() & 0xFF) << 1) | 0x400;
		} else {
			shiftRegisterOut = ((core.dataMemory.getUDRWriteRegister() & 0xFF) << 1) | 0x200;
		}
		
		// flag that data has been received, next send tick the UDR empty flag will be set
		bufferedData = true;
		dataWaitingInUDR = false;
	}
	
	private void updateSettings() {
		byte data = core.dataMemory.getMemory(UCR);
		transmit9Bits = ((data & CHR9) != 0);
		transmitEnabled = ((data & TXEN) != 0);
		// if transmit is enabled then the pin is forced to output, otherwise whatever is in the DDR
		if(transmitEnabled) {
			// TODO :FUTURE: this should be forced in the Port also - cannot be changed via DDR
			transmitInterface.setOutputValue(Interface.Value.LOGICAL_1);
			transmitInterface.setDirection(Interface.OUTPUT);
		} else {
			transmitInterface.setDirection(((core.dataMemory.getMemory(DDRD) & DDD1) == PORT_INPUT) ? Interface.INPUT : Interface.OUTPUT);
		}
		receiveEnabled = ((data & RXEN) != 0);
	}
	
	private void updateBaud() {
		baudRate = CLOCK_SPEED /((core.dataMemory.getMemory(UBRR)+1) * 16);
		ticksPerBit = CLOCK_SPEED / baudRate;
		ticksPerSample = ticksPerBit / 16;
	}
}
