// TODO :FUTURE: must load in code, handle fuses, handle clock speed changes, load in EEPROM?

package simulator.component.AT90S8515;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import java.util.Set;

import java.util.concurrent.Semaphore;

import simulator.Engine;
import simulator.Event;
import simulator.EventAction;
import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;

import static simulator.component.AT90S8515.AT90S8515Consts.*;

public class AT90S8515 extends Component {
	private final static int PORT_A[] = {38, 37, 36, 35, 34, 33, 32, 31};
	private final static int PORT_B[] = { 0,  1,  2,  3,  4 , 5,  6,  7};
	private final static int PORT_C[] = {20, 21, 22, 23, 24, 25, 26, 27};
	private final static int PORT_D[] = { 9, 10, 11, 12, 13, 14, 15, 16};
	private Port portA;
	private Port portB;
	private Port portC;
	private Port portD;
	
	private Interface interfaces[]; 
	
	private Event tickEvent = new Event(this, 0, new EventAction() {
		public void execute() {
			clockTick();
		}});
	
	private Core core;
	private ComponentGraphic ui;
	// the clock speed of this chip
	private double clockSpeed;
	// the debug window with the breakpoints etc.
	private DebugWindow window;
	// modes of operation
	private static enum State {NORMAL, STEP};
	// the current mode of operation
	private State state = State.NORMAL;
	// the mutex for breakpoints
	private Semaphore wait = new Semaphore(0);
	// the timers for this chip
	private Timers timers;
	// the UART for this chip
	private UART uart;
	// the interrupts for this chip
	private Interrupts interrupts;
	
	public AT90S8515(String name, Engine engine, byte programMemory[]) {
		super(name, engine);
		// set to 4 MHz
		clockSpeed = Engine.TIME_MEGAHERTZ_TICK / 4.0;
		interfaces = new Interface[40];
		core = new Core(programMemory);
		for(int i = 0; i < 40; i++)
			interfaces[i] = new Interface(PIN_NAMES[i], this, Interface.INPUT);
		// TODO make any output pins output
		interfaces[INTERFACE_OC1B].setDirection(Interface.OUTPUT);
		// create the chip's timers
		timers = new Timers(core, interfaces[INTERFACE_OC1A], interfaces[INTERFACE_OC1B]);
		// create the chip's UART
		uart = new UART(core, interfaces[INTERFACE_TXD], interfaces[INTERFACE_RXD]);
		// create the interrupt handler
		interrupts = new Interrupts(core);
		/* create port objects - these port objects monitor the value of the ddr and port
		 * registers and update themselves accordingly
		 */
		portA = new Port(interfaces[PORT_A[0]], interfaces[PORT_A[1]], interfaces[PORT_A[2]], interfaces[PORT_A[3]],
				interfaces[PORT_A[4]], interfaces[PORT_A[5]], interfaces[PORT_A[6]], interfaces[PORT_A[7]],
				DDRA, PINA, PORTA, core);
		portB = new Port(interfaces[PORT_B[0]], interfaces[PORT_B[1]], interfaces[PORT_B[2]], interfaces[PORT_B[3]],
				interfaces[PORT_B[4]], interfaces[PORT_B[5]], interfaces[PORT_B[6]], interfaces[PORT_B[7]],
				DDRB, PINB, PORTB, core);
		portC = new Port(interfaces[PORT_C[0]], interfaces[PORT_C[1]], interfaces[PORT_C[2]], interfaces[PORT_C[3]],
				interfaces[PORT_C[4]], interfaces[PORT_C[5]], interfaces[PORT_C[6]], interfaces[PORT_C[7]],
				DDRC, PINC, PORTC, core);
		portD = new Port(interfaces[PORT_D[0]], interfaces[PORT_D[1]], interfaces[PORT_D[2]], interfaces[PORT_D[3]],
				interfaces[PORT_D[4]], interfaces[PORT_D[5]], interfaces[PORT_D[6]], interfaces[PORT_D[7]],
				DDRD, PIND, PORTD, core);
		ui = new AtmelGraphic();
		window = new DebugWindow(name, this, core);
		window.setVisible(true);
	}

	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public Interface[] getInterfaces() {
		return interfaces;
	}

	public void init() {
		for(int i = 0; i < 8; i ++) {
			portA.interfaceValueChanged(i);
			portB.interfaceValueChanged(i);
			portC.interfaceValueChanged(i);
			portD.interfaceValueChanged(i);
		}
		// TODO reset the core etc.
		engine.addEvent(
				new Event(this, engine.getTime() + clockSpeed, new EventAction() {
					public void execute() {
						clockTick();
					}
				}));
	}
	
	/** This ticks the clock at the given speed
	 */
	private void clockTick() {
		// TODO :FUTURE: update the watchdog timer
		// counter for the time it will be when we execute the next instruction
		double enterTime = engine.getTime();
		double time = enterTime;
		
		// while there is not another event in the engine that needs to be executed loop - this if for efficiency
		// TODO this does not conform to the timing requirements of the engine, will this work if there are others at the same time?
		while(time < engine.getNextTime() && time - enterTime < Engine.TIME_DECISECOND) {
			if((state == State.STEP && core.numWaitCycles() == 0) || core.nextIsBreakpoint()) {
				engine.breakpoint(); // notify the engine of the breakpoint
				window.hitBreakpoint(); // update debug window
				window.setVisible(true); // show in case this it was hidden
				try {
					// sleep and wait for instruction
					//wait();
					wait.acquire();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				engine.unbreakpoint();
			}
			// execute the next instruction
			core.executeNextInstruction();
			// update the UART
			uart.updateUART();
			// update the timers
			timers.updateTimers();
			// handle any interrupts caused - MUST be last
			if(core.waitCycles == 0) interrupts.updateInterrupts();
			// update our time counter
			time += clockSpeed;
		}
		
		// enqueue the next clock tick - don't create a new object, this is faster
		tickEvent.setTime(time);
		engine.addEvent(tickEvent);
	}
	
	public synchronized void step() {
		state = State.STEP;
		wait.release();
	}
	
	public synchronized void cont() {
		state = State.NORMAL;
		wait.release();
	}

	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// TODO make sure the chip is still powered and grounded
		// TODO :FUTURE: check for interrupts and clock pulses etc.
		for(int i = 0; i < 8; i++)
			if(changedInterfaces.contains(interfaces[PORT_A[i]])) portA.interfaceValueChanged(i);
		for(int i = 0; i < 8; i++)
			if(changedInterfaces.contains(interfaces[PORT_B[i]])) portB.interfaceValueChanged(i);
		for(int i = 0; i < 8; i++)
			if(changedInterfaces.contains(interfaces[PORT_C[i]])) portC.interfaceValueChanged(i);
		for(int i = 0; i < 8; i++)
			if(changedInterfaces.contains(interfaces[PORT_D[i]])) portD.interfaceValueChanged(i);
	}

	public void prepareOutputs() {
		portA.updateOutputs();
		portB.updateOutputs();
		portC.updateOutputs();
		portD.updateOutputs();
	}
	
	public void dispose() {
		window.setVisible(false);
		window.dispose();
	}

	private class AtmelGraphic extends ComponentGraphic implements MouseListener {
		public final static long serialVersionUID = 1;
		
		final static int WIDTH = 184;
		final static int HEIGHT = 30;
		
		private boolean warnedAlready = false;
		
		public AtmelGraphic() {
			this.setPreferredSize(new Dimension(WIDTH+1, HEIGHT+1));
			int spaceBetweenInterfaces = (WIDTH - (Interface.WIDTH * 20)) / 21;
			for(int i = 0; i < 20; i++) {
				registerInterface(interfaces[i], (i+1) * spaceBetweenInterfaces + (i*Interface.WIDTH), 0);
				registerInterface(interfaces[39 - i], (i+1) * spaceBetweenInterfaces + (i*Interface.WIDTH), HEIGHT-Interface.HEIGHT);
			}
			this.addMouseListener(this);
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw outline
			g2D.drawRect(0, 0, WIDTH, HEIGHT);
			g2D.drawString("AT90S8515", WIDTH/10, 20);
		}
		
		/* MouseInputListener methods */
	    public synchronized void mouseMoved(MouseEvent e) {}
	    public synchronized void mouseDragged(MouseEvent e) {}
	    public synchronized void mouseClicked(MouseEvent e) {
	    	if(!warnedAlready) {
	    		window.setVisible(true);
	    		warnedAlready = true;
	    	}
	    }
	    public synchronized void mousePressed(MouseEvent e) {}
	    public synchronized void mouseReleased(MouseEvent e) {}
	    public synchronized void mouseEntered(MouseEvent e) {}
	    public synchronized void mouseExited(MouseEvent e) {}
	}
}
