// TODO :FUTURE: temp register for 16 bit register writing, this will need to be implemented

package simulator.component.AT90S8515;

import java.util.List;
import java.util.ArrayList;

import static simulator.component.AT90S8515.AT90S8515Consts.*;

public class DataMemory {
	private byte dataMemory[];
	private List<DataMemoryListener> listeners[];
	private DataMemoryListener interruptListener = null;
	private int size;
	private byte UDRReadRegister;
	private byte UDRWriteRegister;
	private boolean UDRHasBeenRead;
	
	// the creation of the array shows a warning but the warning cannot be removed
	public DataMemory(int size) {
		this.size = size;
		dataMemory = new byte[size];
		listeners = new List[size];
		UDRReadRegister = 0;
		UDRWriteRegister = 0;
		UDRHasBeenRead = false;
	}
	
	public byte getMemory(int position) {
		if(position == UDR) {
			// special UDR register which has read and write versions
			UDRHasBeenRead = true;
			// clear the new data flag - this is cleared when this register is read
			clearFlagBit(USR, RXC);
			return UDRReadRegister;
		}
		else return dataMemory[position];
	}
	
	public void setMemory(int position, byte value) {
		byte oldValue = dataMemory[position];
		if(position == TIFR || position == GIFR || position == USR) {
			/* these act differently to all others when
			 *  they are written to it actually does a
			 *  bitwise AND with ~value
			 * simply modify the value supplied before
			 * continuing
			 */
			value = (byte)(dataMemory[position] & (~value));
		}
		if(position == UDR) {
			// special UDR register which has read and write versions
			UDRWriteRegister = value;
			// any listeners are notified of this even if the value hasn't changed
		} else {
			// return if no change
			if(dataMemory[position] == value) return;
			// set the memory
			dataMemory[position] = value;
		}
		// alert any listeners
		if(listeners[position] != null)
			for(DataMemoryListener dml : listeners[position])
				dml.dataMemoryChanged(position);
		
		// notify interrupt listener if necessary - this is for optimisation reasons
		if(position == SREG && ((value ^ oldValue) & SREG_I) != 0) {
			interruptListener.dataMemoryChanged(position);
		}
	}
	
	/**
	 * This is used to set the given bits (mask) in either
	 * the TIFR, GIFR, USR registers
	 * @param position
	 * @param mask
	 */
	public void setFlagBit(int position, int mask) {
		byte value = (byte)((dataMemory[position] & BYTE0) | mask);
		
		// return if no change
		if(dataMemory[position] == value) return;
		// set the memory
		dataMemory[position] = value;
		// alert any listeners
		if(listeners[position] != null)
			for(DataMemoryListener dml : listeners[position])
				dml.dataMemoryChanged(position);
	}
	
	/**
	 * This is used to clear the given bits (mask) in either
	 * the TIFR, GIFRm, USR registers
	 * @param position
	 * @param mask
	 */
	public void clearFlagBit(int position, int mask) {
		byte value = (byte)((dataMemory[position] & BYTE0) & ((~mask) & BYTE0));
		
		// return if no change
		if(dataMemory[position] == value) return;
		// set the memory
		dataMemory[position] = value;
		// alert any listeners
		if(listeners[position] != null)
			for(DataMemoryListener dml : listeners[position])
				dml.dataMemoryChanged(position);
	}
	
	public void registerListener(int position, DataMemoryListener listener) {
		// create the list if it is null
		if(listeners[position] == null)
			listeners[position] = new ArrayList<DataMemoryListener>(1);
		listeners[position].add(listener);
	}
	
	public void removeListener(int position, DataMemoryListener listener) {
		// return if the list doens't exist
		if(listeners[position] == null)
			return;
		listeners[position].remove(listener);
		// destroy list if empty
		if(listeners[position].isEmpty()) listeners[position] = null;
	}
	
	public int getSize() {
		return size;
	}
	
	public boolean hasUDRBeenRead() {
		return UDRHasBeenRead;
	}
	
	public void setUDRReadRegister(byte value) {
		UDRHasBeenRead = false;
		UDRReadRegister = value;
	}
	
	public byte getUDRWriteRegister() {
		return UDRWriteRegister;
	}
	
	public void setInterruptListener(DataMemoryListener interruptListener) {
		this.interruptListener = interruptListener;
	}
}
