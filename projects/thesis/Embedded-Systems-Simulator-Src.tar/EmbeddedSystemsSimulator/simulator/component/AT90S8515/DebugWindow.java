// TODO :FUTURE: allow users to input into memory table and change actual memory - remember special cases

package simulator.component.AT90S8515;

import static simulator.component.AT90S8515.AT90S8515Consts.*;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JToolBar;
import javax.swing.JScrollPane;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JComponent;

import simulator.component.AT90S8515.instructions.Instruction;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

public class DebugWindow extends JFrame {
	public static final long serialVersionUID = 0;
	private JTable codeTable;
	private JTable memoryTable;
	private JToolBar controlBar;
	private Core core;
	private AT90S8515 component;
	private JButton stepButton, continueButton;
	private boolean simulationPaused = false;
	
	public DebugWindow(String name, AT90S8515 component, Core core) {
		super("AT90S85815 Debug Window : " + name);
		this.setLayout(new BorderLayout());
		this.core = core;
		this.component = component;
		this.setMinimumSize(new Dimension(600, 400));
		this.setPreferredSize(new Dimension(600, 400));
		this.setMaximumSize(new Dimension(600, 400));
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				JOptionPane.showMessageDialog(we.getComponent(),
		    			"Closing window, to reopen click the corresponding atmel component on board",
		    			"Closing",
		    			JOptionPane.INFORMATION_MESSAGE);
				we.getComponent().setVisible(false);
			}
		});
		// create the two tables
		createCodeTable();
		createMemoryTable();
		
		controlBar = new JToolBar();
		
		stepButton = new JButton("Step");
		stepButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                step();
            }
        });
		stepButton.setEnabled(false);
		
		continueButton = new JButton("Continue");
		continueButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cont();
            }
        });
		continueButton.setEnabled(false);
		
		controlBar.add(stepButton);
		controlBar.add(continueButton);
		controlBar.setFloatable(false);
		
		this.add(controlBar, BorderLayout.NORTH);
		
		JPanel content = new JPanel(new GridLayout(1, 2));
		JPanel panel;
		
		panel = new JPanel(new BorderLayout());
		panel.setBorder(BorderFactory.createTitledBorder("Program Instructions"));
		panel.add(new JScrollPane(codeTable), BorderLayout.CENTER);
		content.add(panel);
		
		panel = new JPanel(new BorderLayout());
		panel.setBorder(BorderFactory.createTitledBorder("Data Memory"));
		panel.add(new JScrollPane(memoryTable), BorderLayout.CENTER);
		content.add(panel);
		
		this.add(content, BorderLayout.CENTER);
		pack();
		validate();
	}
	
	private void createCodeTable() {
		codeTable = new JTable(new CodeTableModel());
		codeTable.setRowSelectionAllowed(true);
		codeTable.setColumnSelectionAllowed(false);
		codeTable.setDragEnabled(false);
		codeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		codeTable.setPreferredScrollableViewportSize(new Dimension(200, 260));
        codeTable.setFillsViewportHeight(true);
		codeTable.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 2) {
					// set a breakpoint on the target line
					if(e.getSource() instanceof JTable) {
						core.programMemory[((JTable)e.getSource()).getSelectedRow()].toggleBreakpoint();
						codeTable.repaint();
					}
				}
	    	}
		});
		// for the code instructions
		codeTable.setDefaultRenderer(Instruction.class, new BreakpointCellRenderer());
		// for the place labels
		codeTable.setDefaultRenderer(String.class, new CurrentInstructionCellRenderer());
	}
	
	private void createMemoryTable() {
		memoryTable = new JTable(new MemoryTableModel());
		memoryTable.setRowSelectionAllowed(true);
		memoryTable.setColumnSelectionAllowed(false);
		memoryTable.setDragEnabled(false);
		memoryTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//memoryTable.setPreferredScrollableViewportSize(new Dimension(200, 260));
		memoryTable.setFillsViewportHeight(true);
		memoryTable.setDefaultRenderer(GraphicalByte.class, new GraphicalByteRenderer());
	}
	
	public synchronized void hitBreakpoint() {
		// flag the simulation is active again
		simulationPaused = true;
		
		// enable user input
		stepButton.setEnabled(true);
		continueButton.setEnabled(true);
		memoryTable.setEnabled(true);
		
		refreshMemoryTable();
		
		codeTable.repaint();
		updateMemoryTable();
	}
	
	private void refreshMemoryTable() {
		for(int i = 0; i < core.dataMemory.getSize(); i++) {
			((GraphicalByte)memoryTable.getValueAt(i, 1)).repaint(); new GraphicalByte(i);
		}
	}
	
	protected synchronized void step() {
		// tell the chip to step
		component.step();
	}

	protected synchronized void cont() {
		simulationPaused = false;
		// block all user input
		stepButton.setEnabled(false);
		continueButton.setEnabled(false);
		memoryTable.setEnabled(false);
		// tell the chip to continue
		component.cont();
		// repaint the chip (get rid of the current instruction colour)
		codeTable.repaint();
	}
	
	private void updateMemoryTable() {
		for(int i = 0; i < memoryTable.getRowCount(); i++) {
			((GraphicalByte)memoryTable.getValueAt(i, 1)).updateValue();
		}
		memoryTable.repaint();
	}
	
    public synchronized void mouseClicked(MouseEvent e) {
    	if(e.getClickCount() == 2) {
    		// set a breakpoint on the target line
    		if(e.getSource() instanceof JTable) {
    			core.programMemory[((JTable)e.getSource()).getSelectedRow()].toggleBreakpoint();
    			codeTable.repaint();
    		}
    	}
    }
    
	class CodeTableModel extends AbstractTableModel {
		public final static long serialVersionUID = 0;
		
	    private String[] columnNames = {"Address", "Operation"};
	    private Object[][] data;

	    public CodeTableModel() {
	    	data = new Object[core.programMemory.length][2];
	    	for(int i = 0; i < core.programMemory.length; i++) {
				data[i][0] = "0x" + Integer.toHexString(i).toUpperCase();
				data[i][1] = core.programMemory[i];
			}
	    }
	    
	    public int getColumnCount() {
	        return columnNames.length;
	    }

	    public int getRowCount() {
	        return data.length;
	    }

	    public String getColumnName(int col) {
	        return columnNames[col];
	    }

	    public Object getValueAt(int row, int col) {
	        return data[row][col];
	    }

	    /*
	     * JTable uses this method to determine the default renderer/
	     * editor for each cell.  If we didn't implement this method,
	     * then the last column would contain text ("true"/"false"),
	     * rather than a check box.
	     */
	    public Class<?> getColumnClass(int c) {
	        return getValueAt(0, c).getClass();
	    }
	    
	    /*
         * Don't need to implement this method unless your table's
         * data can change.
         */
        public void setValueAt(Object value, int row, int col) {
            data[row][col] = value;
            fireTableCellUpdated(row, col);
        }
	}
	
	public class BreakpointCellRenderer extends DefaultTableCellRenderer {
		public static final long serialVersionUID = 0;
		
	    public Component getTableCellRendererComponent(JTable table, Object value,
	    		boolean isSelected, boolean hasFocus, int row, int column) 
	    {
	        Component cell = super.getTableCellRendererComponent
	        	(table, value, isSelected, hasFocus, row, column);
	        if(value instanceof Instruction) {
	        	Instruction i = (Instruction)value;
	        	if(i.getBreakpoint()) {
	        		cell.setBackground(Color.ORANGE);
	        	} else {
	        		cell.setBackground(Color.WHITE);
	        	}
	        }
	        return cell;
	    }
	}
	
	public class CurrentInstructionCellRenderer extends DefaultTableCellRenderer {
		public static final long serialVersionUID = 0;
		
	    public Component getTableCellRendererComponent(JTable table, Object value,
	    		boolean isSelected, boolean hasFocus, int row, int column) 
	    {
	        Component cell = super.getTableCellRendererComponent
	        	(table, value, isSelected, hasFocus, row, column);
	        if(value instanceof String) {
	        	if(simulationPaused && row == core.programCounter) {
	        		cell.setBackground(Color.GREEN);
	        	} else {
	        		cell.setBackground(Color.WHITE);
	        	}
	        }
	        return cell;
	    }
	}
	
	class MemoryTableModel extends AbstractTableModel {
		public final static long serialVersionUID = 0;
		
	    private String[] columnNames = {"Address", "Value"};
	    private Object[][] data;

	    public MemoryTableModel() {
	    	data = new Object[core.dataMemory.getSize()][2];
	    	
	    	for(int i = 0; i < core.dataMemory.getSize(); i++) {
				if(i < INTERNAL_SRAM_OFFSET) {
					data[i][0] = REGISTER_NAMES[i];
				} else {
					data[i][0] = "SRAM " + (i-INTERNAL_SRAM_OFFSET);
				}
				data[i][0] = ((String)data[i][0]) + " (0x" + Integer.toHexString(i) + ")";
				//data[i][1] = toBinaryString(core.dataMemory.getMemory(i));
				data[i][1] = new GraphicalByte(i);
			}
	    }
	    
	    public int getColumnCount() {
	        return columnNames.length;
	    }

	    public int getRowCount() {
	        return data.length;
	    }

	    public String getColumnName(int col) {
	        return columnNames[col];
	    }

	    public Object getValueAt(int row, int col) {
	        return data[row][col];
	    }

	    /*
	     * JTable uses this method to determine the default renderer/
	     * editor for each cell.  If we didn't implement this method,
	     * then the last column would contain text ("true"/"false"),
	     * rather than a check box.
	     */
	    public Class<?> getColumnClass(int c) {
	        //return getValueAt(0, c).getClass();
	    	if(c == 1) return GraphicalByte.class;
	    	else return String.class;
	    }

        public void setValueAt(Object value, int row, int col) {
            data[row][col] = value;
            fireTableCellUpdated(row, col);
        }
	}
	
	class GraphicalByte extends JComponent {
		static final long serialVersionUID = 0;
		
		private int position;
		private byte value;
		boolean valueChanged = false;
		private long lastTick;
		
		public GraphicalByte(int position) {
			this.position = position;
			lastTick = core.ticks;
			setMinimumSize(new Dimension(15*8+4+20,14));
			setPreferredSize(new Dimension(15*8+4+20, 14));
			value = core.dataMemory.getMemory(position);
			setToolTipText("Value: " + (value & 0xFF) + "(0x" + Integer.toHexString(value & 0xFF) + ")");
		}
		
		public void updateValue() {
			byte newValue = core.dataMemory.getMemory(position);
			if(lastTick != core.ticks) {
				lastTick = core.ticks;
				if(newValue != value) valueChanged = true;
				else valueChanged = false;
			}
			value = newValue;
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// if the simulation is paused then update the view
			if(simulationPaused) {
				setToolTipText("Value: " + (value & 0xFF) + "(0x" + Integer.toHexString(value & 0xFF) + ")");
			}
			if(valueChanged) g2D.setColor(Color.RED);
			else g2D.setColor(Color.BLACK);
			for(int i = 7; i >= 0; i--) {
				if((value & (1 << i)) != 0) {
					g2D.fillRect(15*(8-i-1)+2, 2, 10, 10);
				} else {
					g2D.drawRect(15*(8-i-1)+2, 2, 10, 10);
				}
			}
			g2D.setColor(Color.BLACK);
			g2D.drawString(Integer.toHexString(value & 0xFF), 15*8+4, 12);
		}
	}
	
	// allows the byte graphic to be used with the memory table
	class GraphicalByteRenderer implements TableCellRenderer {
		public Component getTableCellRendererComponent(JTable table,
				Object value, boolean isSelected, boolean hasFocus, int row,
				int column) {
			if (value == null)
				return null;
			return (Component) value;
		}
	}
}