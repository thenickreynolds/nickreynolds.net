package simulator.component;

public class CannotCreateComponentException extends Exception {
	public static final long serialVersionUID = 0;
	
	public CannotCreateComponentException(String message) {
		super(message);
	}
}
