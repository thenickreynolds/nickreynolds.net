package simulator.component;

import java.util.Set;

import simulator.Engine;

/**
 * This class represents a component in the system.
 * @author Nick
 */
public abstract class Component {
	/** The name of this component */
	private String name;
	/** The name of this components class */
	private String className;
	/** The engine this component belongs to */
	protected Engine engine;
	
	/**
	 * Create a new Component.
	 * @param name	The name of the component
	 * @param engine	The engine to which this component belongs.
	 */
	protected Component(String name, Engine engine) {
		String classString = this.getClass().toString(); 
		this.name = name;
		this.className = classString.substring(classString.lastIndexOf(".")+1);
		this.engine = engine;
	}
	
	/**
	 * Get the name of the component.
	 * @return the name of the component.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Get the class name
	 * @return the name of the component class
	 */
	public String getClassName() {
		return className;
	}
	
	/**
	 * This is called to notify the component that inputs have changed value. When this is called
	 * respective actions should be added to the engine queue to change this component's state.
	 * The time at which these actions should occur is the current time + propagation delay for
	 * the action.
	 * @param changedInterfaces
	 */
	public abstract void interfaceChanged(Set<Interface> changedInterfaces);

	/**
	 * Gets all Interface objects which belong to this component.
	 * @return	An array of all interface objects belonging to this component.
	 */
	public abstract Interface[] getInterfaces();
	
	/**
	 * Set all initial values for all outputs  
	 */
	public abstract void prepareOutputs();
	
	/**
	 * This is called to initialise the component. This function must enqueue any starting events.
	 */
	public abstract void init();
	
	/**
	 * Called to dispose of the component. When this is called any additional windows must be closed, actions removed, etc.
	 */
	public abstract void dispose();
	
	/**
	 * Get the description of this component
	 * @return the string representing this component
	 */
	public String toString() {
		return name + "  [" + getClassName() + "]";
	}
	
	/**
	 * Print the state of the component in the following form (or as close as possible)<br />
	 * Component: name:type <br />
	 *  Inputs:     [name:value{, name:value}] <br />
	 *  Outputs:    [name:value{, name:value}]
	 * @return A more complete description of the component and all Interfaces. 
	 */ 
	public String getFullDescription() {
		String description =
			"Component: " + name + "[" + getClassName() + "]\n";
		String inputs =
			" Inputs:   {";
		String outputs =
			" Outputs:  {";
		for(Interface i : getInterfaces()) {
			if(i.getDirection() == Interface.INPUT)
				inputs += i.toString() + ", ";
			else
				outputs += i.toString() + ", ";
		}
		
		// remove the comma space at the end
		if(inputs.endsWith(", "))
			inputs = inputs.substring(0, inputs.length() - 2);
		inputs += "}";
		
		// remove the comma space at the end
		if(outputs.endsWith(", "))
			outputs = outputs.substring(0, outputs.length() - 2);
		outputs += "}";
		
		return description + inputs + "\n" + outputs;
	}
	
	/**
	 * Returns the interface belonging to this component with the name supplied.
	 * @param name	the name of the interface requested
	 * @return		the interface requested if it exists, otherwise null
	 */
	public Interface getInterface(String name) {
		Interface interfaces[] = getInterfaces();
		for(Interface i : interfaces)
			if(i.getName().equals(name)) return i;
		return null;
	}
	
	/**
	 * Returns the graphical representation of this component
	 * @return		a ComponentGraphic representing this component and its interfaces
	 */
	public abstract ComponentGraphic getComponentGraphic();
}
