package simulator.component;

import java.awt.Graphics;

import javax.swing.JPanel;


import java.util.List;
import java.util.ArrayList;

/**
 * This class is used to graphically represent a component. All graphical representations must
 * extend this class.
 * @author Nick
 */
public abstract class ComponentGraphic extends JPanel {
	public final static long serialVersionUID = 1;
	/** The list of Interfaces and their position belong to the component */
	private List<InterfacePosition> interfaces = new ArrayList<InterfacePosition>();
	
	/**
	 * This is called to paint the component graphic
	 */ 
	public abstract void paintComponent(Graphics g);
	
	/**
	 * This is called to register an interface with this graphic. It adds the interface
	 * to the graphic at the given coordinates.  
	 * @param i	the interface to add
	 * @param x	the vertical position of the interface
	 * @param y the horizontal position of the interface
	 */
	public void registerInterface(Interface i, int x, int y) {
		interfaces.add(new InterfacePosition(i, x, y));
		this.add(i);
		i.setLocation(x, y);
		validate();
		repaint();
	}
	
	/**
	 * Called to repaint this graphic. Also ensures the interfaces stay in their correct positions.
	 */
	public void repaint() {
		if(interfaces != null) {
			for(InterfacePosition ip : interfaces)
				ip.i.setLocation(ip.x, ip.y);
		}
		super.repaint();
	}
	
	/**
	 * Used to remove an interface from the component.
	 * @param i	The interface to remove
	 */
	public void deregisterInterface(Interface i) {
		for(InterfacePosition ip : interfaces) {
			if(ip.i == i) {
				interfaces.remove(ip);
				break;
			}
		}
		this.remove(i);
		repaint();
	}
	
	/**
	 * This class is used to store a given interface and it's position within the ComponentGraphic.
	 * @author Nick
	 */
	private class InterfacePosition {
		/** The interface */
		private Interface i;
		/** The position of the interface */
		private int x, y;
		
		/**
		 * Create a new InterfacePosition object to store the interface and it's position.
		 * @param i	The interface
		 * @param x	The horizontal position
		 * @param y The vertical position
		 */
		public InterfacePosition(Interface i, int x, int y) {
			this.i = i;
			this.x = x;
			this.y = y;
		}
	}
}