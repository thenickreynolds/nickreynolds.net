package simulator.component.UARTtoTCP;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.CannotCreateComponentException;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;
import simulator.settings.IntegerSetting;
import simulator.settings.Setting;
import simulator.settings.StringSetting;
import simulator.settings.Setting.Level;

import java.io.IOException;

public class UARTtoTCPFactory extends ComponentFactory {
	private final static String NAME = "UART to TCP";
	public static final String PATH = "Communication";
	private UARTtoTCPGraphic ui;
	private Setting settings[];
	private StringSetting nameSetting;
	private IntegerSetting baudSetting;
	private IntegerSetting portSetting;
	
	public UARTtoTCPFactory(Engine engine) {
		super(NAME, PATH, engine);
		ui = new UARTtoTCPGraphic();
		settings = new Setting[3];
		
		nameSetting = new StringSetting("Name", Level.NECESSARY, NAME);
		baudSetting = new IntegerSetting("Baud Rate", Level.NECESSARY, 4800, Integer.MAX_VALUE, Integer.MIN_VALUE);
		portSetting = new IntegerSetting("Port Number", Level.NECESSARY, 1337, 65535, 1024);
		
		settings[0] = nameSetting;
		settings[1] = baudSetting;
		settings[2] = portSetting;
	}

	public Component createComponent() throws CannotCreateComponentException {
		Component newComponent;
		try {
			newComponent = new UARTtoTCP(nameSetting.getValue(), engine, baudSetting.getValue());
		} catch (IOException e) {
			throw new CannotCreateComponentException(e.getMessage());
		}
		// increment the port number
		portSetting.setValue(Math.max(1024, (portSetting.getValue() + 1) % 65535));
		return newComponent;
	}

	public ComponentGraphic getComponentGraphic() {
		return ui;
	}

	public Setting[] getSettings() {
		return settings;
	}
	
	private class UARTtoTCPGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int WIDTH = 80;
		final static int HEIGHT = 30;
		
		public UARTtoTCPGraphic() {
			super();
			this.setPreferredSize(new Dimension(WIDTH+1, HEIGHT+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw gate outline
			g2D.drawRect(0, 0, WIDTH, HEIGHT);
			g2D.drawString(NAME, WIDTH/10, HEIGHT/2);
		}
	}
}
