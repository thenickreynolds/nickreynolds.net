// need to add a HALT option

package simulator.component.UARTtoTCP;

import java.util.Set;
import java.util.LinkedList;
import java.util.List;
import java.util.Collections;

import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.Engine;
import simulator.Event;
import simulator.EventAction;

import java.net.ServerSocket;
import java.net.Socket;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class UARTtoTCP extends Component {
	private final ServerSocket serverSocket;
	private Socket socket;
	private Thread communicationThread;
	private Interface interfaces[];
	private Interface transmitInterface;
	private Interface receiveInterface;
	private List<Byte> inputBuffer;
	private UARTtoTCPGraphic ui;
	private double timeBetweenTicks;
	private int sendTick;
	private int receiveTick;
	private int sendRegister;
	private int receiveRegister;
	private boolean sending;
	private boolean receiving;
	private int receiveBit;
	private Interface.Value receiveSample[];
	private OutputStream os;
	private Interface.Value lastValue;
	private static int port = 1337;
	private int messagesSinceError = ERROR_CUTOFF;
	private static final int ERROR_CUTOFF = 15;
	
	public UARTtoTCP(String name, Engine engine, int baud) throws IOException {
		super(name, engine);
		
		// calculate time between ticks
		timeBetweenTicks = Engine.TIME_SECOND / (baud * 16);
		
		// create the server socket
		serverSocket = new ServerSocket(port++);
		
		// create a synchronised list - this must be synchronised
		receiveSample = new Interface.Value[3];
		inputBuffer = Collections.synchronizedList(new LinkedList<Byte>());
		
		interfaces = new Interface[2];
		transmitInterface = new Interface("RXD", this, Interface.OUTPUT);
		interfaces[0] = transmitInterface;
		receiveInterface = new Interface("TXD", this, Interface.INPUT);
		interfaces[1] = receiveInterface;
		
		communicationThread = new Thread() {
			public void run() {
				try {
					while(true) {
						// blocks waiting for data
						socket = serverSocket.accept();
						// connected TODO :FUTURE: show graphically
						// read data in
						InputStream is = socket.getInputStream();
						os = socket.getOutputStream();
						int data;
						while((data = is.read()) >= 0) {
							// store the new byte in the inputBuffer
							inputBuffer.add((byte)data);
						}
						os = null;
						// server disconnected
						// TODO :FUTURE: show graphically
					}
				} catch (IOException e) {
					// connection closed
				}
			}
		};
		
		ui = new UARTtoTCPGraphic(name);
		communicationThread.start();
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}

	public Interface[] getInterfaces() {
		return interfaces;
	}

	public void init() {
		engine.addEvent(
				new Event(this, engine.getTime() + timeBetweenTicks, new EventAction() {
					public void execute() {
						tick();
					}
				}));
		sendTick = 0;
		receiveTick = 0;
		sendRegister = 0;
		receiveRegister = 0;
		receiveBit = 0;
		sending = false;
		receiving = false;
		lastValue = receiveInterface.getValue();
	}
	
	public void tick() {
		// send and receive
		if(receiving) {
			receive();
		} else {
			// try to detect any information
			if(receiveInterface.isValue(Interface.Value.LOGICAL_0)) {
				if(lastValue == Interface.Value.LOGICAL_1) {
					receiveTick = 0;
					receiving = true;
					receiveBit = 0;
				}
			} else lastValue = Interface.Value.LOGICAL_1;
		}
		
		if(sendTick % 16 == 0) {
			// send next bit
			if(sending) {
				sendNextBit();
			} else {
				if(inputBuffer.size() > 0) {
					// prepare the next character for sending
					byte load = inputBuffer.remove(0);
					// add header and footer
					sendRegister = 0x200 | ((load & 0xFF) << 1);
					// send the first bit
					sendNextBit();
					sending = true;
				}
			}
		}
		
		sendTick++;
		
		engine.addEvent(
				new Event(this, engine.getTime() + timeBetweenTicks, new EventAction() {
					public void execute() {
						tick();
					}
				}));
	}
	
	private void receive() {
		// sample now
		if(receiveTick % 16 == 7) {
			// store the first sample
			receiveSample[0] = receiveInterface.getValue();
		} else if(receiveTick % 16 == 8) {
			// store the second sample
			receiveSample[1] = receiveInterface.getValue();
		} else if(receiveTick % 16 == 9) {
			// store the third sample and analyse
			receiveSample[2] = receiveInterface.getValue();
			Interface.Value v = getSampleVote();
			if(receiveBit == 0) {
				if(v != Interface.Value.LOGICAL_0) {
					// bad first bit - ignore, reset variables
					receiving = false;
				}
				receiveRegister = 0;
			} else if(receiveBit == 9) {
				if(v != Interface.Value.LOGICAL_1) {
					// bad receive - stop bit not right, reset messages since error
					messagesSinceError = 0;
				} else {
					// decrement messagesSinceError
					if(messagesSinceError < ERROR_CUTOFF) messagesSinceError++;
				}
				// send the character to the connection either way
				try {
					// send to the receiver
					os.write(receiveRegister);
				} catch (Exception e) {
					// TODO :FUTURE: cannot send - show graphically
				}
				// reset the variables
				receiveRegister = 0;
				receiving = false;
			} else {
				// receive bit is in the middle somewhere - store it
				int mask = 1 << (receiveBit-1);
				if(v == Interface.Value.LOGICAL_1) receiveRegister |= mask;
			}
			receiveBit++;
		}
		if(receiving) receiveTick++;
		else receiveTick = 0;
	}

	private Interface.Value getSampleVote() {
		// the number of logical 1s
		int logical_1 = 0;
		// count the logical 1s
		for(Interface.Value v : receiveSample)
			if(v == Interface.Value.LOGICAL_1) logical_1++;
		// return the majority read value
		return (logical_1 > 1) ? Interface.Value.LOGICAL_1 : Interface.Value.LOGICAL_0;
	}
	
	private void sendNextBit() {
		transmitInterface.setOutputValue(((sendRegister & 0x01) != 0) ?
				Interface.Value.LOGICAL_1 :
					Interface.Value.LOGICAL_0);
		sendRegister >>= 1;
		// if the send register is empty then stop sending
		if(sendRegister == 0) sending = false;
	}
	
	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// don't care - all work is done inside the tick 
	}

	public void prepareOutputs() {
		transmitInterface.setOutputValue(Interface.Value.LOGICAL_1);
	}
	
	public void dispose() {
		try {
			if(communicationThread != null) communicationThread.interrupt();
			if(serverSocket != null) serverSocket.close();
		} catch (IOException e) {}
	}
	
	private class UARTtoTCPGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;

		final static int WIDTH = 80;
		final static int HEIGHT = 30;
		
		private String name;
		
		public UARTtoTCPGraphic(String name) {
			super();
			this.name = name;
			this.setPreferredSize(new Dimension(WIDTH+1, HEIGHT+1));
			this.registerInterface(transmitInterface, 30, HEIGHT - Interface.HEIGHT);
			this.registerInterface(receiveInterface, 50, HEIGHT - Interface.HEIGHT);
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw gate outline
			if(messagesSinceError < ERROR_CUTOFF) {
				g2D.setColor(Color.ORANGE);
				g2D.fillRect(0, 0, WIDTH, HEIGHT);
			} else {
				g2D.drawRect(0, 0, WIDTH, HEIGHT);
			}
			g2D.setColor(Color.BLACK);
			g2D.drawString(name, WIDTH/10, HEIGHT/2);
		}
	}
}
