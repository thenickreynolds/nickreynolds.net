package simulator.component.flipflops;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;
import simulator.settings.*;

public class FlipFlopDFactory extends ComponentFactory {
	public static final String NAME = "D Flip Flop";
	public static final String PATH = "Flip Flops";
	private ComponentGraphic ui = new FlipFlopDGraphic();
	private Setting settings[];
	private StringSetting nameSetting;
	
	public FlipFlopDFactory(Engine engine) {
		super(NAME, PATH, engine);
		settings = new Setting[1];
		nameSetting = new StringSetting("Name", Setting.Level.NORMAL, NAME);
		settings[0] = nameSetting;
	}
	
	public Component createComponent() {
		return new FlipFlopD(nameSetting.getValue(), engine);
	}
	
	public Setting[] getSettings() {
		return settings;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	private class FlipFlopDGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final int width = 80;
		final int height = 40;
		
		public FlipFlopDGraphic() {
			this.setPreferredSize(new Dimension(width+1, height+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw gate outline
			g2D.drawRect(0, 0, width, height);
			g2D.drawString(NAME, width/10, height/2);
		}
	}
}
