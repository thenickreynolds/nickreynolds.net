package simulator.component.flipflops;

import simulator.Engine;
import simulator.Event;
import simulator.EventAction;
import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.component.Interface.Value;

import java.util.Set;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class FlipFlopJK extends Component {
	/* Truth Table
	 * J	K	Q'
	 * 0	0	Q
	 * 0	1	0
	 * 1	0	1
	 * 1	1	!Q
	 */
	// an array to store the interfaces for effeciency
	Interface interfaces[];
	// all the interfaces
	Interface interfaceJ, interfaceK, interfaceQ, interfaceNotQ;
	// the graphic for this component
	private FlipFlopJKGraphic ui;
	
	public FlipFlopJK(String name, Engine e) {
		super(name, e);
		
		// prepare all interfaces
		interfaces = new Interface[4];
		interfaceJ = new Interface("J", this, Interface.INPUT);
		interfaces[0] = interfaceJ;
		interfaceK = new Interface("K", this, Interface.INPUT);
		interfaces[1] = interfaceK;
		interfaceQ = new Interface("Q", this, Interface.OUTPUT);
		interfaces[2] = interfaceQ;
		interfaceNotQ = new Interface("NotQ", this, Interface.OUTPUT);
		interfaces[3] = interfaceNotQ;
		
		// create GUI
		ui = new FlipFlopJKGraphic();
	}
	
	public void prepareOutputs() {
		interfaceQ.setOutputValue(Value.LOGICAL_0);
		interfaceNotQ.setOutputValue(Value.LOGICAL_1);
	}
	
	public void changeOutput(Value q) {
		if(interfaceQ.isValue(q)) {
			return;
		}
		
		interfaceQ.setOutputValue(q);
		interfaceNotQ.setOutputValue(Interface.notOperation(q));
	}
	
	public void refresh() {
		final Value newQ;
		int sum = (interfaceJ.isValue(Value.LOGICAL_1) ? 2 : 0) + ((interfaceK.isValue(Value.LOGICAL_1) ? 1 : 0));
		
		switch(sum) {
		case 0:
			// 0 0 - no change
			return;
		case 1:
			// 0 1 - set Q to 0
			newQ = Value.LOGICAL_0;
			break;
		case 2:
			// 1 0 - set Q to 1
			newQ = Value.LOGICAL_1;
			break;
		case 3:
			// 1 1 - unstable (randomly pick a value)
			newQ = Interface.notOperation(interfaceQ.getValue());
		default:
			// this is not possible
			return;
		}
		
		engine.addEvent(
				new Event(this, engine.getTime() + Engine.TIME_NANOSECOND * 2, new EventAction() {
					public void execute() {
						changeOutput(newQ);
					}
				}));
	}
	
	public void init() {
		refresh();
	}
	
	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// if neither of the inputs have changed then return
		if(!changedInterfaces.contains(interfaceJ)
				&& !changedInterfaces.contains(interfaceK))
			return;
		// enqueue update event if necessary
		refresh();
	}
	
	public Interface[] getInterfaces() {
		return interfaces;
	}
	
	public Interface getQ() {
		return interfaceQ;
	}

	public Interface getNotQ() {
		return interfaceNotQ;
	}
	
	public Interface getJ() {
		return interfaceJ;
	}
	
	public Interface getK() {
		return interfaceK;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public void dispose() {}
	
	private class FlipFlopJKGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final int width = 80;
		final int height = 40;
		
		public FlipFlopJKGraphic() {
			this.setPreferredSize(new Dimension(width+1, height+1));
			this.registerInterface(interfaceJ, 0, (int)(height*0.3-Interface.HEIGHT*0.5));
			this.registerInterface(interfaceK, 0, (int)(height*0.7-Interface.HEIGHT*0.5));
			this.registerInterface(interfaceQ, width-Interface.WIDTH, (int)(height*0.3-Interface.HEIGHT*0.5));
			this.registerInterface(interfaceNotQ, width-Interface.WIDTH, (int)(height*0.7-Interface.HEIGHT*0.5));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw gate outline
			g2D.drawRect(0, 0, width, height);
			g2D.drawString("FlipFlop JK", width/10, height/2);
		}
	}
}
