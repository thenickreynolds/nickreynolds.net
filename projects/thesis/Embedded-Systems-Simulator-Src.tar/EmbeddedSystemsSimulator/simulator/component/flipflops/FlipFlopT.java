package simulator.component.flipflops;

import simulator.Engine;
import simulator.Event;
import simulator.EventAction;
import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.component.Interface.Value;

import java.util.Set;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class FlipFlopT extends Component {
	/* Toggle FlipFlop
	 * 
	 * Truth Table
	 * T	Q	Q'
	 * 0	0	0
	 * 0	1	1
	 * 1	0	1
	 * 1	1	0
	 */
	// an array to store the interfaces for effeciency
	Interface interfaces[];
	// all the interfaces
	Interface interfaceT, interfaceQ, interfaceNotQ;
	// the graphic for this component
	private FlipFlopTGraphic ui;
	
	public FlipFlopT(String name, Engine e) {
		super(name, e);
		
		// prepare all interfaces
		interfaces = new Interface[3];
		interfaceT = new Interface("T", this, Interface.INPUT);
		interfaces[0] = interfaceT;
		interfaceQ = new Interface("Q", this, Interface.OUTPUT);
		interfaces[1] = interfaceQ;
		interfaceNotQ = new Interface("NotQ", this, Interface.OUTPUT);
		interfaces[2] = interfaceNotQ;
		
		// create GUI
		ui = new FlipFlopTGraphic();
	}
	
	public void prepareOutputs() {
		interfaceQ.setOutputValue(Value.LOGICAL_0);
		interfaceNotQ.setOutputValue(Value.LOGICAL_1);
	}
	
	public void changeOutput(Value q) {
		if(interfaceQ.isValue(q)) {
			return;
		}
		
		interfaceQ.setOutputValue(q);
		interfaceNotQ.setOutputValue(Interface.notOperation(q));
	}
	
	public void refresh() {
		final Value newQ;
		int sum = (interfaceT.isValue(Value.LOGICAL_1) ? 2 : 0) + ((interfaceQ.isValue(Value.LOGICAL_1) ? 1 : 0));
		
		switch(sum) {
		case 0:
		case 3:
			// 0 0, 1 1 - set Q to 0
			newQ = Value.LOGICAL_0;
			break;
		case 1:
		case 2:
			// 0 1, 1 0 - set Q to 1
			newQ = Value.LOGICAL_1;
			break;
		default:
			// this is not possible
			return;
		}
		
		engine.addEvent(
				new Event(this, engine.getTime() + Engine.TIME_NANOSECOND * 2, new EventAction() {
					public void execute() {
						changeOutput(newQ);
					}
				}));
	}
	
	public void init() {
		refresh();
	}
	
	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// if neither of the inputs have changed then return
		if(!changedInterfaces.contains(interfaceT))
			return;
		// enqueue update event if necessary
		refresh();
	}
	
	public Interface[] getInterfaces() {
		return interfaces;
	}

	public Interface getQ() {
		return interfaceQ;
	}

	public Interface getNotQ() {
		return interfaceNotQ;
	}
	
	public Interface getT() {
		return interfaceT;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public void dispose() {}
	
	private class FlipFlopTGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final int width = 80;
		final int height = 40;
		
		public FlipFlopTGraphic() {
			this.setPreferredSize(new Dimension(width+1, height+1));
			this.registerInterface(interfaceT, 0, (int)(height*0.3-Interface.HEIGHT*0.5));
			this.registerInterface(interfaceQ, width-Interface.WIDTH, (int)(height*0.3-Interface.HEIGHT*0.5));
			this.registerInterface(interfaceNotQ, width-Interface.WIDTH, (int)(height*0.7-Interface.HEIGHT*0.5));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw gate outline
			g2D.drawRect(0, 0, width, height);
			g2D.drawString("FlipFlop T", width/10, height/2);
		}
	}
}
