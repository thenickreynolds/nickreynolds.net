package simulator.component.flipflops;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;
import simulator.settings.Setting;
import simulator.settings.StringSetting;

public class FlipFlopJKFactory extends ComponentFactory {
	public static final String NAME = "JK Flip Flop";
	public static final String PATH = "Flip Flops";
	private ComponentGraphic ui = new FlipFlopJKGraphic();
	private Setting settings[];
	private StringSetting nameSetting;
	
	public FlipFlopJKFactory(Engine engine) {
		super(NAME, PATH, engine);
		settings = new Setting[1];
		nameSetting = new StringSetting("Name", Setting.Level.NORMAL, NAME);
		settings[0] = nameSetting;
	}
	
	public Setting[] getSettings() {
		return settings;
	}
	
	public Component createComponent() {
		return new FlipFlopJK(nameSetting.getValue(), engine);
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	private class FlipFlopJKGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final int width = 80;
		final int height = 40;
		
		public FlipFlopJKGraphic() {
			this.setPreferredSize(new Dimension(width+1, height+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw gate outline
			g2D.drawRect(0, 0, width, height);
			g2D.drawString(NAME, width/10, height/2);
		}
	}
}
