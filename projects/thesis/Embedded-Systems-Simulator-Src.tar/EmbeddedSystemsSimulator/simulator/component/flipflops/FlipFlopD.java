package simulator.component.flipflops;

import simulator.Engine;
import simulator.Event;
import simulator.EventAction;
import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.component.Interface.Value;

import java.util.Set;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class FlipFlopD extends Component {
	/* Truth Table
	 * D	C	Q'
	 * 
	 * 0	0	0
	 * 0	1	1
	 * Note:	Propogates on clock tick
	 */
	// an array to store the interfaces for effeciency
	Interface interfaces[];
	// all the interfaces
	Interface interfaceD, interfaceClock, interfaceQ, interfaceNotQ;
	// the graphic for this component
	private FlipFlopDGraphic ui;
	
	public FlipFlopD(String name, Engine e) {
		super(name, e);
		
		// prepare all interfaces
		interfaces = new Interface[4];
		interfaceD = new Interface("D", this, Interface.INPUT);
		interfaces[0] = interfaceD;
		interfaceClock = new Interface("Clock", this, Interface.INPUT);
		interfaces[1] = interfaceClock;
		interfaceQ = new Interface("Q", this, Interface.OUTPUT);
		interfaces[2] = interfaceQ;
		interfaceNotQ = new Interface("NotQ", this, Interface.OUTPUT);
		interfaces[3] = interfaceNotQ;
		
		// create GUI
		ui = new FlipFlopDGraphic();
	}
	
	public void prepareOutputs() {
		interfaceQ.setOutputValue(Value.LOGICAL_0);
		interfaceNotQ.setOutputValue(Value.LOGICAL_1);
	}
	
	public void changeOutput(Value q) {
		if(interfaceQ.isValue(q)) {
			return;
		}
		
		interfaceQ.setOutputValue(q);
		interfaceNotQ.setOutputValue(Interface.notOperation(q));
	}
	
	public void refresh() {
		final Value newQ;
		
		// not clock edge (nothing changes)
		if(interfaceClock.isValue(Value.LOGICAL_0)) {
			return;
		}
		
		// propogate the value
		newQ = interfaceD.getValue();
		
		// create the new event
		engine.addEvent(
				new Event(this, engine.getTime() + Engine.TIME_NANOSECOND * 2, new EventAction() {
					public void execute() {
						changeOutput(newQ);
					}
				}));
	}
	
	public void init() {
		refresh();
	}
	
	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// if the clock hasn't changed or is not logical 1 then ignore it
		if(!changedInterfaces.contains(interfaceClock))
			return;
		// enqueue update event if necessary
		refresh();
	}
	
	public Interface[] getInterfaces() {
		return interfaces;
	}
	
	public Interface getQ() {
		return interfaceQ;
	}

	public Interface getNotQ() {
		return interfaceNotQ;
	}
	
	public Interface getD() {
		return interfaceD;
	}
	
	public Interface getClock() {
		return interfaceClock;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public void dispose() {}
	
	private class FlipFlopDGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final int width = 80;
		final int height = 40;
		
		public FlipFlopDGraphic() {
			this.setPreferredSize(new Dimension(width+1, height+1));
			this.registerInterface(interfaceD, 0, (int)(height*0.3-Interface.HEIGHT*0.5));
			this.registerInterface(interfaceClock, 0, (int)(height*0.7-Interface.HEIGHT*0.5));
			this.registerInterface(interfaceQ, width-Interface.WIDTH, (int)(height*0.3-Interface.HEIGHT*0.5));
			this.registerInterface(interfaceNotQ, width-Interface.WIDTH, (int)(height*0.7-Interface.HEIGHT*0.5));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw gate outline
			g2D.drawRect(0, 0, width, height);
			g2D.drawString("FlipFlop D", width/10, height/2);
		}
	}
}
