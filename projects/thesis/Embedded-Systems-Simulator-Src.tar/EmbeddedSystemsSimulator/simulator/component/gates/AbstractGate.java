package simulator.component.gates;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Set;

import simulator.Engine;
import simulator.Event;
import simulator.EventAction;
import simulator.component.Component;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.component.Interface.Value;

public abstract class AbstractGate extends Component {
	// inputs to this component
	protected Interface[] inputs;
	// output interface
	protected Interface output;
	// interfaces belonging to this component (made up of inputs/outputs)
	protected Interface[] interfaces;
	// the user interface for this component
	protected ComponentGraphic ui;
	// the type of the gate
	protected String type;
	
	protected AbstractGate(String type, String name, int numInputs, Engine engine) {
		super(name, engine);
		this.type = type;
		int i;
		// create interfaces of component
		inputs = new Interface[numInputs];
		interfaces = new Interface[numInputs+1];
		for(i = 0; i < inputs.length; i++) {
			inputs[i] = new Interface("input " + (i+1), this, Interface.INPUT);
			interfaces[i] = inputs[i];
		}
		output = new Interface("output", this, Interface.OUTPUT);
		interfaces[i] = output;
		ui = new GateGraphic();
	}
	
	protected void changeOutput(Value v) {
		if(output.isValue(v))
			return;
		output.setOutputValue(v);
	}
	
	public Interface[] getInterfaces() {
		return interfaces;
	}
	
	protected abstract Value refresh();
	
	public Interface[] getInputs() {
		return inputs;
	}
	
	public void interfaceChanged(Set<Interface> changedInterfaces) {
		// look for any of the input Interfaces in changedInterfaces
		for(Interface i : inputs)
			if(changedInterfaces.contains(i)) {
				addEvent();
				break;
			}
	}
	
	private void addEvent() {
		final Value newOutput = refresh();
		engine.addEvent(
			new Event(this, engine.getTime() + Engine.TIME_PICOSECOND, new EventAction() {
				public void execute() {
					changeOutput(newOutput);
				}
			}));
	}
	
	public void prepareOutputs() {
		output.setOutputValue(Value.LOGICAL_0);
	}
	
	public void init() { 
		addEvent();
	}
	
	public Interface getOutput() {
		return output;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	public void dispose() {}
	
	protected class GateGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int WIDTH = 80;
		final static int HEIGHT = 30;
		
		public GateGraphic() {
			this.setPreferredSize(new Dimension(WIDTH+1, HEIGHT+1));
			this.registerInterfaces(WIDTH, HEIGHT);
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw gate outline
			
			g2D.drawRect(0, 0, WIDTH, HEIGHT);
			g2D.drawString(type + " GATE", WIDTH/10, HEIGHT/2);
		}
		
		protected void registerInterfaces(int width, int height) {
			double step = height/(inputs.length + 1.0);
			for(int i = 0; i < inputs.length; i++) {
				this.registerInterface(inputs[i], 0, (int)(step*(i+1)-Interface.HEIGHT*0.5));
			}
			this.registerInterface(output, width-Interface.WIDTH, (int)(height*0.5-Interface.HEIGHT*0.5));
		}
	}
}
