package simulator.component.gates;

import simulator.component.Interface;
import simulator.component.Interface.Value;
import simulator.Engine;
import simulator.TemporaryException;

public class GateAND extends AbstractGate {
	public GateAND(String name, Engine engine) {
		this(name, engine, 2);
	}
	
	public GateAND(String name, Engine engine, int numInputs) {
		super("AND", name, numInputs, engine);
		
		if(numInputs < 2) throw new TemporaryException("Cannot create an AND gate with less than 2 input");
	}
	
	protected Value refresh() {
		// see if a LOGICAL_0 input exists
		for(Interface i : getInputs())
			if(i.isValue(Value.LOGICAL_0)) return Value.LOGICAL_0;
		return Value.LOGICAL_1;
	}
}