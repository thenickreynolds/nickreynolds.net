package simulator.component.gates;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;
import simulator.component.Interface;
import simulator.settings.Setting;
import simulator.settings.StringSetting;
import simulator.settings.Setting.Level;

public class GateNOTFactory extends ComponentFactory {
	public static final String NAME = "NOT Gate";
	public static final String PATH = "Logic";
	private ComponentGraphic ui = new GateNOTGraphic();
	private Setting settings[];
	private StringSetting nameSetting;
	
	public GateNOTFactory(Engine engine) {
		super(NAME, PATH, engine);
		settings = new Setting[1];
		nameSetting = new StringSetting("Name", Level.NECESSARY, NAME);
		settings[0] = nameSetting;
	}
	
	public Component createComponent() {
		return new GateNOT(nameSetting.getValue(), engine);
	}
	
	public Setting[] getSettings() {
		return settings;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	private class GateNOTGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int WIDTH = 30;
		final static int HEIGHT = 30;
		
		public GateNOTGraphic() {
			this.setPreferredSize(new Dimension(WIDTH+1+Interface.WIDTH, HEIGHT+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw triangle
			g2D.drawLine(Interface.WIDTH, (int)(HEIGHT*0.15), Interface.WIDTH, (int)(HEIGHT*0.85));
			g2D.drawLine(Interface.WIDTH, (int)(HEIGHT*0.85), (int)(WIDTH*0.85), (int)(HEIGHT*0.5));
			g2D.drawLine((int)(WIDTH*0.85), (int)(HEIGHT*0.5), Interface.WIDTH, (int)(HEIGHT*0.15));
			// draw not circle
			g2D.drawOval((int)(WIDTH*0.85), (int)(HEIGHT*0.5-HEIGHT*0.1*0.5), (int)(WIDTH*0.15), (int)(WIDTH*0.15));
		}
	}
}
