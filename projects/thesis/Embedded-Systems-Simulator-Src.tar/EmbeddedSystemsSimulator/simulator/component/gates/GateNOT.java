package simulator.component.gates;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.component.Interface;
import simulator.component.Interface.Value;
import simulator.Engine;

public class GateNOT extends AbstractGate {
	public GateNOT(String name, Engine engine) {
		super("NOT", name, 1, engine);
		
		ui = new GateNOTGraphic();
	}

	public Value refresh() {
		// this gate only has one input
		return Interface.notOperation(getInputs()[0].getValue());
	}
	
	private class GateNOTGraphic extends GateGraphic {
		public final static long serialVersionUID = 1;
		
		final static int WIDTH = 30;
		final static int HEIGHT = 30;
		
		public GateNOTGraphic() {
			this.setPreferredSize(new Dimension(WIDTH+1+Interface.WIDTH, HEIGHT+1));
			this.registerInterfaces(WIDTH+Interface.WIDTH, HEIGHT);
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw triangle
			g2D.drawLine(Interface.WIDTH, (int)(HEIGHT*0.15), Interface.WIDTH, (int)(HEIGHT*0.85));
			g2D.drawLine(Interface.WIDTH, (int)(HEIGHT*0.85), (int)(WIDTH*0.85), (int)(HEIGHT*0.5));
			g2D.drawLine((int)(WIDTH*0.85), (int)(HEIGHT*0.5), Interface.WIDTH, (int)(HEIGHT*0.15));
			// draw not circle
			g2D.drawOval((int)(WIDTH*0.85), (int)(HEIGHT*0.5-HEIGHT*0.1*0.5), (int)(WIDTH*0.15), (int)(WIDTH*0.15));
		}
	}
}