package simulator.component.gates;

import simulator.TemporaryException;
import simulator.component.Interface;
import simulator.component.Interface.Value;
import simulator.Engine;

public class GateXOR extends AbstractGate {
	public GateXOR(String name, Engine engine) {
		this(name, engine, 2);
	}
	
	public GateXOR(String name, Engine engine, int numInputs) {
		super("XOR", name, numInputs, engine);
		
		if(numInputs < 2) throw new TemporaryException("Cannot create an XOR gate with less than 2 input");
	}
	
	protected Value refresh() {
		int countTrue = 0;
		// count the number of LOGICAL_1 inputs
		for(Interface i : getInputs())
			if(i.isValue(Value.LOGICAL_1)) countTrue++;
		
		if((countTrue%2) == 1) {
			// number is odd, output should be LOGICAL_1
			return Value.LOGICAL_1;
		} else {
			// number is even, output should be LOGICAL_0
			return Value.LOGICAL_0;
		}
	}
}