package simulator.component.gates;

import simulator.TemporaryException;
import simulator.component.Interface;
import simulator.component.Interface.Value;
import simulator.Engine;

public class GateOR extends AbstractGate {
	public GateOR(String name, Engine engine) {
		this(name, engine, 2);
	}
	
	public GateOR(String name, Engine engine, int numInputs) {
		super("OR", name, numInputs, engine);
		
		if(numInputs < 2) throw new TemporaryException("Cannot create an OR gate with less than 2 input");
	}
	
	public Value refresh() {
		// see if a LOGICAL_1 input exists
		for(Interface i : getInputs())
			if(i.isValue(Value.LOGICAL_1)) {
				return Value.LOGICAL_1;
			}
		return Value.LOGICAL_0;
	}
}