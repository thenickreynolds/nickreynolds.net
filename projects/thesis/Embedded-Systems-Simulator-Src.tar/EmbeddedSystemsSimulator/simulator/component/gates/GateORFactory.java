package simulator.component.gates;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import simulator.Engine;
import simulator.component.Component;
import simulator.component.ComponentFactory;
import simulator.component.ComponentGraphic;
import simulator.settings.IntegerSetting;
import simulator.settings.Setting;
import simulator.settings.StringSetting;
import simulator.settings.Setting.Level;

public class GateORFactory extends ComponentFactory {
	public static final String NAME = "OR Gate";
	public static final String PATH = "Logic";
	private ComponentGraphic ui = new GateORGraphic();
	private Setting settings[];
	private StringSetting nameSetting;
	private IntegerSetting numInputsSetting;
	
	public GateORFactory(Engine engine) {
		super(NAME, PATH, engine);
		settings = new Setting[2];
		nameSetting = new StringSetting("Name", Level.NECESSARY, NAME);
		numInputsSetting = new IntegerSetting("Num. Inputs", Level.NECESSARY, 2, 5, 2);
		settings[0] = nameSetting;
		settings[1] = numInputsSetting;
	}
	
	public Component createComponent() {
		return new GateOR(nameSetting.getValue(), engine, numInputsSetting.getValue());
	}
	
	public Setting[] getSettings() {
		return settings;
	}
	
	public ComponentGraphic getComponentGraphic() {
		return ui;
	}
	
	private class GateORGraphic extends ComponentGraphic {
		public final static long serialVersionUID = 1;
		
		final static int WIDTH = 80;
		final static int HEIGHT = 30;
		
		public GateORGraphic() {
			this.setPreferredSize(new Dimension(WIDTH+1, HEIGHT+1));
		}
		
		public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D)g;
			// draw gate outline
			g2D.drawRect(0, 0, WIDTH, HEIGHT);
			g2D.drawString(NAME, WIDTH/10, HEIGHT/2);
		}
	}
}
