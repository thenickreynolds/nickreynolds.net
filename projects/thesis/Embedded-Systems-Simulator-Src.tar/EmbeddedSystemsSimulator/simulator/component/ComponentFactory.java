package simulator.component;

import simulator.Engine;
import simulator.settings.Setting;

/**
 * This ComponentFactory class must be extended for each component to be added to the system. It provides
 * a method to instantiate Component objects with specific, pre-defined settings.
 * @author Nick
 */
public abstract class ComponentFactory {
	// the name of this component type
	private String name;
	private String path;
	protected Engine engine;
	
	/**
	 * The default constructor for the ComponentFactory
	 * @param name	The name of the component
	 * @param path	The path to be displayed under, delimited by the '.' character
	 * @param engine	The simulation engine to which this component belongs
	 */
	protected ComponentFactory(String name, String path, Engine engine) {
		this.name = name;
		this.path = path;
	}
	
	/**
	 * Get the name of the component
	 * @return	the name of the component
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Get the path of the component
	 * @return the path of the component delimited by the '.' character
	 */
	public String getTreePath() {
		return path;
	}
	
	/**
	 * Get the component graphic
	 * @return	the graphical representation of the component to use while placing on a ComponentField
	 */
	public abstract ComponentGraphic getComponentGraphic();
	
	/**
	 * Create a new Component object for which this factory is made
	 * @return	A new Component which was created based on the Settings gathered (if applicable)
	 * @throws CannotCreateComponentException	This is thrown if the new Component could not be created.
	 */
	public abstract Component createComponent() throws CannotCreateComponentException;
	
	/**
	 * Returns an array of all the Settings applicable for this Component
	 * @return
	 */
	public abstract Setting[] getSettings();
	
	public String toString() {
		return name;
	}
}