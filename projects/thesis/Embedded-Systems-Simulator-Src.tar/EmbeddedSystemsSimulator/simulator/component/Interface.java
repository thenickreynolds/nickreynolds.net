// TODO BUG: there is an error when an interface is changed (value/direction) multiple times in one engine time... this is going to need to be fixed (i.e. the value will be back to the same but it will register as changed)

package simulator.component;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JComponent;

import java.util.ArrayList;
import java.util.List;

import simulator.TemporaryException;

public class Interface extends JComponent {
	public final static long serialVersionUID = 1;
	
	// the WIDTH and HEIGHT of an interface graphic
	public final static int WIDTH = 5;
	public final static int HEIGHT = 5;
	
	// interface is selected by the component field
	private boolean selected = false;
	
	public static enum Value { LOGICAL_0, LOGICAL_1 };
	// input interface
	public final static boolean INPUT = true;
	// output interface
	public final static boolean OUTPUT = false;
	// the direction of the interface
	private boolean direction;
	// the component to which this interface belongs
	private Component owner;
	// the interfaces to which this interface is connected
	private List<Interface> siblings = new ArrayList<Interface>();
	// the value of this interface (only if output)
	private Value inputValue;
	private Value outputValue;
	// name of the input
	private String name;
	// a list of listeners (awaiting a change of value)
	private List<InterfaceListener> interfaceListeners = new ArrayList<InterfaceListener>();
	
	public Interface(String name, Component owner, boolean direction) {
		if(owner == null) throw new NullPointerException("Must supply a parent");
		this.name = name;
		this.owner = owner;
		this.direction = direction;
		this.outputValue = Value.LOGICAL_0;
		this.inputValue = Value.LOGICAL_0;
		
		setPreferredSize(new Dimension(WIDTH+1, HEIGHT+1));
		setToolTipText(toString());
	}
	
	public void setDirection(boolean direction) {
		if(direction == this.direction) return;
		this.direction = direction;

		// update all siblings which are inputs
		for(Interface sibling : siblings) {
			if(sibling.isInput()) {
				sibling.siblingChangedValue();
			}
		}
	}
	
	public boolean getDirection() {
		return direction;
	}
	
	public void connect(Interface sibling) {
		if(siblings.contains(sibling)) throw new TemporaryException("Already connected");
		siblings.add(sibling);
		setToolTipText(toString());
	}
	
	public void disconnect(Interface sibling) {
		if(!siblings.contains(sibling)) throw new TemporaryException("Not connected");
		// remove the connection
		siblings.remove(sibling);
		sibling.remove(this);
		setToolTipText(toString());
	}
	
	public List<Interface> getSiblings() {
		return siblings;
	}
	
	public void setOutputValue(Value value) {
		if(direction == INPUT) {
			// set the output value and don't do anything else
			this.outputValue = value;
		}
		
		// don't need to do anything - already this value
		if(this.outputValue == value) return;
		
		// change the value
		this.outputValue = value;
		
		// update all siblings which are inputs
		for(Interface sibling : siblings) {
			if(sibling.isInput()) {
				sibling.siblingChangedValue();
			}
		}
	}
	
	/** This returns the current value of the interface
	 * @return if this interface is currently an output this returns the value being output, if it is an input it returns LOGICAL_0 iff there are no connected interfaces which are OUTPUTS and value LOGICAL_1  
	 */
	public Value getValue() {
		if(direction == INPUT) return inputValue;
		else return outputValue;
	}
	
	/** This calculates what the current value of this interface should be ASSUMING it is an input 
	 * @return this returns LOGICAL_0 iff there are no connected interfaces which are OUTPUTS and value LOGICAL_1  
	 */
	protected Value calculateValue() {
		// return logical zero unless there exists an output who's value is logical 1
		for(Interface i : siblings)
			if(i.direction == OUTPUT && i.isValue(Value.LOGICAL_1))
				return Value.LOGICAL_1;
		return Value.LOGICAL_0;
	}
	
	public void siblingChangedValue() {
		// if direction is output exit this
		if(direction == OUTPUT) return;
		// calculate a new value
		Value updatedValue = calculateValue();
		// check if value has changed
		if(inputValue != updatedValue) {
			// value has changed, update it
			inputValue = updatedValue;
			// notify listeners of change
			for(InterfaceListener il : interfaceListeners)
				il.interfaceValueChanged(this);
		}
	}
	
	public Component getOwner() {
		return owner;
	}
	
	public String getName() {
		return name;
	}
	
	public boolean isSibling(Interface i) {
		return siblings.contains(i);
	}
	
	public static String valueString(Value v) {
		if(v == Value.LOGICAL_0) {
			return "0";
		} else if (v == Value.LOGICAL_1) {
			return "1";
		} else {
			return "Unknown Value";
		}
	}
	
	public String getFullDescription() {
		String description = toString();
		if(!siblings.isEmpty()) {
			description += " is connected to:\n";
		}
		for(Interface i : siblings)
			description += "\t" + i.getName() + " of " + i.getOwner().getName();
		return description;
	}
	
	public String toString() {
		return name + " of " + owner.getName();
	}
	
	public boolean isValue(Value v) {
		return getValue() == v;
	}
	
	public static Value notOperation(Value v) {
		return (v == Value.LOGICAL_0) ? Value.LOGICAL_1 : Value.LOGICAL_0;
	}
	
	public void paintComponent(Graphics g) {
		Graphics2D g2D = (Graphics2D)g;
		Color c = null;
		
		// different colour depending on value
		if (direction == INPUT && siblings.isEmpty()) {
			c = Color.GRAY;
		} else {
			final Value currentValue = getValue();
			
			// get the current value
			if (currentValue == Value.LOGICAL_1) {
				c = Color.GREEN;
			} else if (currentValue == Value.LOGICAL_0) {
				c = Color.WHITE;
			} else {
				c = Color.RED;
			}
		}
		// draw the coloured interface
		g2D.setColor(c);
		g2D.fillRect(0, 0, WIDTH, HEIGHT);
		// draw the boundary
		g2D.setColor((selected) ? Color.RED : Color.BLACK);
		g2D.drawRect(0, 0, WIDTH, HEIGHT);
	}
	
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	
	public boolean getSelected() {
		return selected;
	}
	
	public boolean isInput() {
		return direction == INPUT;
	}
	
	public boolean isOutput() {
		return direction == OUTPUT;
	}
	
	/* InterfaceListener */
	public void addInterfaceListener(InterfaceListener interfaceListener) {
		interfaceListeners.add(interfaceListener);
	}
	
	public void removeInterfaceListener(InterfaceListener interfaceListener) {
		interfaceListeners.remove(interfaceListener);
	}
}
