package simulator;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.awt.*;

public class EmbeddedSystemsSimulator extends Thread {
	// the main engine
	private EngineGUI e;
	/* GUI Components */
	private JFrame window;
	private JMenuBar menu;
	private JMenu fileMenu, helpMenu;
	private JLabel generalStatus, errorStatus, runningStatus;
	private JButton playButton;
	private JToolBar controlBar;
	// these are used for text representations (makes wrapping and center align work)
	public static final String TEXT_PREFIX = "<html><center>";
	public static final String TEXT_POSTFIX = "</center></html>";
	// the engine thread (running the engine in the background)
	private Thread engineThread;
	// the last time the user interface was notified of the running time
	private long lastRealTime = -1;
	private long lastSimulationTime = -1;
	// status updater timer
	private Timer statusUpdaterTimer;
	// determines if the simulation should be restrained to realtime or not
	private boolean realtime = true;
	// the tree for component sel
	
	// create the entire GUI
    private void createAndShowGUI() {
        // create frame
    	window = new JFrame("Embedded System Simulator");
    	// set close operation
    	window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        /* set the layout (rows columns)
         * |--------------|
         * |     menu     | file->exit; plugins->load; help->about;
         * |--------------|
         * |    control   | play pause counter simulationtime:realtime
         * |--------------|
         * |     tabs     | place holder for all components and debug window
         * |              |
         * |              |
         * |              |
         * |              |
         * |              |
         * |--------------|
         * |    status    | status bar with brief information
         * |--------------|
         */
        JPanel pane = new JPanel(new BorderLayout());

        // create menu bar
        window.setJMenuBar(createMenu());
        
        // add control bar
        pane.add(createControlBar(), BorderLayout.NORTH);
        
        // create main tab container
        pane.add(e.getGUI(), BorderLayout.CENTER);
        
        // add status bar
        pane.add(createStatusBar(), BorderLayout.SOUTH);
        
        // add pane to frame
        window.getContentPane().add(pane);
        
        // display the frame
        window.setPreferredSize(new Dimension(800, 500));
        window.setMinimumSize(new Dimension(400, 300));
        window.pack();
        window.setVisible(true);
    }
    
    // create the menu bar for the main window
    private JMenuBar createMenu() {
    	JMenuItem menuItem;
    	
    	// create the menu bar
    	menu = new JMenuBar();
    	
    	// create the File menu
    	fileMenu = new JMenu("File");
    	fileMenu.setMnemonic(KeyEvent.VK_F);
    	
    	// lock toolbar
    	JCheckBoxMenuItem checkBoxMenuItem = new JCheckBoxMenuItem("Lock Toolbar");
    	checkBoxMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lockMenu(evt);
            }
        });
    	checkBoxMenuItem.setState(true);
    	fileMenu.add(checkBoxMenuItem);
    	
    	checkBoxMenuItem = new JCheckBoxMenuItem("Realtime Simulation");
    	checkBoxMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                setRealtime(evt);
            }
        });
    	checkBoxMenuItem.setState(true);
    	fileMenu.add(checkBoxMenuItem);
    	
    	// exit
    	menuItem = new JMenuItem("Exit", KeyEvent.VK_X);
    	menuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                close(evt);
            }
        });
    	fileMenu.add(menuItem);
    	    	
    	// create Help menu
    	helpMenu = new JMenu("Help");
    	helpMenu.setMnemonic(KeyEvent.VK_H);
    	
    	// about
    	menuItem = new JMenuItem("About ESS", KeyEvent.VK_A);
    	menuItem.addActionListener(new java.awt.event.ActionListener() {
    		public void actionPerformed(java.awt.event.ActionEvent evt) {
    			// launch about window
    			about();
    		}
    	});
    	
    	helpMenu.add(menuItem);
    	
    	menu.add(fileMenu);
    	menu.add(helpMenu);
    	
    	return menu;
    }
    
    // create the control bar
    private JToolBar createControlBar() {
    	// create control bar
    	controlBar = new JToolBar();
    	controlBar.setFloatable(false);
    	
    	playButton = new JButton("Play");
    	playButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                togglePlayPause();
            }
        });
    	controlBar.add(playButton);
    	
    	JButton button;
    	
    	button = new JButton("Reset");
    	button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reset();
            }
        });
    	controlBar.add(button);
    	
    	button = new JButton("Halt");
    	button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                halt();
            }
        });
    	controlBar.add(button);
    	
    	button = new JButton("Clear Components");
    	button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear();
            }
        });
    	controlBar.add(button);
    	
    	return controlBar;
    }
    
    // create the control bar (buttons for main control)
    private JPanel createStatusBar() {
        // status bar
        JPanel statusBar = new JPanel(new GridLayout(1, 3, 1, 0));
        statusBar.setPreferredSize(new Dimension(50, 25));
        statusBar.setBorder(BorderFactory.createLoweredBevelBorder());
        
        generalStatus = new JLabel("");
        generalStatus.setHorizontalAlignment(JLabel.LEFT);
        generalStatus.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        
        runningStatus = new JLabel("");
        runningStatus.setHorizontalAlignment(JLabel.RIGHT);
        runningStatus.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        
        errorStatus = new JLabel("");
        errorStatus.setHorizontalAlignment(JLabel.RIGHT);
        errorStatus.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        
        statusBar.add(generalStatus);
        statusBar.add(runningStatus);
        statusBar.add(errorStatus);
        
        return statusBar;
    }
    
    // change the text in the status bar
    public void setGeneralStatus(String s) {}
    public void setRunningStatus(String s) {}
    public void setErrorStatus(String s) {}

    // send a play/pause message to the Engine
    private synchronized void togglePlayPause() {
    	if(e.getState() == Engine.State.OFF) {
    		if(engineThread != null) {
    			// the system has already attempted to run the engine - ignore this as it should resolve itself
    			return;
    		}
    		// spawn a new thread to run the Engine in real-time
        	engineThread = new Thread() {
        		public void run() {
        			e.start(realtime);
        		}
        	};
        	engineThread.start();
        	playButton.setText("Pause");
    	} else if (e.getState() == Engine.State.PAUSED) {
    		e.unpause();
    		playButton.setText("Pause");
    	} else if (e.getState() == Engine.State.RUNNING) {
    		e.pause();
    		playButton.setText("Continue");
    	} else {
    		JOptionPane.showMessageDialog(window, "Can not pause the engine right now");
    		return;
    	}
    }
    
    private synchronized void halt() {
    	if(e.getState() == Engine.State.OFF) {
    		JOptionPane.showMessageDialog(window, "Cannot stop system when in OFF state");
    		return;
    	}
    	if(engineThread != null) {
    		e.stop();
    		engineThread = null;
    	}
    	playButton.setText("Play");
    }
    
    private synchronized void clear() {
    	if(e.getState() != Engine.State.OFF) {
    		JOptionPane.showMessageDialog(window, "System must be OFF to clear");
    		return;
    	}
    	e.removeAllComponents();
    }
    
    // stop and start the simulation
    private synchronized void reset() {
    	if(e.getState() != Engine.State.RUNNING || e.getState() != Engine.State.PAUSED) {
    		JOptionPane.showMessageDialog(window, "Engine not running or paused");
    		return;
    	}
    	halt();
    	togglePlayPause();
    }
    
    private void lockMenu(java.awt.event.ActionEvent evt) {
    	// get the menu item and check it's state
    	controlBar.setFloatable(!((JCheckBoxMenuItem)evt.getSource()).getState());
    }
    
    private void setRealtime(java.awt.event.ActionEvent evt) {
    	// get the menu item and check it's state
    	realtime = ((JCheckBoxMenuItem)evt.getSource()).getState();
    }
    
    // pop up an about box displaying information regarding ESS
    public void about() {
    	JOptionPane.showMessageDialog(window,
                "About Embedded Systems Simulator\n" +
                "\n" +
    			"ESS was created by Nicholas Reynolds of the University\n" +
                "of Queensland Australia as part of an Engineering.\n" +
    			"Honours Thesis (Software Engineering).\n" +
    			"\n" +
    			"This tool is to be used for educational purposes only.\n" +
    			"\n" +
    			"For feedback or bug reports please email\n" +
    			"tassieboy.nick@gmail.com",
                "About ESS",
                JOptionPane.INFORMATION_MESSAGE);
    }
    
    // close the application after a user confirmation
    public void close() {
    	close(true);
    }
    
    // close the application
    public void close(ActionEvent e) {
    	// check to make sure closing is the right thing to do
    	close(true);
    }
    
    // close the application, if warn is true confirm close with the user
    private void close(boolean warn) {
    	if(warn)
    		if(JOptionPane.showConfirmDialog(window, "Are you sure you want to exit?", "Confirm Exit", JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION)
    			return;
    	// interrupt the thread to let it know it needs to die now
    	if (engineThread != null && engineThread.isAlive()) e.stop();
    	// dispose of the main window
    	window.dispose();
    }
    
    public void run() {
    	// create a new Engine GUI object
    	e = new EngineGUI();
    	// create and show the GUI
    	createAndShowGUI();
    	// set up the status updater
    	statusUpdaterTimer = new Timer(1000, new ActionListener() {
    		public void actionPerformed(ActionEvent evt) {
    			updateStatus();
    		}
    	});
    	statusUpdaterTimer.start();
    }
    
    public void updateStatus() {
    	if(e.state == Engine.State.RUNNING) {
        	long currentRealTime = System.currentTimeMillis();
        	long currentSimulationTime = (long)(e.getTimeSeconds() * 1000);
        	
        	if(lastRealTime < 0) {
        		lastRealTime = currentRealTime;
        		lastSimulationTime = currentSimulationTime;
            	runningStatus.setText("Calculating...");
            	return;
        	}
        	
        	double percentage =
        		(double)(currentSimulationTime - lastSimulationTime) // running time since last report
        		/ (double)(currentRealTime - lastRealTime) // actual time since last report
        		* 100; // to convert into a percentage
        	
        	runningStatus.setText("Running at: " + (int)percentage + "% realtime");
        	
        	lastRealTime = currentRealTime;
        	lastSimulationTime = currentSimulationTime;
        	
        	generalStatus.setText("System time: " + secondsToTime((long)e.getTimeSeconds()));
    	} else if(e.state == Engine.State.PAUSED) {
    		runningStatus.setText("Engine paused");
    		generalStatus.setText("System time: " + secondsToTime((long)e.getTimeSeconds()));
    	} else if(e.state == Engine.State.OFF) {
    		runningStatus.setText("Engine off");
    		generalStatus.setText("");
    	} else if(e.state == Engine.State.READY) {
    		runningStatus.setText("Engine ready");
    		generalStatus.setText("System time: " + secondsToTime(0));
    	} else if(e.state == Engine.State.STOP) {
    		runningStatus.setText("Engine stopping");
    		generalStatus.setText("");
    	} else if(e.state == Engine.State.BREAKPOINT) {
    		runningStatus.setText("Engine stopped on breakpoint");
    		generalStatus.setText("System time: " + secondsToTime((long)e.getTimeSeconds()));
    	} else {
    		runningStatus.setText("Unknown state");
    	}
    }
    
    private static String secondsToTime(long seconds) {
    	java.text.DecimalFormat df = new java.text.DecimalFormat("##################00");
    	String ret = df.format(seconds % 60) + " seconds";
    	if(seconds / 60 > 0) ret = df.format((seconds / 60) % 60) + " minutes, " + ret;
    	if(seconds / (60*60) > 0) ret = df.format((seconds / (60*60))) + " hours, " + ret;
    	return ret;
    }
    
    public static void main(String[] args) {
    	//try {
        //	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        //} catch (Exception e) {};
    	javax.swing.SwingUtilities.invokeLater(new EmbeddedSystemsSimulator());
    }
}
