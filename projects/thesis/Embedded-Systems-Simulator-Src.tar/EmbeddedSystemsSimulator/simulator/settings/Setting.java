package simulator.settings;

import javax.swing.JComponent;

import java.awt.Color;

public interface Setting {
	public static final int HEIGHT = 30;
	public static final int WIDTH = 150;
	public static final Color ERROR_COLOR = new Color(254, 177, 177);
	public static final Color OK_COLOR = new Color(205, 252, 197);
	
	public enum Level {NECESSARY, NORMAL, ADVANCED};
	
	public Level getLevel();
	
	public String getName();
	
	public JComponent getInputInterface();
}
