// TODO :FUTURE: there is an error here when a user inputs into a text field but does not unfocus from it - the value does not get set

package simulator.settings;

import javax.swing.JComponent;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class DoubleSetting implements Setting {
	private String name;
	private Level level;
	private JSpinner spinner;
	
	/** Creates a new setting which is of an double type
	 * @param name	The name of this setting
	 * @param level	The level of usability
	 * @param defaultValue The default value of this setting
	 * @param maxValue	The maximum value for this setting
	 * @param minValue	The minimum value for this setting
	 */
	public DoubleSetting(String name, Level level, double defaultValue, double maxValue, double minValue) {
		this.name = name;
		this.level = level;
		spinner = new JSpinner(new SpinnerNumberModel(defaultValue, minValue, maxValue, 1));
	}
	
	/** Creates a new setting which is of an double type
	 * @param name	The name of this setting
	 * @param level	The level of usability
	 * @param defaultValue The default value of this setting
	 * @param maxValue	The maximum value for this setting
	 * @param minValue	The minimum value for this setting
	 * @param step		The step size for this setting
	 */
	public DoubleSetting(String name, Level level, double defaultValue, double maxValue, double minValue, double step) {
		this.name = name;
		this.level = level;
		spinner = new JSpinner(new SpinnerNumberModel(defaultValue, minValue, maxValue, step));
		((JSpinner.DefaultEditor)spinner.getEditor()).getTextField().setBackground(Setting.OK_COLOR);
	}
	
	public String getName() {
		return name;
	}
	
	public double getValue() {
		return ((Double)spinner.getValue()).doubleValue();
	}

	public JComponent getInputInterface() {
		return spinner;
	}
	
	public Level getLevel() {
		return level;
	}
}