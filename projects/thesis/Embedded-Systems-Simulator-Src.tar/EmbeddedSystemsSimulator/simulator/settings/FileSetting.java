package simulator.settings;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.File;

public class FileSetting implements Setting {

	private JPanel panel;
	private JTextField fileField;
	private JButton open;
	private Level level;
	private String name;
	private JFileChooser fileChooser;
	private File selectedFile;
	
	public FileSetting(String name, Level level, String fileExtensions) {
		panel = new JPanel(new BorderLayout());
		fileField = new JTextField("");
		fileField.setEditable(false);
		fileField.setBackground(Setting.ERROR_COLOR);
		fileChooser = new JFileChooser();
		fileChooser.setFileFilter(new FileNameExtensionFilter(fileExtensions, fileExtensions));
		open = new JButton(new ImageIcon("simulator\\materials\\folder.png"));
		open.setToolTipText("Open File");
		open.setPreferredSize(new Dimension(20, 16));
		panel.add(fileField, BorderLayout.CENTER);
		panel.add(open, BorderLayout.EAST);
		this.level = level;
		this.name = name;
		selectedFile = null;
		open.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                if(fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                	setSelectedFile(fileChooser.getSelectedFile());
                }
            }
        });
	}
	
	public void setSelectedFile(File f) {
		selectedFile = f;
		fileField.setText(f.getAbsolutePath());
		fileField.setToolTipText(f.getAbsolutePath());
		fileField.setBackground(Setting.OK_COLOR);
	}
	
	public File getValue() {
		return selectedFile;
	}
	
	public JComponent getInputInterface() {
		return panel;
	}

	public Level getLevel() {
		return level;
	}

	public String getName() {
		return name;
	}

}
