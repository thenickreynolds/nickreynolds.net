package simulator.settings;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.BorderFactory;

import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Dimension;

import java.util.List;
import java.util.ArrayList;

public class SettingsPanel extends JPanel {
	public final static long serialVersionUID = 1;

	private List<Setting> settings = new ArrayList<Setting>();
	
	public SettingsPanel() {
		super(new FlowLayout());
		setMinimumSize(new Dimension(200, 100));
		setPreferredSize(new Dimension(200, 100));
		setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Settings"));
	}
	
	public void addSetting(Setting setting) {
		settings.add(setting);
		
		JPanel settingsPanel = new JPanel(new GridLayout(1, 2));
		settingsPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
		
		JTextField label = new JTextField(setting.getName());
		label.setEditable(false);
		label.setToolTipText(setting.getName());
		label.setCaretPosition(0);
		
		settingsPanel.add(label);
		settingsPanel.add(setting.getInputInterface());
		settingsPanel.setMinimumSize(new Dimension(190, 20));
		settingsPanel.setPreferredSize(new Dimension(190, 20));
		
		add(settingsPanel);
		validate();
	}
	
	public void addSettings(Setting settings[]) {
		if(settings == null) return;
		for(Setting s : settings)
			addSetting(s);
	}
	
	public void clearSettings() {
		settings.clear();
		repaint();
		removeAll();
	}
}
