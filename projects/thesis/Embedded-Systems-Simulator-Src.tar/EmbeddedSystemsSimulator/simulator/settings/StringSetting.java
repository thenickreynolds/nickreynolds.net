package simulator.settings;

import javax.swing.JComponent;
import javax.swing.JTextField;

import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;

public class StringSetting implements Setting, DocumentListener {
	public final static int DEFAULT_MAX = 100;
	
	private String name;
	private Level level;
	private int minLength;
	private int maxLength;
	private JTextField text;

	/**
	 * Create a setting field which takes a string with the settings specified.
	 * @param name	The name of this setting
	 * @param level	The level of usability of this setting
	 * @param defaultValue The default value for this setting
	 * @param minLength the minimum length of the resulting string
	 * @param maxLength the maximum length of the resulting string
	 */
	public StringSetting(String name, Level level, String defaultValue, int minLength, int maxLength) {
		this.name = name;
		this.level = level;
		this.minLength = minLength;
		this.maxLength = maxLength;
		text = new JTextField(maxLength);
		text.getDocument().addDocumentListener(this);
		text.setText(defaultValue);
	}
	
	/**
	 * Create a setting field which takes a string with the constraints specified. The minimum length defaults to 1 and maximum to DEFAULT_MAX 
	 * @param name	The name of this setting
	 * @param level	The level of usability of this setting
	 * @param defaultValue The default value for this setting
	 */
	public StringSetting(String name, Level level, String defaultValue) {
		this.name = name;
		this.level = level;
		this.minLength = 1;
		this.maxLength = DEFAULT_MAX;
		text = new JTextField(maxLength);
		text.getDocument().addDocumentListener(this);
		text.setText(defaultValue);
	}
	
	public void setValue(String s) {
		text.setText(s);
	}
	
	public String getValue() {
		return text.getText();
	}
	
	public String getName() {
		return name;
	}
	
	public Level getLevel() {
		return level;
	}
	
	public JComponent getInputInterface() {
		return text;
	}
	
	public void changedUpdate(DocumentEvent e) {
		updateColor();
	}
	public void removeUpdate(DocumentEvent e) {
		updateColor();
	}
	public void insertUpdate(DocumentEvent e) {
		updateColor();
	}
	
	private void updateColor() {
		if(text.getText().length() < minLength) text.setBackground(Setting.ERROR_COLOR);
		else text.setBackground(Setting.OK_COLOR);
	}
}
