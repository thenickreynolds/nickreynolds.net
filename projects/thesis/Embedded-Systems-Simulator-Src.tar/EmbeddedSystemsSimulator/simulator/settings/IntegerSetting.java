// TODO :FUTURE: there is an error here when a user inputs into a text field but does not unfocus from it - the value does not get set

package simulator.settings;

import javax.swing.JComponent;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class IntegerSetting implements Setting {
	private String name;
	private Level level;
	private JSpinner spinner;
	
	/** Creates a new setting which is of an integer type
	 * @param name	The name of this setting
	 * @param level	The level of usability
	 * @param defaultValue The default value of this setting
	 * @param maxValue	The maximum value for this setting
	 * @param minValue	The minimum value for this setting
	 */
	public IntegerSetting(String name, Level level, int defaultValue, int maxValue, int minValue) {
		this.name = name;
		this.level = level;
		spinner = new JSpinner(new SpinnerNumberModel(defaultValue, minValue, maxValue, 1));
	}
	
	/** Creates a new setting which is of an integer type
	 * @param name	The name of this setting
	 * @param level	The level of usability
	 * @param defaultValue The default value of this setting
	 * @param maxValue	The maximum value for this setting
	 * @param minValue	The minimum value for this setting
	 * @param step		The step size for this setting
	 */
	public IntegerSetting(String name, Level level, int defaultValue, int maxValue, int minValue, int step) {
		this.name = name;
		this.level = level;
		spinner = new JSpinner(new SpinnerNumberModel(defaultValue, minValue, maxValue, step));
		((JSpinner.DefaultEditor)spinner.getEditor()).getTextField().setBackground(Setting.OK_COLOR);
	}
	
	public String getName() {
		return name;
	}
	
	public int getValue() {
		return ((Integer)spinner.getValue()).intValue();
	}
	
	public void setValue(int value) {
		spinner.setValue(value);
	}

	public JComponent getInputInterface() {
		return spinner;
	}
	
	public Level getLevel() {
		return level;
	}
}