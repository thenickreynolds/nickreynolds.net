package simulator;

import simulator.component.Component;

public class Event implements Comparable<Event> {
	// time of event execution
	private double time;
	// component to which this event belongs
	private Component component;
	// the action of the event
	private EventAction action;
	
	public Event(Component component, double time, EventAction action) {
		this.component = component;
		this.time = time;
		this.action = action;
	}
	
	public double getTime() {
		return time;
	}
	
	public void execute() {
		action.execute();
	}
	
	public String toString() {
		return component.getName() + "[" + component.getClassName() + "]";
	}
	
	public int compareTo(Event e) {
		// compare to given Event
		if(time < e.getTime())
			return -1;
		else if(time > e.getTime())
			return 1;
		else
			return 0;
	}
	
	public void setTime(double time) {
		this.time = time;
	}
}
