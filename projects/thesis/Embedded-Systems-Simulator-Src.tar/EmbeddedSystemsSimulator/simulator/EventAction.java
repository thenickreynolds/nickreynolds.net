package simulator;

public abstract class EventAction {
	public abstract void execute();
}
