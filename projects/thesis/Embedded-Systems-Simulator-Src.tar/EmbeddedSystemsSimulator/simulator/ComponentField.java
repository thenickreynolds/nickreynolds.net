// TODO :FUTURE: better wiring layout ability, delete items, move items, smarter repaint
// TODO disallow overlapping items - graphically let the user know if it is ok to place an item where the cursor is
// TODO hold shift to place multiple items

package simulator;	

import java.util.List;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.event.MouseInputListener;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import simulator.component.CannotCreateComponentException;
import simulator.component.ComponentFactory;
import simulator.component.Component;
import simulator.component.Interface;
import simulator.component.ComponentGraphic;

public class ComponentField extends JPanel implements MouseInputListener {
	public final static long serialVersionUID = 1;
	public static enum Tool {COMPONENT_PLACEMENT, INTERACTION, WIRING}; 
	
	private final static int STEP = 10;
	private ComponentFactory factory;
	private ComponentGraphicAndPosition cgap; 
	private Color backgroundColor = Color.WHITE;
	private Cursor emptyCursor, selectionCursor;
	private Tool selectedTool = Tool.INTERACTION;
	
	private List<ComponentAndPosition> components;
	private List<Interface> interfaces;
	
	private Interface selectedInterface = null;
	
	private Engine engine;
	
	// repaint timer - this is to ensure the interfaces etc. get repainted
	private Timer repaintTimer = new Timer(20, new ActionListener() {
		public void actionPerformed(ActionEvent evt) {
			repaint();
		}
	}); 
	
	public ComponentField(Engine engine) {
		super();
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.setBackground(Color.WHITE);
		this.components = new Vector<ComponentAndPosition>();
		Toolkit tk = Toolkit.getDefaultToolkit();
		this.emptyCursor = tk.createCustomCursor(
				tk.getImage("simulator/materials/blankImage.gif"),
				new Point(0, 0),
				"blank");
		this.selectionCursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);
		this.engine = engine;
		interfaces = new Vector<Interface>();
		repaintTimer.start();
	}
    
    private void paintGrid(Graphics g) {
    	Dimension size = this.getSize();
    	
		// draw grid
		g.setColor(Color.GRAY);
		for(int x = STEP; x < size.width; x += STEP) {
			for(int y = STEP; y < size.height; y += STEP) {
				g.drawLine(x, y, x, y);
			}
		}
		repositionComponents();
    }
    
    public void setSelectedComponentFactory(ComponentFactory cf) {
    	factory = cf;
    	cgap = new ComponentGraphicAndPosition(cf.getComponentGraphic(), new Point(0, 0));
    }
    
    private void repositionComponents() {
    	repositionComponents(null);
    }
    
    public void removeAllComponents() {
    	components.clear();
    	super.removeAll();
    }
    
    private void repositionComponents(Point point) {
    	for(ComponentAndPosition cap : components)
    		cap.resetLocation();
    	
    	if(point != null && cgap != null)
    		cgap.setPoint(snapToGrid(point));
    	else if(cgap != null)
    		cgap.resetLocation();
    }
    
    public Tool getTool() {
    	return selectedTool;
    }
    
    public void setTool(Tool t) {
    	selectedTool = t;
    	if(selectedTool != Tool.WIRING && selectedInterface != null) {
    		selectedInterface.setSelected(false);
    		selectedInterface = null;
    	}
    }
    
    private Point snapToGrid(Point point) {
    	Point p = new Point();
    	p.x = Math.round(point.x / STEP) * STEP;
    	p.y = Math.round(point.y / STEP) * STEP;
    	return p;
    }
    
    private void addComponent(ComponentFactory f, Point p) {
    	Component c = null;
    	// create the storage class
    	try {
    		c = f.createComponent();
    		if(c == null) {
    			JOptionPane.showMessageDialog(this, "Could not create component.\n\nUnknown error.", "Cannot create component", JOptionPane.ERROR_MESSAGE);
    			return;
    		}
    	} catch (CannotCreateComponentException e) {
    		JOptionPane.showMessageDialog(this, "Could not create component.\n\n" + e.getMessage(), "Cannot create component", JOptionPane.ERROR_MESSAGE);
    		return;
    	}
    	Point point = snapToGrid(p);
    	ComponentAndPosition cap = new ComponentAndPosition(c, point);
    	// add to the list of components
    	components.add(cap);
    	// listen for clicking on the interface (this is used for wiring)
    	for(final Interface i : c.getInterfaces()) {
    		i.addMouseListener(new MouseListener() {
    			public void mousePressed(MouseEvent e) {}
    			public void mouseReleased(MouseEvent e) {}
    			public void mouseEntered(MouseEvent e) {}
    			public void mouseExited(MouseEvent e) {}
    			public void mouseClicked(MouseEvent e) {
    				interfaceClicked(i, e);
    			}
    		});
    		interfaces.add(i);
    	}
    	// subscribe the component to the engine
    	engine.subscribe(c);
    	// add to the panel
    	add(c.getComponentGraphic());
    	// position the components
    	repositionComponents(p);
    	// validate and repaint the form
    	validate();
    	repaint();
    }
    
    public void interfaceClicked(Interface i, MouseEvent e) {
    	// this is for wiring only
    	if(selectedTool != Tool.WIRING) return;
    	
    	if(selectedInterface == null) {
    		// nothing previously selected
    		selectedInterface = i;
    		i.setSelected(true);
    	} else {
    		if(selectedInterface == i) {
    			// click on the same interface
    			i.setSelected(false);
    			selectedInterface = null;
    			return; 
    		}
    		
    		// if not connected then connect, otherwise disconnect
    		if(i.isSibling(selectedInterface)) {
    			// disconnect the selected and this interface
    			engine.disconnect(i, selectedInterface);
    		} else {
    			// connect the selected and this interface
    			engine.connect(i, selectedInterface);
    		}
    		
    		// deselect the interface
    		selectedInterface.setSelected(false);
    		selectedInterface = null;
    		
    		repaint();
    	}
    }
    
    /* JPanel/JComponent/etc methods */
    public void paintComponent(Graphics g) {
		Dimension size = this.getSize();
		// clean the canvas
		g.setColor(backgroundColor);
		g.fillRect(0, 0, size.width, size.height);
		paintGrid(g);
		paintConnections(g);
    }
    
    private void paintConnections(Graphics g) {
		g.setColor(Color.BLACK);
		
		for(ComponentAndPosition cap : components) {
			Component c = cap.getComponent();
			for(Interface i : c.getInterfaces()) {
				for(Interface sibling : i.getSiblings()) {
					Point a, b, offset;
					a = i.getLocationOnScreen();
					b = sibling.getLocationOnScreen();
					offset = this.getLocationOnScreen();
					a.x -= offset.x - i.getHeight() / 2;
					a.y -= offset.y - i.getWidth() / 2;
					b.x -= offset.x - sibling.getHeight() / 2;
					b.y -= offset.y - sibling.getWidth() / 2;
					
					g.drawLine(a.x, a.y, b.x, b.y);
				}
			}
		}
    }
    
    public void repaint() {
    	super.repaint();
    	//if(this.getGraphics() != null)
    	//	paintConnections(this.getGraphics());
    }
    
    /* MouseInputListener methods */
    public synchronized void mouseMoved(MouseEvent e) {
    	if(selectedTool == Tool.COMPONENT_PLACEMENT) {
    		if(cgap == null) return;
    		repositionComponents(e.getPoint());
    	} else if(selectedTool == Tool.INTERACTION) {
    		
    	} else if(selectedTool == Tool.WIRING) {
    		
    	}
    }
    
    public synchronized void mouseDragged(MouseEvent e) {}
    
    public synchronized void mouseClicked(MouseEvent e) {
    	if(selectedTool == Tool.COMPONENT_PLACEMENT) {
    		if(factory == null) return;
    		addComponent(factory, e.getPoint());
    	} else if(selectedTool == Tool.INTERACTION) {
    		
    	} else if(selectedTool == Tool.WIRING) {
    		
    	}
    }
    
    public synchronized void mousePressed(MouseEvent e) {}
    
    public synchronized void mouseReleased(MouseEvent e) {}
    
    public synchronized void mouseEntered(MouseEvent e) {
    	if(selectedTool == Tool.COMPONENT_PLACEMENT) {
    		if(cgap == null) return;
    		// make the item draw
    		this.setCursor(emptyCursor);
    		add(cgap.getGraphic());
    		validate();
    		repositionComponents(e.getPoint());
    		// position the components
    		repaint();
    	} else if(selectedTool == Tool.INTERACTION) {
    		this.setCursor(selectionCursor);
    	} else if(selectedTool == Tool.WIRING) {
    		
    	}
    }
    
    public synchronized void mouseExited(MouseEvent e) {
    	this.setCursor(null);
    	
    	if(selectedTool == Tool.COMPONENT_PLACEMENT) {
        	// stop the item from drawing
        	if(cgap == null) return;
        	remove(cgap.getGraphic());
        	validate();
        	// position the components
        	repositionComponents();
        	repaint();
		} else if(selectedTool == Tool.INTERACTION) {
		
		} else if(selectedTool == Tool.WIRING) {
		
		}
    }
    
    private class ComponentAndPosition {
    	private Component component;
    	private Point point;
    	
    	public ComponentAndPosition(Component component, Point point) {
    		this.component = component;
    		this.point = point;
    	}
    	
    	public void resetLocation() {
    		component.getComponentGraphic().setLocation(point);
    	}
    	
    	public Component getComponent() {
    		return component;
    	}
    	
    	public int getX() {
    		return point.x;
    	}
    	
    	public int getY() {
    		return point.y;
    	}
    	
    	public void setX(int x) {
    		this.point.x = x;
    	}
    	
    	public void setY(int y) {
    		this.point.y = y;
    	}
    	
    	public Point getPoint() {
    		return point;
    	}
    	
    	public void setPoint(Point point) {
    		this.point = point;
    	}
    }
    
    private class ComponentGraphicAndPosition {
    	private ComponentGraphic component;
    	private Point point;
    	
    	public ComponentGraphicAndPosition(ComponentGraphic component, Point point) {
    		this.component = component;
    		this.point = point;
    	}
    	
    	public ComponentGraphic getGraphic() {
    		return component;
    	}
    	
    	public void resetLocation() {
    		component.setLocation(point);
    	}
    	
    	public int getX() {
    		return point.x;
    	}
    	
    	public int getY() {
    		return point.y;
    	}
    	
    	public void setX(int x) {
    		this.point.x = x;
    	}
    	
    	public void setY(int y) {
    		this.point.y = y;
    	}
    	
    	public Point getPoint() {
    		return point;
    	}
    	
    	public void setPoint(Point point) {
    		this.point = point;
    		component.setLocation(point);
    	}
    }
}
