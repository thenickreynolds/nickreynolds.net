package simulator;

public class TemporaryException extends RuntimeException {
	static final long serialVersionUID = 0;
	
	public TemporaryException(String message) {
		super(message);
	}
}