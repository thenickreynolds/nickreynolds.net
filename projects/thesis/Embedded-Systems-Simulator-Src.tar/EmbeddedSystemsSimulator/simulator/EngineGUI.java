// TODO :FUTURE: handle exceptions properly and log all errors with enough information to help plugin writers 

package simulator;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JComponent;
import javax.swing.JTree;
import javax.swing.JScrollPane;
import javax.swing.JLabel;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeSelectionModel;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;

import java.lang.reflect.Modifier;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import simulator.component.*;
import simulator.settings.SettingsPanel;

public class EngineGUI extends Engine implements TreeSelectionListener {
	// the gui main layer
	private final JPanel mainPanel;
	// the component field
	private final ComponentField componentField;
	// the settings panel
	private final SettingsPanel settingsPanel;
	// the side panel
	private final JPanel sidePanel;
	// the preview panel
	private final JPanel previewPanel;
	// the panel which contains the selecting tree and the preview panel
	private final JPanel sideTopPanel;
	
	private final String INTERACTION_STRING = "Interaction Tool";
	private final String WIRING_STRING = "Wiring Tool";
	
	private String[] classStrings = {
			"simulator.component.AT90S8515.AT90S8515Factory",
			"simulator.component.UARTtoTCP.UARTtoTCPFactory",
			"simulator.component.general.ClockFactory",
			"simulator.component.general.DelayFactory",
			"simulator.component.general.GroundFactory",
			"simulator.component.general.VCCFactory",
			"simulator.component.general.PushButtonFactory",
			"simulator.component.flipflops.FlipFlopDFactory",
			"simulator.component.flipflops.FlipFlopJKFactory",
			"simulator.component.flipflops.FlipFlopSRFactory",
			"simulator.component.flipflops.FlipFlopTFactory",
			"simulator.component.gates.GateANDFactory",
			"simulator.component.gates.GateNOTFactory",
			"simulator.component.gates.GateORFactory",
			"simulator.component.gates.GateXORFactory"};
	private List<ComponentFactory> factories = new ArrayList<ComponentFactory>();
	
	private JTree tree;
	
	public EngineGUI () {
		// set up the engine
		super();
		sidePanel = new JPanel(new GridLayout(2, 1));
		sideTopPanel = new JPanel(new GridLayout(2, 1));
		previewPanel = new JPanel(new BorderLayout());
		previewPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Preview"));
		sideTopPanel.add(previewPanel);
		mainPanel = new JPanel(new BorderLayout());
		componentField = new ComponentField(this);
		mainPanel.add(componentField, BorderLayout.CENTER);
		
		for(String s : classStrings) {
			try {
				Class<?> c = Class.forName(s);
				Class<?> sc = c.getSuperclass();
				// make sure this is not a final, static, interface, abstract, etc.
				if(c.getModifiers() != Modifier.PUBLIC) continue;
				// make sure the superclass of this class is ComponentFactory
				while(sc != null && sc != ComponentFactory.class)
					sc = sc.getSuperclass();
				if(sc != ComponentFactory.class) continue;
				// get the constructor which takes the engine as a parameter
				Constructor<?> constructor = c.getDeclaredConstructor(new Class[] {Engine.class});
				// create an instance of the factory and store it
				factories.add((ComponentFactory)constructor.newInstance(new Object[] {this}));
			} catch(ClassNotFoundException e) {
				// the class could not be located - log this information
			} catch(NoSuchMethodException e) {
				// the class does not have the correct constructor - log this information
			} catch(InvocationTargetException e) {
				// the constructor threw an exception
				e.printStackTrace();
			} catch(IllegalAccessException e) {
				// do not currently have access to this field
			} catch (InstantiationException e) {
				// the object cannot be instantiated (created)
			}
		}
		
		settingsPanel = new SettingsPanel();
		
		// create the component tree
		DefaultMutableTreeNode top = new DefaultMutableTreeNode("Components");
		top.add(new DefaultMutableTreeNode(INTERACTION_STRING));
		top.add(new DefaultMutableTreeNode(WIRING_STRING));
		createTree(top);
		tree = new JTree(top);
		tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		tree.addTreeSelectionListener(this);
		sideTopPanel.add(new JScrollPane(tree));
		sidePanel.add(sideTopPanel);
		sidePanel.add(settingsPanel);
		
		mainPanel.add(sidePanel, BorderLayout.WEST);
		mainPanel.validate();
	}
	
	private void createTree(DefaultMutableTreeNode top) {
		HashMap<String, DefaultMutableTreeNode> categories = new HashMap<String, DefaultMutableTreeNode>();
		
		for(final ComponentFactory cf : factories) {
			// get the path of this item
			String path = cf.getTreePath();
			// try to find category
			DefaultMutableTreeNode category = categories.get(path);
			// check if it existed
			if(category == null) {
				// create new category
				//String completePath[] = path.split(".");
				category = new DefaultMutableTreeNode(path);
				categories.put(path, category);
				top.add(category);
			}
			// create this node 
			DefaultMutableTreeNode factory = new DefaultMutableTreeNode(cf);
			// add this to the category
			category.add(factory);
		}
	}
	
	public void removeAllComponents() {
		super.removeAllComponents();
		componentField.removeAllComponents();
	}
	
	public void componentSelected(ComponentFactory factory) {
		// select the component and make the tool the component placement tool
		componentField.setSelectedComponentFactory(factory);
		componentField.setTool(ComponentField.Tool.COMPONENT_PLACEMENT);
		settingsPanel.clearSettings();
		settingsPanel.addSettings(factory.getSettings());
	}

	public JComponent getGUI() {
		return mainPanel;
	}
	
	public void valueChanged(TreeSelectionEvent evt) {
		// get the selected object
		Object selected = ((DefaultMutableTreeNode)tree.getLastSelectedPathComponent()).getUserObject();
		if(selected instanceof ComponentFactory) {
			componentSelected((ComponentFactory)selected);
			setPreview(((ComponentFactory)selected).getComponentGraphic());
		} else if(selected instanceof String) {
			String tool = (String)selected;
			if(tool.equals(WIRING_STRING)) {
				// use the wiring tool
    			componentField.setTool(ComponentField.Tool.WIRING);
    			settingsPanel.clearSettings();
    			setPreview(new JLabel(WIRING_STRING));
			} else if(tool.equals(INTERACTION_STRING)) {
				// use the interaction tool
    			componentField.setTool(ComponentField.Tool.INTERACTION);
    			settingsPanel.clearSettings();
    			setPreview(new JLabel(INTERACTION_STRING));
			} else {
				// use the interaction tool anyway
    			componentField.setTool(ComponentField.Tool.INTERACTION);
    			settingsPanel.clearSettings();
    			setPreview(new JLabel(INTERACTION_STRING));
			}
		}
	}
	
	private void setPreview(JComponent c) {
		JPanel p = new JPanel(new BorderLayout());
		p.add(c, BorderLayout.CENTER);
		previewPanel.removeAll();
		previewPanel.add(p, BorderLayout.CENTER);
		previewPanel.validate();
		previewPanel.repaint();
	}
}