// TODO :FUTURE: add the ability to change timing mechanism (real time, catch up if behind, unbound, x2, x4, etc.

package simulator;

import simulator.component.Component;
import simulator.component.Interface;
import simulator.component.InterfaceListener;

import java.util.Queue;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Set;

public class Engine implements InterfaceListener {
	// states of the system
	public static enum State { OFF, RUNNING, READY, PAUSED, STOP, BREAKPOINT };
	// the state of the system
	protected State state;
	// list of events ordered by the time they occur
	protected Queue<Event> eventQueue;
	// list of components connected to the system
	protected Set<Component> components;
	// the set of interfaces changed since the previous tick - hash set to make lookup fast
	protected Set<Interface> changedInterfaces;
	// the current time
	protected double time;
	// the time the simulation started - this is used to restrain to real time and changes value when (un)paused/(un)breakpointed
	protected long startTime;
	// the time the breakpoint was initiated - this is used to keep the real time throttle at peace
	protected long breakpointTime;
	
	// time delays
	public static final double TIME_YOCTOSECOND		= 00000000.000000000000000000000001;
	public static final double TIME_ZEPTOSECOND		= 00000000.000000000000000000001000;
	public static final double TIME_ATTOSECOND		= 00000000.000000000000000001000000;
	public static final double TIME_FEMTOSECOND		= 00000000.000000000000001000000000;
	public static final double TIME_PICOSECOND		= 00000000.000000000001000000000000;
	public static final double TIME_NANOSECOND		= 00000000.000000001000000000000000;
	public static final double TIME_MICROSECOND		= 00000000.000001000000000000000000;
	public static final double TIME_MILLISECOND		= 00000000.001000000000000000000000;
	public static final double TIME_CENTISECOND		= 00000000.010000000000000000000000;
	public static final double TIME_DECISECOND		= 00000000.100000000000000000000000;
	public static final double TIME_SECOND			= 00000001.000000000000000000000000;
	public static final double TIME_MINUTE			= 00000060.000000000000000000000000;
	public static final double TIME_HOUR			= 00003600.000000000000000000000000;
	public static final double TIME_DAY				= 00086400.000000000000000000000000;
	public static final double TIME_WEEK			= 00604800.000000000000000000000000;
	public static final double TIME_YEAR			= 31536000.000000000000000000000000;
	public static final double TIME_LEAPYEAR		= 31622400.000000000000000000000000;
	
	public static final double TIME_YOTTAHERTZ_TICK	= TIME_YOCTOSECOND;
	public static final double TIME_ZETTAHERTZ_TICK	= TIME_ZEPTOSECOND;
	public static final double TIME_EXAHERTZ_TICK	= TIME_ATTOSECOND;
	public static final double TIME_PETAHERTZ_TICK	= TIME_FEMTOSECOND;
	public static final double TIME_TERAHERTZ_TICK	= TIME_PICOSECOND;
	public static final double TIME_GIGAHERTZ_TICK	= TIME_NANOSECOND;
	public static final double TIME_MEGAHERTZ_TICK	= TIME_MICROSECOND;
	public static final double TIME_KILOHERTZ_TICK	= TIME_MILLISECOND;
	public static final double TIME_DECAHERTZ_TICK	= TIME_DECISECOND;
	public static final double TIME_HERTZ_TICK		= TIME_SECOND;
	
	public Engine() {
		// initialise variables
		eventQueue = new PriorityQueue<Event>();
		components = new HashSet<Component>();
		changedInterfaces = new HashSet<Interface>();
		time = 0;
		state = State.OFF;
	}
	
	public void init() {
		// init the system and all components - throw exception if system is not OFF
		if(state != State.OFF) throw new TemporaryException("Cannot init while system is not OFF");
		time = 0;
		eventQueue.clear();
		for(Component c : components) c.prepareOutputs();
		for(Component c : components) c.init();
		state = State.READY;
	}
	
	public double getTimeSeconds() {
		return time;
	}
	
	public double getTime() {
		return time;
	}
	
	public double getNextTime() {
		if(eventQueue.isEmpty()) return Double.MAX_VALUE;
		else return eventQueue.peek().getTime();
	}
	
	public void subscribe(Component c) {
		if(state != State.OFF) throw new TemporaryException("Can't add component while system not in OFF state");
		components.add(c);
		for(Interface i : c.getInterfaces()) i.addInterfaceListener(this);
	}
	
	public void unsubscribe(Component c) {
		if(state != State.OFF) throw new TemporaryException("Can't remove component while system not in OFF state");
		for(Interface i : c.getInterfaces()) {
			// disconnect all connections to siblings
			Object siblings[] = i.getSiblings().toArray();
			for(Object sibling : siblings)
				disconnect(i, (Interface)sibling);
			// remove the listener to the interface
			i.removeInterfaceListener(this);
		}
		c.dispose();
		components.remove(c);
	}
	
	public void connect(Interface a, Interface b) {
		if(state != State.OFF) throw new TemporaryException("Can't connect interfaces while system not in OFF state");
		a.connect(b);
		b.connect(a);
	}
	
	public void disconnect(Interface a, Interface b) {
		if(state != State.OFF) throw new TemporaryException("Can't disconnect interfaces while system not in OFF state");
		a.disconnect(b);
		b.disconnect(a);
	}
	
	public void addEvent(Event e) {
		// throw an exception if event is to occur in the past
		if(e.getTime() <= time) {
			throw new TemporaryException("Time of event is before the current system time");
		}
		
		// add event to queue
		eventQueue.add(e);
	}
	
	protected synchronized void tick() {
		if(state != State.RUNNING) {
			// don't execute this instruction
			return;
		}
		
		// nothing to do
		if(eventQueue.isEmpty()) return;
		
		// update time to that of current actions
		time = eventQueue.peek().getTime();
		
		// clear the interfaces to make way for all new ones
		changedInterfaces.clear();
		
		// execute all events for the current time
		do {
			eventQueue.remove().execute();
		} while (!eventQueue.isEmpty() && eventQueue.peek().getTime() == time);
		
		// send changed interface to all components attached to an interface in changedInterfaces
		Set<Component> parentComponents = new HashSet<Component>();
		
		// find all parent components
		for(Interface i : changedInterfaces)
			parentComponents.add(i.getOwner());
		
		// alert all parent components (new events are enqueued here)
		for(Component c : parentComponents)
			c.interfaceChanged(changedInterfaces);
	}
	
	public String toString() {
		String s = "Engine ["
			+ "Components: " + components.size() + ", "
			+ "Event Size: " + eventQueue.size() + ", "
			+ "System Time: " + time + "]\n";
		for(Component c : components) {
			s += c.getFullDescription() + "\n";
		}
		return s;
	}
	
	// start the system in realtime mode
	public void start() {
		start(true);
	}
	
	/**
	 * Start running the system. This will start an endless loop of executing event actions.
	 * @param realtime	If real-time is true the system will attempt slow the simulation to run at 1:1 SimulationTime:RealTime
	 */
	//  if real-time is true the system will attempt to run 1:1, simulation time:real time
	public void start(boolean realtime) {
		try {
			startTime = System.currentTimeMillis();
			// initialise the system
			init();
			state = State.RUNNING;
			// run the system
			while(true) {
				// the waiting time - used for real time simulation
				if(realtime) {
					while(true) {
						// check if any actions need to occur
						synchronized(this) {
							// being told to pause
							if(state == State.PAUSED) {
								long pauseTime = System.currentTimeMillis();
								wait();
								startTime += (System.currentTimeMillis() - pauseTime);
							}
							// being told to stop
							if(state == State.STOP) {
								state = State.OFF;
								eventQueue.clear();
								time = 0;
								break;
							}
						}
						
						long timeWait;
						if(eventQueue.isEmpty()) timeWait = Long.MAX_VALUE;
						else timeWait = (long)(startTime + eventQueue.peek().getTime() * 1000) - System.currentTimeMillis();
						if(timeWait <= 0) break;
						long realWait = Math.min(10, timeWait);
						Thread.sleep(realWait);
						time += (realWait / 1000.0);
					}
				}
				tick();
			}
		} catch (InterruptedException e) {
			assert false;
		}
	}
	
	public synchronized void pause() {
		if(state != State.RUNNING && state != State.READY) throw new TemporaryException("Cannot pause while not running");
		state = State.PAUSED;
	}
	
	public synchronized void unpause() {
		if(state != State.PAUSED) throw new TemporaryException("Cannot pause while not running");
		state = State.RUNNING;
		notify();
	}
	
	public synchronized void breakpoint() {
		if(state != State.RUNNING) throw new TemporaryException("Cannot breakpoint while not running");
		state = State.BREAKPOINT;
		breakpointTime = System.currentTimeMillis();
	}

	public synchronized void unbreakpoint() {
		if(state != State.BREAKPOINT) throw new TemporaryException("Cannot unbreakpoint while not breakpointed");
		state = State.RUNNING;
		startTime += (System.currentTimeMillis() - breakpointTime);
	}
	
	public synchronized void stop() {
		if(state != State.RUNNING && state != State.READY)
			throw new TemporaryException("Cannot stop while not running");
		state = State.STOP;
	}
	
	public synchronized void removeAllComponents() {
		if(state != State.OFF)
			throw new TemporaryException("Cannot removed components while not OFF");
		// make a copy of the set
		Object removeComponents[] = components.toArray();
		// remove them all
		for(Object c : removeComponents) {
			unsubscribe((Component)c);
		}
	}
	
	public synchronized State getState() {
		return state;
	}
		
	/* InterfaceListener methods */
	public void interfaceValueChanged(Interface i) {
		/* this is triggered when an input interface has changed value,
		 * this only occurs if a sibling interface has changed it's value
		 */
		changedInterfaces.add(i);
	}
}